# PocketDoJa Android 4.4 port — Pass 12

## Goal
Strengthen the Android 4.4 (API 19) validation path before asking the user to run a build on GitHub Actions.

## Changes
- Expanded the API-19 source preflight to scan all shipped Java source roots: the Android app, OpenDoJa runtime, and the `dexlib` Android library. Developer probes/tools remain excluded where the Android Gradle source set excludes them.
- Added explicit configuration checks for `minSdk 19`, `MultiDexApplication`, multidex, core-library desugaring, and `desugar_jdk_libs_nio:2.1.4`.
- Added a post-build APK verifier that checks the packaged manifest's minSdk and every DEX header. Android 4.4 Dalvik requires DEX 035; the verifier fails if D8 emits a newer DEX version.
- Added a Java record/AGP gate: the runtime has record declarations, and D8 record desugaring requires AGP 8.1+; this project's AGP 8.13.2 is checked by preflight.
- Added Gradle dependency caching to GitHub Actions and included dexlib lint diagnostics.
- Kept the original game JAM/JAR/SP data and emulator architecture unchanged.

## Why keep the newer Java APIs?
The configured NIO desugaring artifact includes the Java 11 default desugaring API set plus `java.nio`. The runtime also contains Java `record` declarations; D8/R8 lowers records for older Android VMs, and AGP 8.1+ is required for the global-synthetic handling. The official Android API tables list `List.of`, `List.copyOf`, `Map.of`, `Map.copyOf`, and `java.util.Base64` in the desugared API surface. This means these calls do not need to be mechanically rewritten solely because the minimum runtime is API 19. `Path.of` remains removed from shipped source because it is not part of the Android compile-time `Path` surface; `Paths.get` is used instead.

## Checks run in this workspace
- API-19 source preflight: run and recorded in the accompanying report.
- APK post-build verifier: syntax-checked only; it cannot run until a CI APK exists.
- Gradle Android build/lint: not run here because this workspace has no Android SDK/`android.jar`/ADB and cannot download Gradle 8.13.
- Android 4.4 install/launch/gameplay: not tested.

## Next gate
Run the workflow from a GitHub repository. The first CI run will reveal actual compiler/lint errors; after a successful build, inspect the APK verification result and test installation/launch on an Android 4.4 device or emulator.
