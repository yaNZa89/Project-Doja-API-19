# PocketDoJa API 19 — Gradle-independent build route

This is a fallback build path for environments where Gradle itself cannot be run. It does **not** change the application architecture or create a second app variant. It builds the same single Legacy package (`com.shibesan.pocketdoja`, minSdk 19, targetSdk 30).

## Required local tools

- JDK 17 (`javac`, `keytool`)
- Android SDK platform `android-34`
- Android Build Tools `35.0.0`: `aapt`, `aapt2`, `d8`, `zipalign`, `apksigner`
- `zip` and `unzip`

## Required dependency files

Place these in `.build-deps/`, or set the corresponding environment variables:

- `asm-9.6.jar` (`POCKETDOJA_ASM_JAR`)
- `multidex-2.0.1.aar` (`POCKETDOJA_MULTIDEX_AAR`)
- `desugar_jdk_libs_nio-2.1.4.jar` (`POCKETDOJA_DESUGAR_LIB_JAR`)
- `desugar_jdk_libs_configuration_nio-2.1.4.jar` (`POCKETDOJA_DESUGAR_CONFIG_JAR` source) with `META-INF/desugar/d8/desugar.json` extracted to `desugar_jdk_libs_configuration_nio-2.1.4.json`

The desugared library and its matching `desugar_jdk_libs_configuration_nio:2.1.4` configuration must use the same version. Extract `META-INF/desugar/d8/desugar.json` from the configuration JAR. Do not omit either: this source set uses Java NIO APIs that need core-library desugaring on API 19.

## Run

```sh
export ANDROID_HOME=/path/to/Android/Sdk
./tools/build-api19-manual.sh
```

Output:

`build-manual/PocketDoJa-legacy-v1.3.0a-api19-debug.apk`

The script compiles resources with AAPT2, Java sources with `javac`, converts app bytecode with D8 using `--min-api 19`, runs L8 to produce the NIO backport DEX, packages the AndroidX multidex runtime and desugared-library support, aligns and signs a debug APK, then checks minSdk and DEX version with the existing verifier.

## Important limitations

- This route has been authored but cannot be executed in the current workspace until the Android SDK/build-tools and the exact Maven artifacts above are available.
- The manual pipeline is not yet proven equivalent to AGP's resource/manifest processing. Any AAPT2/D8 errors must be fixed before treating its output as a valid build.
- A successful build is not a device test. Install and launch on an API 19 emulator/device, then test import, DoJa 5.0 launch, MascotCapsule V3 rendering, input, audio, lifecycle, and persistence.
- Debug signing is for testing only. No release keystore or password is included.
