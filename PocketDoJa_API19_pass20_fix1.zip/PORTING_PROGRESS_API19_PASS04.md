# PocketDoJa 1.3.0a — Android 4.4 / API 19 porting pass 04

## Changes in this pass

### 1. Legacy code-cache directory
- `Context.getCodeCacheDir()` was added in API 21.
- Added `CodeCacheCompat`: API 21+ uses `getCodeCacheDir()`, while API 19–20 uses the app's `getCacheDir()`.
- Updated both the DEX optimized-output directory and the UI's DEX-cache cleanup path to use the compatibility helper.

### 2. Task management compatibility
- `ActivityManager.getAppTasks()`, `ActivityManager.AppTask`, and `Activity.finishAndRemoveTask()` are API 21 features.
- Moved those references into `TaskCompat.Api21`.
- API 19–20 falls back to `Activity.finishAffinity()` and does not load the API-21 task helper.
- Updated both HomeActivity and EntryActivity exit flows.

### 3. Storage permission compatibility
- Added `StorageAccessCompat` to isolate API 23 runtime permission methods (`checkSelfPermission`, `requestPermissions`) and API 30 `Environment.isExternalStorageManager()`.
- API 19–22 treats legacy storage permission as install-time permission and does not call runtime permission APIs.
- Updated HomeActivity and CustomFilePicker.

### 4. Additional API-specific UI calls
- Moved `AnimatedImageDrawable` usage into an API 28 nested helper.
- Moved the API 33 three-argument `registerReceiver` overload into a nested helper.
- Moved `PopupWindow.setElevation()` into an API 21 nested helper.

### 5. MIDI playback fallback for API 19–22
- The original `MidiMediaPlayer` depended directly on API 21 `AudioAttributes`, API 23 `MediaDataSource`, and API 23 `PlaybackParams`.
- API 19–20 now selects the legacy `MediaPlayer.setAudioStreamType(STREAM_MUSIC)` and `setDataSource(String)` path.
- On API 19–22, MIDI bytes are written to a private temporary `.mid` file under `OpenDoJaPaths.hostDataRoot()/midi-cache` and removed when playback is released or startup fails.
- API 21+ audio attributes and API 23+ in-memory media source/playback-rate calls are isolated in nested API-specific helpers.
- This preserves a MIDI playback path on KitKat instead of failing on missing framework classes. Actual MIDI decoder availability still requires device testing.

## Validation performed
- `MidiMediaPlayer` compiled against API-shaped Android stubs.
- API 19 MIDI smoke test ran with an API-19-shaped runtime classpath that deliberately omitted `MediaDataSource`, `AudioAttributes`, and `PlaybackParams`; it verified the temporary-file path and cleanup.
- Storage/task smoke test ran with API-19-shaped stubs that deliberately omitted API-21/API-23/API-30 methods and classes.
- Code-cache smoke test ran with an API-19-shaped `Context` stub that deliberately omitted `getCodeCacheDir()`.
- Existing locale compatibility smoke test passed for the eight configured tags: `en`, `zh-CN`, `zh-TW`, `pt-BR`, `fil`, `ms`, `ja`, and `ko`.
- Static scan confirms the API-21/API-23/API-28/API-30/API-33 calls listed above now reside in nested compatibility helpers.
- Attempted `bash gradlew --version`; the wrapper could not download Gradle 8.13 because DNS resolution for `services.gradle.org` failed (`UnknownHostException`).

## Confirmed build configuration
- App `minSdk` is 19.
- `multiDexEnabled true` is set and the manifest uses `androidx.multidex.MultiDexApplication`.
- App core-library desugaring is enabled with `com.android.tools:desugar_jdk_libs_nio:2.1.4`.
- The NIO desugaring variant includes `java.nio.file`; Google's Android Developers blog documents it for devices including Android 7 and lower.
- The project uses AGP 8.13.2 and Gradle wrapper 8.13; Google's AGP compatibility table lists Gradle 8.13 as the minimum for AGP 8.13.
- The project contains Java records; AGP 8.1+ supports D8/R8 record desugaring. This is another reason to keep the app build on a modern AGP while targeting an older Android runtime.

## Remaining blockers / status
- No Android SDK (`android.jar`, `aapt`, `d8`, `adb`) is installed in this environment.
- No full Gradle build, APK signing, installation, or real Android 4.4 test has been completed.
- MIDI decoder behavior, DEX class loading, audio output, file import, OpenGL rendering, and actual Monster Hunter i for SH gameplay must still be tested on an API 19 device/emulator.
- This is a source-level compatibility pass, not a verified Android 4.4 APK release.
