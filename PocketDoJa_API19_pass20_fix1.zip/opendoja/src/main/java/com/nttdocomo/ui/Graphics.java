package com.nttdocomo.ui;

import com.nttdocomo.lang.XString;
import com.nttdocomo.lang._XStringSupport;
import com.nttdocomo.ui.ogl.DirectBuffer;
import opendoja.g3d.DojaGraphics3DRenderer;
import opendoja.g3d.OptJ3DRenderer;
import opendoja.host.*;
import opendoja.host.compat.CompatFeature;
import opendoja.host.compat.GameCompatibility;
import opendoja.host.ogl.AcrodeaOglRenderer;
import opendoja.host.ogl.OglRenderer;

import opendoja.compat.awt.*;
import opendoja.compat.awt.geom.AffineTransform;
import opendoja.compat.awt.image.BufferedImage;
import java.util.function.Consumer;

/**
 * Represents the graphics context used for canvases and images.
 */
public class Graphics implements com.nttdocomo.ui.graphics3d.Graphics3D, com.nttdocomo.opt.ui.j3d.Graphics3D, com.nttdocomo.ui.ogl.GraphicsOGL {
    private static final boolean TRACE_FAILURES = opendoja.host.OpenDoJaLaunchArgs.getBoolean(opendoja.host.OpenDoJaLaunchArgs.TRACE_FAILURES);
    private static final boolean TRACE_3D_CALLS = opendoja.host.OpenDoJaLaunchArgs.getBoolean(opendoja.host.OpenDoJaLaunchArgs.DEBUG3D_CALLS);
    private static final boolean TRACE_OPEN_GLES_SYNC = opendoja.host.OpenDoJaLaunchArgs.getBoolean(opendoja.host.OpenDoJaLaunchArgs.TRACE_OPEN_GLES_SYNC);
    private static final double DOJAAFFINE_FIXED_POINT_SCALE = 4096.0;
    private static final int OPT_RENDER_OP_REPL = 0;
    private static final int OPT_RENDER_OP_ADD = 1;
    private static final int OPT_RENDER_OP_SUB = 2;

    /**
     * Constant for black.
     */
    public static final int BLACK = 0;
    /**
     * Constant for blue.
     */
    public static final int BLUE = 1;
    /**
     * Constant for lime.
     */
    public static final int LIME = 2;
    /**
     * Constant for aqua.
     */
    public static final int AQUA = 3;
    /**
     * Constant for red.
     */
    public static final int RED = 4;
    /**
     * Constant for fuchsia.
     */
    public static final int FUCHSIA = 5;
    /**
     * Constant for yellow.
     */
    public static final int YELLOW = 6;
    /**
     * Constant for white.
     */
    public static final int WHITE = 7;
    /**
     * Constant for gray.
     */
    public static final int GRAY = 8;
    /**
     * Constant for navy.
     */
    public static final int NAVY = 9;
    /**
     * Constant for green.
     */
    public static final int GREEN = 10;
    /**
     * Constant for teal.
     */
    public static final int TEAL = 11;
    /**
     * Constant for maroon.
     */
    public static final int MAROON = 12;
    /**
     * Constant for purple.
     */
    public static final int PURPLE = 13;
    /**
     * Constant for olive.
     */
    public static final int OLIVE = 14;
    /**
     * Constant for silver.
     */
    public static final int SILVER = 15;
    /**
     * Image flip-mode constant for none.
     */
    public static final int FLIP_NONE = 0;
    /**
     * Image flip-mode constant for horizontal.
     */
    public static final int FLIP_HORIZONTAL = 1;
    /**
     * Image flip-mode constant for vertical.
     */
    public static final int FLIP_VERTICAL = 2;
    /**
     * Image flip-mode constant for rotate.
     */
    public static final int FLIP_ROTATE = 3;
    /**
     * Image flip-mode constant for rotate left.
     */
    public static final int FLIP_ROTATE_LEFT = 4;
    /**
     * Image flip-mode constant for rotate right.
     */
    public static final int FLIP_ROTATE_RIGHT = 5;
    /**
     * Image flip-mode constant for rotate right horizontal.
     */
    public static final int FLIP_ROTATE_RIGHT_HORIZONTAL = 6;
    /**
     * Image flip-mode constant for rotate right vertical.
     */
    public static final int FLIP_ROTATE_RIGHT_VERTICAL = 7;

    private final DesktopSurface surface;
    private DoJaRuntime ownerRuntime;
    private Graphics2D delegate;
    private final DojaGraphics3DRenderer doja3D = new DojaGraphics3DRenderer(TRACE_3D_CALLS);
    private final OptJ3DRenderer opt3D = new OptJ3DRenderer(doja3D.context(), TRACE_3D_CALLS);
    private final OglRenderer oglRenderer;
    private boolean pendingOptRenderedContent;
    private int originX;
    private int originY;
    private int color = getColorOfName(BLACK);
    private Font font = Font.getDefaultFont();
    private int flipMode = FLIP_NONE;
    private boolean pictoColorEnabled;
    private Runnable softwareMutationHook;
    private Runnable disposeHook;
    private Consumer<Graphics> copyHook;
    private int lockDepth;
    // True when this draw slice included an image. Clear-after-flush only applies to
    // text-only frames so titles that keep a static background from the previous frame survive.
    private boolean frameDrewImage;
    /** Reused scratch for {@link #blendOptRenderLayer}. */
    private int[] optDestinationPixels;
    private int[] optSourcePixels;
    private static volatile java.lang.reflect.Constructor<?> platformGraphicsConstructor;

    /**
     * Applications cannot create this object directly.
     */
    protected Graphics() {
        this(new DesktopSurface(1, 1));
    }

    /**
     * Applications cannot create this object directly.
     */
    protected Graphics(DesktopSurface surface) {
        this.surface = surface;
        this.delegate = surface.image().createGraphics();
        configureDelegate(this.delegate);
        this.delegate.setColor(new Color(color, true));
        this.delegate.setFont(font.awtFont());
        this.oglRenderer = new AcrodeaOglRenderer(new GraphicsOglHost());
        clearClip();
    }

    /** Associates this Graphics with the runtime that owns its canvas. */
    void attachOwnerRuntime(DoJaRuntime runtime) {
        this.ownerRuntime = runtime;
    }

    /**
     * Cooperative shutdown: once the owning game runtime has shut down, any further API use
     * from a leaked game thread throws an Error (not catchable by the title's catch(Exception)),
     * so the thread unwinds instead of spinning forever (Thread.stop() is unsupported on Android).
     */
    private void throwIfOwnerShutdown() {
        DoJaRuntime runtime = ownerRuntime;
        boolean shuttingDown = runtime != null ? runtime.isShutdown() : DoJaRuntime.isShuttingDown();
        DoJaRuntime.terminateOrParkIfShuttingDown(shuttingDown);
    }

    static Graphics createPlatformGraphics(DesktopSurface surface) {
        try {
            java.lang.reflect.Constructor<?> constructor = platformGraphicsConstructor;
            if (constructor == null) {
                Class<?> clazz = Class.forName("com.docomostar.opt.ui.Graphics2");
                constructor = clazz.getDeclaredConstructor(DesktopSurface.class);
                constructor.setAccessible(true);
                platformGraphicsConstructor = constructor;
            }
            return (Graphics) constructor.newInstance(surface);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return new Graphics(surface);
        }
    }

    /**
     * Clears clip.
     */
    public void clearClip() {
        delegate.setClip(0, 0, surface.width(), surface.height());
    }

    /**
     * Clears rect.
     */
    public void clearRect(int x, int y, int width, int height) {
        prepareSoftwareSurfaceMutation();
        Color old = delegate.getColor();
        delegate.setColor(new Color(surface.backgroundColor(), true));
        delegate.fillRect(originX + x, originY + y, width, height);
        delegate.setColor(old);
        flushSurfacePresentation();
    }

    /**
     * Clips rect.
     */
    public void clipRect(int x, int y, int width, int height) {
        delegate.clipRect(originX + x, originY + y, width, height);
    }

    /**
     * Copies copy.
     */
    public Graphics copy() {
        Graphics copy = createPlatformGraphics(surface);
        copy.originX = originX;
        copy.originY = originY;
        copy.color = color;
        copy.font = font;
        copy.flipMode = flipMode;
        copy.softwareMutationHook = softwareMutationHook;
        copy.copyHook = copyHook;
        Shape clip = delegate.getClip();
        if (clip != null) {
            copy.delegate.setClip(clip);
        }
        copy.delegate.setColor(new Color(color, true));
        copy.delegate.setFont(font.awtFont());
        copy.pictoColorEnabled = pictoColorEnabled;
        copy.doja3D.copyStateFrom(doja3D);
        copy.opt3D.copyStateFrom(opt3D);
        if (copy.copyHook != null) {
            copy.copyHook.accept(copy);
        }
        return copy;
    }

    /**
     * Returns the current origin X coordinate.
     */
    protected final int getOriginX() {
        return originX;
    }

    /**
     * Returns the current origin Y coordinate.
     */
    protected final int getOriginY() {
        return originY;
    }

    private final class GraphicsOglHost implements OglRenderer.Host {
        @Override
        public DesktopSurface surface() {
            return surface;
        }

        @Override
        public Graphics2D delegate() {
            return delegate;
        }

        @Override
        public void markOpenGlesActivity() {
            surface.markOpenGlesActivity();
        }

        @Override
        public void flushSurfacePresentation() {
            Graphics.this.flushSurfacePresentation();
        }

        @Override
        public void onSoftwareSurfaceMutation() {
            oglRenderer.onSoftwareSurfaceMutation();
        }
    }

    @Override
    public void glClearColor(float red, float green, float blue, float alpha) {
        oglRenderer.glClearColor(red, green, blue, alpha);
    }

    @Override
    public void glClear(int mask) {
        oglRenderer.glClear(mask);
    }

    @Override
    public void beginDrawing() {
        oglRenderer.beginDrawing();
    }

    @Override
    public void endDrawing() {
        oglRenderer.endDrawing();
    }

    @Override
    public void glEnable(int cap) {
        oglRenderer.glEnable(cap);
    }

    @Override
    public void glDisable(int cap) {
        oglRenderer.glDisable(cap);
    }

    @Override
    public void glEnableClientState(int array) {
        oglRenderer.glEnableClientState(array);
    }

    @Override
    public void glDisableClientState(int array) {
        oglRenderer.glDisableClientState(array);
    }

    @Override
    public void glMatrixMode(int mode) {
        oglRenderer.glMatrixMode(mode);
    }

    @Override
    public void glLoadIdentity() {
        oglRenderer.glLoadIdentity();
    }

    @Override
    public void glLoadMatrixf(float[] m) {
        oglRenderer.glLoadMatrixf(m);
    }

    @Override
    public void glMultMatrixf(float[] m) {
        oglRenderer.glMultMatrixf(m);
    }

    @Override
    public void glPushMatrix() {
        oglRenderer.glPushMatrix();
    }

    @Override
    public void glPopMatrix() {
        oglRenderer.glPopMatrix();
    }

    @Override
    public void glOrthof(float left, float right, float bottom, float top, float zNear, float zFar) {
        oglRenderer.glOrthof(left, right, bottom, top, zNear, zFar);
    }

    @Override
    public void glFrustumf(float left, float right, float bottom, float top, float zNear, float zFar) {
        oglRenderer.glFrustumf(left, right, bottom, top, zNear, zFar);
    }

    @Override
    public void glDepthRangef(float zNear, float zFar) {
        oglRenderer.glDepthRangef(zNear, zFar);
    }

    @Override
    public void glRotatef(float angle, float x, float y, float z) {
        oglRenderer.glRotatef(angle, x, y, z);
    }

    @Override
    public void glScalef(float x, float y, float z) {
        oglRenderer.glScalef(x, y, z);
    }

    @Override
    public void glTranslatef(float x, float y, float z) {
        oglRenderer.glTranslatef(x, y, z);
    }

    @Override
    public void glAlphaFunc(int func, float ref) {
        oglRenderer.glAlphaFunc(func, ref);
    }

    @Override
    public void glDepthMask(boolean flag) {
        oglRenderer.glDepthMask(flag);
    }

    @Override
    public void glDepthFunc(int func) {
        oglRenderer.glDepthFunc(func);
    }

    @Override
    public void glBlendFunc(int sfactor, int dfactor) {
        oglRenderer.glBlendFunc(sfactor, dfactor);
    }

    @Override
    public void glColor4f(float red, float green, float blue, float alpha) {
        oglRenderer.glColor4f(red, green, blue, alpha);
    }

    @Override
    public void glColor4ub(short red, short green, short blue, short alpha) {
        oglRenderer.glColor4ub(red, green, blue, alpha);
    }

    @Override
    public void glLightModelf(int pname, float param) {
        oglRenderer.glLightModelf(pname, param);
    }

    @Override
    public void glLightModelfv(int pname, float[] params) {
        oglRenderer.glLightModelfv(pname, params);
    }

    @Override
    public void glLightf(int light, int pname, float param) {
        oglRenderer.glLightf(light, pname, param);
    }

    @Override
    public void glLightfv(int light, int pname, float[] params) {
        oglRenderer.glLightfv(light, pname, params);
    }

    @Override
    public void glMaterialf(int face, int pname, float param) {
        oglRenderer.glMaterialf(face, pname, param);
    }

    @Override
    public void glMaterialfv(int face, int pname, float[] params) {
        oglRenderer.glMaterialfv(face, pname, params);
    }

    @Override
    public void glNormal3f(float nx, float ny, float nz) {
        oglRenderer.glNormal3f(nx, ny, nz);
    }

    @Override
    public void glTexEnvi(int target, int pname, int param) {
        oglRenderer.glTexEnvi(target, pname, param);
    }

    @Override
    public void glTexEnvfv(int target, int pname, float[] params) {
        oglRenderer.glTexEnvfv(target, pname, params);
    }

    @Override
    public void glShadeModel(int mode) {
        oglRenderer.glShadeModel(mode);
    }

    @Override
    public void glActiveTexture(int texture) {
        oglRenderer.glActiveTexture(texture);
    }

    @Override
    public void glClientActiveTexture(int texture) {
        oglRenderer.glClientActiveTexture(texture);
    }

    @Override
    public void glMultiTexCoord4f(int target, float s, float t, float r, float q) {
        oglRenderer.glMultiTexCoord4f(target, s, t, r, q);
    }

    @Override
    public void glTexEnvf(int target, int pname, float param) {
        oglRenderer.glTexEnvf(target, pname, param);
    }

    @Override
    public void glTexEnviv(int target, int pname, int[] params) {
        oglRenderer.glTexEnviv(target, pname, params);
    }

    @Override
    public void glPixelStorei(int pname, int param) {
        oglRenderer.glPixelStorei(pname, param);
    }

    @Override
    public void glHint(int target, int mode) {
        oglRenderer.glHint(target, mode);
    }

    @Override
    public void glFrontFace(int mode) {
        oglRenderer.glFrontFace(mode);
    }

    @Override
    public void glCullFace(int mode) {
        oglRenderer.glCullFace(mode);
    }

    @Override
    public void glViewport(int x, int y, int width, int height) {
        oglRenderer.glViewport(x, y, width, height);
    }

    @Override
    public void glTexParameterf(int target, int pname, float param) {
        oglRenderer.glTexParameterf(target, pname, param);
    }

    @Override
    public void glTexParameteri(int target, int pname, int param) {
        oglRenderer.glTexParameteri(target, pname, param);
    }

    @Override
    public void glBindTexture(int target, int texture) {
        oglRenderer.glBindTexture(target, texture);
    }

    @Override
    public void glGenTextures(int n, int[] textures) {
        oglRenderer.glGenTextures(n, textures);
    }

    @Override
    public void glGenTextures(int[] textures) {
        oglRenderer.glGenTextures(textures);
    }

    @Override
    public void glDeleteTextures(int n, int[] textures) {
        oglRenderer.glDeleteTextures(n, textures);
    }

    @Override
    public void glDeleteTextures(int[] textures) {
        oglRenderer.glDeleteTextures(textures);
    }

    @Override
    public void glCompressedTexImage2D(int target, int level, int internalformat, int width, int height, int border, int imageSize, DirectBuffer pixels) {
        oglRenderer.glCompressedTexImage2D(target, level, internalformat, width, height, border, imageSize, pixels);
    }

    @Override
    public void glCompressedTexImage2D(int target, int level, int internalformat, int width, int height, int border,
                                       com.nttdocomo.ui.ogl.ByteBuffer pixels) {
        oglRenderer.glCompressedTexImage2D(target, level, internalformat, width, height, border, pixels);
    }

    @Override
    public void glTexImage2D(int target, int level, int internalformat, int width, int height, int border,
                             int format, int type, DirectBuffer pixels) {
        oglRenderer.glTexImage2D(target, level, internalformat, width, height, border, format, type, pixels);
    }

    @Override
    public void glGenBuffers(int[] buffers) {
        oglRenderer.glGenBuffers(buffers);
    }

    @Override
    public void glDeleteBuffers(int[] buffers) {
        oglRenderer.glDeleteBuffers(buffers);
    }

    @Override
    public void glBindBuffer(int target, int buffer) {
        oglRenderer.glBindBuffer(target, buffer);
    }

    @Override
    public void glBufferData(int target, DirectBuffer data, int usage) {
        oglRenderer.glBufferData(target, data, usage);
    }

    @Override
    public void glBufferSubData(int target, int offset, DirectBuffer data) {
        oglRenderer.glBufferSubData(target, offset, data);
    }

    @Override
    public void glVertexPointer(int size, int type, int stride, DirectBuffer pointer) {
        oglRenderer.glVertexPointer(size, type, stride, pointer);
    }

    @Override
    public void glVertexPointer(int size, int type, int stride, int pointer) {
        oglRenderer.glVertexPointer(size, type, stride, pointer);
    }

    @Override
    public void glTexCoordPointer(int size, int type, int stride, DirectBuffer pointer) {
        oglRenderer.glTexCoordPointer(size, type, stride, pointer);
    }

    @Override
    public void glTexCoordPointer(int size, int type, int stride, int pointer) {
        oglRenderer.glTexCoordPointer(size, type, stride, pointer);
    }

    @Override
    public void glNormalPointer(int type, int stride, DirectBuffer pointer) {
        oglRenderer.glNormalPointer(type, stride, pointer);
    }

    @Override
    public void glNormalPointer(int type, int stride, int pointer) {
        oglRenderer.glNormalPointer(type, stride, pointer);
    }

    @Override
    public void glColorPointer(int size, int type, int stride, DirectBuffer pointer) {
        oglRenderer.glColorPointer(size, type, stride, pointer);
    }

    @Override
    public void glColorPointer(int size, int type, int stride, int pointer) {
        oglRenderer.glColorPointer(size, type, stride, pointer);
    }

    @Override
    public void glCurrentPaletteMatrixOES(int matrixpaletteindex) {
        oglRenderer.glCurrentPaletteMatrixOES(matrixpaletteindex);
    }

    @Override
    public void glLoadPaletteFromModelViewMatrixOES() {
        oglRenderer.glLoadPaletteFromModelViewMatrixOES();
    }

    @Override
    public void glMatrixIndexPointerOES(int size, int type, int stride, DirectBuffer pointer) {
        oglRenderer.glMatrixIndexPointerOES(size, type, stride, pointer);
    }

    @Override
    public void glMatrixIndexPointerOES(int size, int type, int stride, int pointer) {
        oglRenderer.glMatrixIndexPointerOES(size, type, stride, pointer);
    }

    @Override
    public void glWeightPointerOES(int size, int type, int stride, DirectBuffer pointer) {
        oglRenderer.glWeightPointerOES(size, type, stride, pointer);
    }

    @Override
    public void glWeightPointerOES(int size, int type, int stride, int pointer) {
        oglRenderer.glWeightPointerOES(size, type, stride, pointer);
    }

    @Override
    public void glDrawArrays(int mode, int first, int count) {
        oglRenderer.glDrawArrays(mode, first, count);
    }

    @Override
    public void glDrawElements(int mode, int count, int type, DirectBuffer indices) {
        oglRenderer.glDrawElements(mode, count, type, indices);
    }

    @Override
    public void glDrawElements(int mode, int count, int type, int indices) {
        oglRenderer.glDrawElements(mode, count, type, indices);
    }

    @Override
    public void glDrawElements(int mode, int count, DirectBuffer indices) {
        oglRenderer.glDrawElements(mode, count, indices);
    }

    @Override
    public void glFlush() {
        oglRenderer.glFlush();
    }

    @Override
    public int glGetError() {
        return oglRenderer.glGetError();
    }

    @Override
    public void glGetIntegerv(int pname, int[] params) {
        oglRenderer.glGetIntegerv(pname, params);
    }

    @Override
    public void glGetFloatv(int pname, float[] params) {
        oglRenderer.glGetFloatv(pname, params);
    }

    /**
     * Captures an image from the current drawing surface.
     *
     * @param x the left edge of the region
     * @param y the top edge of the region
     * @param width the region width
     * @param height the region height
     * @return a new image containing the requested region
     */
    protected final Image getImageRegion(int x, int y, int width, int height) {
        if (width <= 0 || height <= 0) {
            return null;
        }
        int srcX = Math.max(0, originX + x);
        int srcY = Math.max(0, originY + y);
        int srcRight = Math.min(originX + x + width, surface.width());
        int srcBottom = Math.min(originY + y + height, surface.height());
        int srcWidth = srcRight - srcX;
        int srcHeight = srcBottom - srcY;
        if (srcWidth <= 0 || srcHeight <= 0) {
            return null;
        }
        int[] pixels = surface.image().getRGB(srcX, srcY, srcWidth, srcHeight, null, 0, srcWidth);
        return Image.createImage(srcWidth, srcHeight, pixels, 0);
    }

    // DoJa titles scroll cached surfaces with copyArea requests that can hang partly outside
    // the backing image; clip the source rectangle but keep dx/dy as translation offsets.
    /**
     * Copies area.
     */
    public void copyArea(int x, int y, int width, int height, int dx, int dy) {
        if (width <= 0 || height <= 0) {
            return;
        }
        int srcX = originX + x;
        int srcY = originY + y;
        int clippedSrcX = java.lang.Math.max(0, srcX);
        int clippedSrcY = java.lang.Math.max(0, srcY);
        int clippedSrcRight = java.lang.Math.min(srcX + width, surface.width());
        int clippedSrcBottom = java.lang.Math.min(srcY + height, surface.height());
        int clippedWidth = clippedSrcRight - clippedSrcX;
        int clippedHeight = clippedSrcBottom - clippedSrcY;
        if (clippedWidth <= 0 || clippedHeight <= 0) {
            return;
        }

        int destX = clippedSrcX + dx;
        int destY = clippedSrcY + dy;
        BufferedImage source = new BufferedImage(clippedWidth, clippedHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D sourceGraphics = source.createGraphics();
        try {
            sourceGraphics.drawImage(surface.image(),
                    0,
                    0,
                    clippedWidth,
                    clippedHeight,
                    clippedSrcX,
                    clippedSrcY,
                    clippedSrcX + clippedWidth,
                    clippedSrcY + clippedHeight,
                    null);
        } finally {
            sourceGraphics.dispose();
        }
        // copyArea mutates the surface like every other draw op; without the
        // mutation hook a transparent image would keep serving its stale keyed
        // copy after the pixels underneath changed.
        prepareSoftwareSurfaceMutation();
        delegate.drawImage(source, destX, destY, null);
        flushSurfacePresentation();
    }

    /**
     * Disposes this object and releases its resources.
     */
    public void dispose() {
        oglRenderer.close();
        delegate.dispose();
        Runnable hook = disposeHook;
        disposeHook = null;
        if (hook != null) {
            hook.run();
        }
    }

    void syncOffscreenSurfaceForReadback() {
        flushPending3DPasses();
        pendingOptRenderedContent = false;
        oglRenderer.flushHardwarePresentation();
    }

    /**
     * Host-only lifecycle hook, not part of the original DoJa API. Runtime-owned
     * paint callbacks may need to release the Java2D delegate without invalidating
     * the DoJa wrapper seen by application code.
     */
    public void refreshDelegateAfterHostPaint() {
        Shape clip = delegate.getClip();
        delegate.dispose();
        delegate = surface.image().createGraphics();
        configureDelegate(delegate);
        delegate.setColor(new Color(color, true));
        delegate.setFont(font.awtFont());
        if (clip == null) {
            delegate.setClip(null);
        } else {
            delegate.setClip(clip);
        }
        oglRenderer.onHostDelegateRecreated();
    }

    /**
     * Draws chars.
     */
    public void drawChars(char[] data, int x, int y, int offset, int length) {
        // DoJa uses the order (chars, x, y, offset, length), unlike Java SE/AWT.
        drawString(new String(data, offset, length), x, y);
    }

    /**
     * Draws image.
     */
    public void drawImage(Image image, int x, int y) {
        if (image == null) return;
        drawSubImage(image, x, y, 0, 0, image.getWidth(), image.getHeight(), image.getWidth(), image.getHeight());
    }

    /**
     * Draws sprite Set.
     */
    public void drawSpriteSet(SpriteSet spriteSet) {
        if (spriteSet == null) {
            throw new NullPointerException("spriteSet");
        }
        drawSpriteSet(spriteSet, 0, spriteSet.getCount());
    }

    /**
     * Draws sprite Set.
     */
    public void drawSpriteSet(SpriteSet spriteSet, int offset, int count) {
        if (spriteSet == null) {
            throw new NullPointerException("spriteSet");
        }
        if (offset < 0 || count < 0 || offset + count > spriteSet.getCount()) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int previousFlipMode = flipMode;
        for (int i = offset; i < offset + count; i++) {
            Sprite sprite = spriteSet.getSprite(i);
            if (sprite != null && sprite.isVisible()) {
                setFlipMode(sprite.getFlipMode());
                drawImage(sprite.image(), sprite.getX(), sprite.getY(), sprite.sourceX(), sprite.sourceY(), sprite.getWidth(), sprite.getHeight());
            }
        }
        setFlipMode(previousFlipMode);
    }

    /**
     * Draws image Map.
     */
    public void drawImageMap(ImageMap imageMap, int x, int y) {
        if (imageMap != null) {
            imageMap.draw(this, x, y);
        }
    }

    /**
     * Draws image.
     */
    public void drawImage(Image image, int x, int y, int sx, int sy, int width, int height) {
        if (image == null) return;
        drawSubImage(image, x, y, sx, sy, width, height, width, height);
    }

    /**
     * Draws line.
     */
    public void drawLine(int x1, int y1, int x2, int y2) {
        Rectangle bounds = rectangleFromPoints(originX + x1, originY + y1, originX + x2, originY + y2);
        if (drawWithOptRenderMode(bounds, graphics -> graphics.drawLine(originX + x1, originY + y1, originX + x2, originY + y2))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        delegate.drawLine(originX + x1, originY + y1, originX + x2, originY + y2);
        flushSurfacePresentation();
    }

    /**
     * Draws polyline.
     */
    public void drawPolyline(int[] xs, int[] ys, int n) {
        drawPolyline(xs, ys, n, 0);
    }

    /**
     * Draws polyline.
     */
    public void drawPolyline(int[] xs, int[] ys, int n, int mode) {
        if (xs == null || ys == null || n <= 0) {
            return;
        }
        int[] drawX = new int[n];
        int[] drawY = new int[n];
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (int i = 0; i < n; i++) {
            drawX[i] = originX + xs[i];
            drawY[i] = originY + ys[i];
            minX = Math.min(minX, drawX[i]);
            minY = Math.min(minY, drawY[i]);
            maxX = Math.max(maxX, drawX[i]);
            maxY = Math.max(maxY, drawY[i]);
        }
        Rectangle bounds = rectangleFromPoints(minX, minY, maxX, maxY);
        if (drawWithOptRenderMode(bounds, graphics -> graphics.drawPolyline(drawX, drawY, n))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        delegate.drawPolyline(drawX, drawY, n);
        flushSurfacePresentation(bounds);
    }

    /**
     * Draws rect.
     */
    public void drawRect(int x, int y, int width, int height) {
        Rectangle bounds = normalizedRectangle(originX + x, originY + y, width + 1, height + 1);
        if (drawWithOptRenderMode(bounds, graphics -> graphics.drawRect(originX + x, originY + y, width, height))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        delegate.drawRect(originX + x, originY + y, width, height);
        flushSurfacePresentation();
    }

    /**
     * Draws string.
     */
    public void drawString(String text, int x, int y) {
        if (text == null) {
            return;
        }
        opendoja.host.TextSampleLog.record(text);
        Rectangle bounds = new Rectangle(
                originX + x,
                originY + y - font.getAscent(),
                Math.max(1, font.stringWidth(text)),
                Math.max(1, font.getHeight()));
        if (drawWithOptRenderMode(bounds, graphics -> font.drawString(graphics, text, originX + x, originY + y, color))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        font.drawString(delegate, text, originX + x, originY + y, color);
        flushSurfacePresentation();
    }

    /**
     * Fills polygon.
     */
    public void fillPolygon(int[] xs, int[] ys, int n) {
        fillPolygon(xs, ys, n, 0);
    }

    /**
     * Fills polygon.
     */
    public void fillPolygon(int[] xs, int[] ys, int n, int mode) {
        if (xs == null || ys == null || n <= 0) {
            return;
        }
        int[] drawX = new int[n];
        int[] drawY = new int[n];
        for (int i = 0; i < n; i++) {
            drawX[i] = originX + xs[i];
            drawY[i] = originY + ys[i];
        }
        prepareSoftwareSurfaceMutation();
        delegate.fillPolygon(drawX, drawY, n);
        flushSurfacePresentation();
    }

    /**
     * Fills rect.
     */
    public void fillRect(int x, int y, int width, int height) {
        Rectangle bounds = normalizedRectangle(originX + x, originY + y, width, height);
        if (drawWithOptRenderMode(bounds, graphics -> graphics.fillRect(originX + x, originY + y, width, height))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        delegate.fillRect(originX + x, originY + y, width, height);
        flushSurfacePresentation();
    }

    /**
     * Gets color Of Name.
     */
    public static int getColorOfName(int name) {
        return switch (name) {
            case BLACK -> 0xFF000000;
            case BLUE -> 0xFF0000FF;
            case LIME -> 0xFF00FF00;
            case AQUA -> 0xFF00FFFF;
            case RED -> 0xFFFF0000;
            case FUCHSIA -> 0xFFFF00FF;
            case YELLOW -> 0xFFFFFF00;
            case WHITE -> 0xFFFFFFFF;
            case GRAY -> 0xFF808080;
            case NAVY -> 0xFF000080;
            case GREEN -> 0xFF008000;
            case TEAL -> 0xFF008080;
            case MAROON -> 0xFF800000;
            case PURPLE -> 0xFF800080;
            case OLIVE -> 0xFF808000;
            case SILVER -> 0xFFC0C0C0;
            default -> 0xFF000000;
        };
    }

    /**
     * Gets color Of R G B.
     */
    public static int getColorOfRGB(int red, int green, int blue) {
        return getColorOfRGB(red, green, blue, 255);
    }

    /**
     * Gets color Of R G B.
     */
    public static int getColorOfRGB(int red, int green, int blue, int alpha) {
        return ((alpha & 0xFF) << 24) | ((red & 0xFF) << 16) | ((green & 0xFF) << 8) | (blue & 0xFF);
    }

    /**
     * Starts double-buffered drawing.
     */
    public void lock() {
        throwIfOwnerShutdown();
        DoJaRuntime runtime = DoJaRuntime.current();
        if (runtime != null) {
            // Direct `Canvas.getGraphics()` loops bypass `requestRender(...)`,
            // so service queued runtime callbacks at explicit frame-lock
            // boundaries as well.
            runtime.drainApplicationCallbacks();
        }
        lockDepth++;
        // Each lock starts a fresh drawing slice. Tracking images per slice rather than
        // per frame lets a text-only screen clear even when the game already holds an
        // outer lock from drawing the previous scene.
        frameDrewImage = false;
        if (lockDepth == 1) {
            surface.beginGraphicsLock();
            // Multi-part line tracking only makes sense within one flush. Carrying it
            // across frames would shift unrelated text that reuses the same coordinates.
            _BitmapFont.resetTextLineState();
        }
        if (surface.hasRepaintHook() && lockDepth == 1) {
            setOrigin(0, 0);
            clearClip();
            setFlipMode(FLIP_NONE);
            resetCanvasFrameState();
        }
    }

    /**
     * Sets clip.
     */
    public void setClip(int x, int y, int width, int height) {
        delegate.setClip(originX + x, originY + y, width, height);
    }

    /**
     * Sets color.
     */
    public void setColor(int color) {
        this.color = color;
        delegate.setColor(new Color(color, true));
    }

    /**
     * Sets font.
     */
    public void setFont(Font font) {
        if (font == null) {
            return;
        }
        this.font = font;
        delegate.setFont(font.awtFont());
    }

    /**
     * Sets origin.
     */
    public void setOrigin(int x, int y) {
        this.originX = x;
        this.originY = y;
    }

    /**
     * Sets picto Color Enabled.
     */
    public void setPictoColorEnabled(boolean enabled) {
        this.pictoColorEnabled = enabled;
    }

    /**
     * Ends double-buffered drawing.
     */
    public void unlock(boolean flush) {
        // DoJa specifies that unlock() is a no-op when the lock count is already zero.
        if (lockDepth == 0) {
            return;
        }
        boolean presentFrame = false;
        boolean outermostUnlock = lockDepth == 1;
        boolean nestedCanvasUnlock = !flush && !outermostUnlock && surface.hasRepaintHook();
        boolean pacedPresentation = flush;
        // opt `renderPrimitives(...)` framebuffer blends participate in the same staged 3D pass
        // as later opaque draws. Replay them only at the pass boundary so opaque geometry fills
        // z first, then the blended pass can depth-test against that result.
        if (flush || outermostUnlock || nestedCanvasUnlock) {
            flushPending3DPasses();
        }
        if (flush) {
            traceOpenGlesSync("unlock present flush=true outermost=" + outermostUnlock);
            oglRenderer.flushHardwarePresentation();
            presentFrame = true;
        } else if (nestedCanvasUnlock) {
            traceOpenGlesSync("unlock present flush=false outermost=false");
            oglRenderer.flushHardwarePresentation();
            presentFrame = true;
            pacedPresentation = false;
        } else if (outermostUnlock && surface.hasRepaintHook()) {
            // Some games draw directly to Canvas.getGraphics() and finish the frame with unlock(false)
            // rather than unlock(true). Canvas surfaces still need to present at the end of that
            // outermost lock scope, while offscreen Image surfaces must remain offscreen.
            // These loops already own their pacing, so present without the sync-unlock delay that
            // explicit unlock(true)/flush() paths use.
            traceOpenGlesSync("unlock present flush=false outermost=true");
            oglRenderer.flushHardwarePresentation();
            presentFrame = true;
            pacedPresentation = false;
        }
        lockDepth--;
        if (outermostUnlock) {
            surface.endGraphicsLock();
        }
        DoJaRuntime runtime = DoJaRuntime.current();
        if (runtime != null && outermostUnlock) {
            // An outermost unlock marks the end of one application-owned draw
            // slice, so it is another safe point to release queued callbacks.
            runtime.drainApplicationCallbacks();
        }
        if (outermostUnlock && !presentFrame) {
            surface.endDepthFrame();
        }
        if (presentFrame) {
            // Snapshot after the pacing decision so frames that will not be shown
            // do not rotate the presentation buffers at all.
            surface.flushSnapshot(pacedPresentation, true);
        }
        if (flush
                && !frameDrewImage
                && surface.hasRepaintHook()
                && GameCompatibility.isFeatureEnabled(CompatFeature.CLEAR_CANVAS_AFTER_FLUSH)) {
            // Some handsets hand the app a blank back buffer after a flush, and the warning
            // screen depends on that. The snapshot above is already taken, so this only
            // affects the next frame. Text-only frames only: the menu redraws images over
            // its old background, and clearing those would erase it.
            surface.clearCanvasFrame(surface.backgroundColor());
        }
        if (flush) {
            // The flush ends this slice. Some titles keep drawing after unlock without
            // taking a new lock, so start the next slice with a clean flag.
            frameDrewImage = false;
        }
    }

    /**
     * Sets flip Mode.
     */
    public void setFlipMode(int flipMode) {
        this.flipMode = flipMode;
    }

    /**
     * Draws scaled Image.
     */
    public void drawScaledImage(Image image, int dx, int dy, int dw, int dh, int sx, int sy, int sw, int sh) {
        drawSubImage(image, dx, dy, sx, sy, sw, sh, dw, dh);
    }

    /**
     * Draws string.
     */
    public void drawString(XString text, int x, int y) {
        drawString(_XStringSupport.valueOrNull(text), x, y);
    }

    /**
     * Draws string.
     */
    public void drawString(XString text, int x, int y, int offset, int length) {
        if (text == null) {
            return;
        }
        String value = _XStringSupport.value(text, "text");
        int start = Math.max(0, offset);
        int end = Math.min(value.length(), start + Math.max(0, length));
        drawString(value.substring(start, end), x, y);
    }

    /**
     * Draws arc.
     */
    public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        Rectangle bounds = normalizedRectangle(originX + x, originY + y, width, height);
        if (drawWithOptRenderMode(bounds, graphics -> graphics.drawArc(originX + x, originY + y, width, height, startAngle, arcAngle))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        delegate.drawArc(originX + x, originY + y, width, height, startAngle, arcAngle);
        flushSurfacePresentation();
    }

    /**
     * Fills arc.
     */
    public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        Rectangle bounds = normalizedRectangle(originX + x, originY + y, width, height);
        if (drawWithOptRenderMode(bounds, graphics -> graphics.fillArc(originX + x, originY + y, width, height, startAngle, arcAngle))) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        delegate.fillArc(originX + x, originY + y, width, height, startAngle, arcAngle);
        flushSurfacePresentation();
    }

    /**
     * Gets pixel.
     */
    public int getPixel(int x, int y) {
        int readX = originX + x;
        int readY = originY + y;
        if (!isInSurface(readX, readY)) {
            return getColorOfName(BLACK);
        }
        return surface.image().getRGB(readX, readY);
    }

    /**
     * Gets r G B Pixel.
     */
    public int getRGBPixel(int x, int y) {
        int readX = originX + x;
        int readY = originY + y;
        if (!isInSurface(readX, readY)) {
            return 0;
        }
        return surface.image().getRGB(readX, readY);
    }

    /**
     * Gets pixels.
     */
    public int[] getPixels(int x, int y, int width, int height, int[] pixels, int offset) {
        return getRGBPixels(x, y, width, height, pixels, offset);
    }

    /**
     * Gets r G B Pixels.
     */
    public int[] getRGBPixels(int x, int y, int width, int height, int[] pixels, int offset) {
        int length = checkedReadRgbPixelLength(pixels, offset, width, height);
        int[] target = pixels == null ? new int[offset + length] : pixels;
        int baseX = originX + x;
        int baseY = originY + y;
        for (int row = 0; row < height; row++) {
            int readY = baseY + row;
            int rowOffset = offset + row * width;
            for (int column = 0; column < width; column++) {
                int readX = baseX + column;
                target[rowOffset + column] = isInSurface(readX, readY) ? surface.image().getRGB(readX, readY) : 0;
            }
        }
        return target;
    }

    /**
     * Sets pixel.
     */
    public void setPixel(int x, int y) {
        setRGBPixel(x, y, color);
    }

    /**
     * Sets pixel.
     */
    public void setPixel(int x, int y, int color) {
        setRGBPixel(x, y, color);
    }

    /**
     * Sets r G B Pixel.
     */
    public void setRGBPixel(int x, int y, int color) {
        int drawX = originX + x;
        int drawY = originY + y;
        if (!isVisibleSoftwarePixel(drawX, drawY)) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        surface.image().setRGB(drawX, drawY, toOpaqueRgb(color));
        flushSurfacePresentation(new Rectangle(drawX, drawY, 1, 1));
    }

    /**
     * Sets pixels.
     */
    public void setPixels(int x, int y, int width, int height, int[] pixels, int offset) {
        setRGBPixels(x, y, width, height, pixels, offset);
    }

    /**
     * Sets r G B Pixels.
     */
    public void setRGBPixels(int x, int y, int width, int height, int[] pixels, int offset) {
        int length = checkedRgbPixelLength(pixels, offset, width, height);
        prepareSoftwareSurfaceMutation();
        if (hasNonOpaqueRgbPixels(pixels, offset, length)) {
            surface.image().setRGB(originX + x, originY + y, width, height,
                    opaqueRgbPixels(pixels, offset, length), 0, width);
        } else {
            surface.image().setRGB(originX + x, originY + y, width, height, pixels, offset, width);
        }
        flushSurfacePresentation();
    }

    private static int checkedRgbPixelLength(int[] pixels, int offset, int width, int height) {
        if (pixels == null) {
            throw new NullPointerException("pixels");
        }
        return checkedReadRgbPixelLength(pixels, offset, width, height);
    }

    private static int checkedReadRgbPixelLength(int[] pixels, int offset, int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("width and height must be > 0");
        }
        int length = Math.multiplyExact(width, height);
        if (offset < 0 || (pixels != null && offset > pixels.length - length)) {
            throw new ArrayIndexOutOfBoundsException(offset);
        }
        return length;
    }

    private static boolean hasNonOpaqueRgbPixels(int[] pixels, int offset, int length) {
        for (int i = 0; i < length; i++) {
            if ((pixels[offset + i] & 0xFF000000) != 0xFF000000) {
                return true;
            }
        }
        return false;
    }

    private boolean isVisibleSoftwarePixel(int x, int y) {
        if (!isInSurface(x, y)) {
            return false;
        }
        Rectangle clipBounds = delegate.getClipBounds();
        return clipBounds == null || clipBounds.contains(x, y);
    }

    private boolean isInSurface(int x, int y) {
        return x >= 0 && y >= 0 && x < surface.width() && y < surface.height();
    }

    private static int[] opaqueRgbPixels(int[] pixels, int offset, int length) {
        int[] normalized = new int[length];
        for (int i = 0; i < length; i++) {
            normalized[i] = toOpaqueRgb(pixels[offset + i]);
        }
        return normalized;
    }

    private static int toOpaqueRgb(int pixel) {
        return 0xFF000000 | (pixel & 0x00FFFFFF);
    }

    private static int effectiveImageAlpha(Image image) {
        try {
            return image.getAlpha();
        } catch (com.nttdocomo.lang.UnsupportedOperationException ignored) {
            // Extended image types such as TransparentImage are always drawn fully opaque here.
            return 255;
        }
    }

    /**
     * Draws image.
     */
    public void drawImage(Image image, int[] matrix, int sx, int sy, int width, int height) {
        if (image == null) return;
        validateAffineImageArguments(image, matrix);
        validateAffineImageRegion(width, height);
        drawAffineImageValidated(image, createDoJaAffineTransform(matrix), sx, sy, width, height);
    }

    /**
     * Draws image.
     */
    public void drawImage(Image image, int[] matrix) {
        if (image == null) return;
        validateAffineImageArguments(image, matrix);
        drawAffineImageValidated(image, createDoJaAffineTransform(matrix), 0, 0, image.getWidth(), image.getHeight());
    }

    protected final void drawAffineImageValidated(Image image, AffineTransform localTransform, int sx, int sy, int width, int height) {
        ensureImageNotDisposed(image);
        BufferedImage source = image.renderForDisplay();
        if (source == null) {
            return;
        }
        frameDrewImage = true;

        int srcX1 = sx;
        int srcY1 = sy;
        int srcX2 = sx + width;
        int srcY2 = sy + height;
        int clippedSrcX1 = Math.max(0, srcX1);
        int clippedSrcY1 = Math.max(0, srcY1);
        int clippedSrcX2 = Math.min(source.getWidth(), srcX2);
        int clippedSrcY2 = Math.min(source.getHeight(), srcY2);
        if (clippedSrcX1 >= clippedSrcX2 || clippedSrcY1 >= clippedSrcY2) {
            return;
        }

        BufferedImage clippedSource = source.getSubimage(
                clippedSrcX1,
                clippedSrcY1,
                clippedSrcX2 - clippedSrcX1,
                clippedSrcY2 - clippedSrcY1);

        // Keep clipped source pixels at their original local coordinates instead of stretching
        // the visible remainder to fill the full requested region.
        localTransform.translate(clippedSrcX1 - srcX1, clippedSrcY1 - srcY1);
        Rectangle localBounds = transformedBounds(localTransform, clippedSource.getWidth(), clippedSource.getHeight());
        AffineTransform oldTransform = delegate.getTransform();
        Composite oldComposite = delegate.getComposite();
        Rectangle bounds = normalizedRectangle(
                originX + localBounds.x,
                originY + localBounds.y,
                localBounds.width,
                localBounds.height);
        if (drawWithOptRenderMode(bounds, graphics -> {
            AffineTransform drawTransform = new AffineTransform(localTransform);
            drawTransform.preConcatenate(AffineTransform.getTranslateInstance(originX, originY));
            AffineTransform savedTransform = graphics.getTransform();
            Composite savedComposite = graphics.getComposite();
            try {
                applyFlipTransform(graphics, localBounds.x, localBounds.y, localBounds.width, localBounds.height);
                int imageAlpha = effectiveImageAlpha(image);
                if (imageAlpha < 255) {
                    graphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageAlpha / 255.0f));
                }
                graphics.drawImage(clippedSource, drawTransform, null);
            } finally {
                graphics.setComposite(savedComposite);
                graphics.setTransform(savedTransform);
            }
        })) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        try {
            applyFlipTransform(localBounds.x, localBounds.y, localBounds.width, localBounds.height);
            AffineTransform drawTransform = new AffineTransform(localTransform);
            drawTransform.preConcatenate(AffineTransform.getTranslateInstance(originX, originY));
            int imageAlpha = effectiveImageAlpha(image);
            if (imageAlpha < 255) {
                delegate.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageAlpha / 255.0f));
            }
            delegate.drawImage(clippedSource, drawTransform, null);
        } finally {
            delegate.setComposite(oldComposite);
            delegate.setTransform(oldTransform);
        }
        flushSurfacePresentation();
    }

    private static void validateAffineImageArguments(Image image, int[] matrix) {
        if (image == null) {
            throw new NullPointerException("image");
        }
        if (matrix == null) {
            throw new NullPointerException("matrix");
        }
        if (matrix.length < 6) {
            throw new ArrayIndexOutOfBoundsException("matrix");
        }
    }

    private static void validateAffineImageRegion(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("width and height must be > 0");
        }
    }

    protected static final AffineTransform createDoJaAffineTransform(int[] matrix) {
        return new AffineTransform(
                matrix[0] / DOJAAFFINE_FIXED_POINT_SCALE,
                matrix[3] / DOJAAFFINE_FIXED_POINT_SCALE,
                matrix[1] / DOJAAFFINE_FIXED_POINT_SCALE,
                matrix[4] / DOJAAFFINE_FIXED_POINT_SCALE,
                matrix[2] / DOJAAFFINE_FIXED_POINT_SCALE,
                matrix[5] / DOJAAFFINE_FIXED_POINT_SCALE);
    }

    protected final void ensureImageNotDisposed(Image image) {
        if (image instanceof DesktopImage desktopImage) {
            desktopImage.ensureNotDisposed();
        }
    }

    protected final Image resolveNthMediaImageFrame(MediaImage image, int k) {
        if (image == null) {
            throw new NullPointerException("image");
        }
        if (image instanceof MediaManager.AbstractMediaResource tracked && tracked.state() != MediaResource.USE) {
            throw new UIException(UIException.ILLEGAL_STATE);
        }
        if (image instanceof MediaManager.AnimatedMediaImage animated) {
            if (k < 0 || k >= animated.frameCount()) {
                throw new IllegalArgumentException("k");
            }
            return animated.frame(k);
        }
        if (k != 0) {
            throw new IllegalArgumentException("k");
        }
        return image.getImage();
    }

    private static Rectangle transformedBounds(AffineTransform transform, int width, int height) {
        double[] corners = {
                0.0, 0.0,
                width, 0.0,
                0.0, height,
                width, height
        };
        transform.transform(corners, 0, corners, 0, corners.length / 2);
        double minX = corners[0];
        double minY = corners[1];
        double maxX = corners[0];
        double maxY = corners[1];
        for (int i = 2; i < corners.length; i += 2) {
            minX = Math.min(minX, corners[i]);
            minY = Math.min(minY, corners[i + 1]);
            maxX = Math.max(maxX, corners[i]);
            maxY = Math.max(maxY, corners[i + 1]);
        }
        int left = (int) Math.floor(minX);
        int top = (int) Math.floor(minY);
        int right = (int) Math.ceil(maxX);
        int bottom = (int) Math.ceil(maxY);
        return new Rectangle(left, top, Math.max(1, right - left), Math.max(1, bottom - top));
    }

    private void drawSubImage(Image image, int dx, int dy, int sx, int sy, int sw, int sh, int dw, int dh) {
        ensureImageNotDisposed(image);
        BufferedImage source = image == null ? null : image.renderForDisplay();
        if (source == null || sw <= 0 || sh <= 0 || dw == 0 || dh == 0) {
            return;
        }
        frameDrewImage = true;
        int srcX1 = sx;
        int srcY1 = sy;
        int srcX2 = sx + sw;
        int srcY2 = sy + sh;
        int clippedSrcX1 = Math.max(0, srcX1);
        int clippedSrcY1 = Math.max(0, srcY1);
        int clippedSrcX2 = Math.min(source.getWidth(), srcX2);
        int clippedSrcY2 = Math.min(source.getHeight(), srcY2);
        if (clippedSrcX1 >= clippedSrcX2 || clippedSrcY1 >= clippedSrcY2) {
            return;
        }
        // DoJa-style source rectangles can fall partially outside the image. Clip them and remap
        // the destination proportionally instead of delegating to getSubimage(), which throws.
        int destX1 = originX + dx + Math.round((clippedSrcX1 - srcX1) * (dw / (float) sw));
        int destY1 = originY + dy + Math.round((clippedSrcY1 - srcY1) * (dh / (float) sh));
        int destX2 = originX + dx + Math.round((clippedSrcX2 - srcX1) * (dw / (float) sw));
        int destY2 = originY + dy + Math.round((clippedSrcY2 - srcY1) * (dh / (float) sh));
        Rectangle bounds = flippedBounds(rectangleFromPoints(destX1, destY1, destX2, destY2), dx, dy, dw, dh);
        // Only build the (capturing) opt-mode painter when opt-render blending is actually
        // active; otherwise every sprite blit allocated a lambda that was never used.
        if (needsOptRenderModeBlend() && drawWithOptRenderMode(bounds, graphics -> {
            AffineTransform savedTransform = graphics.getTransform();
            Composite savedComposite = graphics.getComposite();
            try {
                applyFlipTransform(graphics, dx, dy, dw, dh);
                int imageAlpha = effectiveImageAlpha(image);
                if (imageAlpha < 255) {
                    graphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageAlpha / 255.0f));
                }
                graphics.drawImage(source, destX1, destY1, destX2, destY2, clippedSrcX1, clippedSrcY1, clippedSrcX2, clippedSrcY2, null);
            } finally {
                graphics.setComposite(savedComposite);
                graphics.setTransform(savedTransform);
            }
        })) {
            return;
        }
        prepareSoftwareSurfaceMutation();
        // Saving/restoring the delegate transform allocates (a double[6] + AffineTransform
        // + Matrix). The vast majority of sprites are unflipped, so only do it when needed.
        boolean flipped = flipMode != FLIP_NONE;
        AffineTransform oldTransform = flipped ? delegate.getTransform() : null;
        try {
            if (flipped) {
                applyFlipTransform(dx, dy, dw, dh);
            }
            int imageAlpha = effectiveImageAlpha(image);
            if (imageAlpha < 255) {
                delegate.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageAlpha / 255.0f));
            }
            delegate.drawImage(source, destX1, destY1, destX2, destY2, clippedSrcX1, clippedSrcY1, clippedSrcX2, clippedSrcY2, null);
            delegate.setComposite(AlphaComposite.SrcOver);
        } finally {
            if (flipped) {
                delegate.setTransform(oldTransform);
            }
        }
        Rectangle visibleBounds = bounds.intersection(new Rectangle(0, 0, surface.width(), surface.height()));
        if (shouldImmediatelyPresentOutsideLockImage(image, visibleBounds)) {
            oglRenderer.onSoftwareSurfaceMutation();
            traceOpenGlesSync("immediate software image present outside lock");
            surface.flush(copyImage(surface.image()), false);
            return;
        }
        flushSurfacePresentation(visibleBounds);
    }

    private boolean shouldImmediatelyPresentOutsideLockImage(Image image, Rectangle visibleBounds) {
        OpenGlesRendererMode mode = OpenDoJaLaunchArgs.openGlesRendererMode();
        if (mode != OpenGlesRendererMode.HARDWARE) {
            if (TRACE_OPEN_GLES_SYNC) {
                traceOutsideLockPresentDecision("image", false, "mode=" + mode, null, visibleBounds);
            }
            return false;
        }
        if (!(image instanceof DesktopImage desktopImage)) {
            traceOutsideLockPresentDecision("image", false, "non-desktop-image", null, visibleBounds);
            return false;
        }
        if (desktopImage.width() != surface.width() || desktopImage.height() != surface.height()) {
            traceOutsideLockPresentDecision("image", false,
                    "size=" + desktopImage.width() + "x" + desktopImage.height()
                            + " surface=" + surface.width() + "x" + surface.height(),
                    desktopImage, visibleBounds);
            return false;
        }
        if (visibleBounds.isEmpty()) {
            traceOutsideLockPresentDecision("image", false, "empty-bounds", desktopImage, visibleBounds);
            return false;
        }
        if (visibleBounds.width < surface.width() - 32 || visibleBounds.height < surface.height() - 32) {
            traceOutsideLockPresentDecision("image", false,
                    "bounds=" + visibleBounds.width + "x" + visibleBounds.height,
                    desktopImage, visibleBounds);
            return false;
        }
        boolean hasRepaintHook = surface.hasRepaintHook();
        boolean insideLock = surface.hasActiveGraphicsLock();
        boolean immediate = hasRepaintHook && !insideLock;
        traceOutsideLockPresentDecision("image", immediate,
                "hook=" + hasRepaintHook + " insideLock=" + insideLock,
                desktopImage, visibleBounds);
        return immediate;
    }

    private BufferedImage copyImage(BufferedImage image) {
        if (image == surface.image()) {
            return surface.copyForPresentation();
        }
        BufferedImage copy = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = copy.createGraphics();
        try {
            g2.drawImage(image, 0, 0, null);
        } finally {
            g2.dispose();
        }
        return copy;
    }

    private void flushSurfacePresentation() {
        flushSurfacePresentation(null);
    }

    private void flushSurfacePresentation(Rectangle bounds) {
        boolean insideLock = surface.hasActiveGraphicsLock();
        if (insideLock || !surface.hasRepaintHook()) {
            oglRenderer.onSoftwareSurfaceMutation();
            return;
        }
        if (OpenDoJaLaunchArgs.openGlesRendererMode() == OpenGlesRendererMode.HARDWARE) {
            if (!oglRenderer.hasBufferedHardwarePresentation()) {
                // Before the hardware backend has produced an authoritative frame snapshot,
                // outside-lock software mutations have nothing buffered to race against.
                // Publish startup/loading frames immediately so direct-canvas titles such as
                // Nose Hair Master can show their intro splash before the first normal
                // hardware-backed frame boundary exists.
                oglRenderer.onSoftwareSurfaceMutation();
                traceOpenGlesSync("immediate startup software present outside lock");
                surface.flush(copyImage(surface.image()), false);
                return;
            }
            // Immediate outside-lock presents can race the buffered hardware
            // frame and expose partially updated output. Keep the software
            // mutation on the backing surface, but let the next normal
            // unlock/present boundary publish it.
            Rectangle overlayBounds = bounds == null ? null : intersectSurfaceBounds(bounds);
            oglRenderer.onPresentedSoftwareOverlay(overlayBounds);
            traceOpenGlesSync("deferred software present outside lock"
                    + (overlayBounds == null
                    ? ""
                    : " bounds=" + overlayBounds.x + "," + overlayBounds.y + " "
                    + overlayBounds.width + "x" + overlayBounds.height));
            return;
        }
        oglRenderer.onPresentedSoftwareOverlay(bounds);
        traceOpenGlesSync("immediate software present outside lock");
        // Per-primitive outside-lock presents expose half-drawn frames; mark them as
        // non-boundary so hosts with present debouncing can coalesce a draw burst.
        // frame=null means "snapshot the surface when the present is delivered" -
        // copying 240x240 pixels through AWT here on every draw call costs more than
        // the drawing itself and was the dominant direct-draw frame cost.
        surface.flush(null, false, false);
    }

    private void prepareSoftwareSurfaceMutation() {
        // 2D primitives write the bitmap-backed surface directly; publish any pending OGL
        // software framebuffer content first so the two passes composite instead of racing.
        surface.flushOglFrameToBitmap();
        Runnable hook = softwareMutationHook;
        if (hook != null) {
            hook.run();
        }
        oglRenderer.prepareForSoftwareMutation();
    }

    void setSoftwareMutationHook(Runnable softwareMutationHook) {
        this.softwareMutationHook = softwareMutationHook;
    }

    void setDisposeHook(Runnable disposeHook) {
        this.disposeHook = disposeHook;
    }

    void setCopyHook(Consumer<Graphics> copyHook) {
        this.copyHook = copyHook;
    }

    private void traceOpenGlesSync(String message) {
        if (!TRACE_OPEN_GLES_SYNC) {
            return;
        }
        OpenDoJaLog.debug(Graphics.class, message);
    }

    protected void resetCanvasFrameState() {
    }

    protected boolean usesOptRenderMode() {
        return false;
    }

    protected int currentOptRenderOperator() {
        return OPT_RENDER_OP_REPL;
    }

    protected int currentOptRenderSourceRatio() {
        return 255;
    }

    protected int currentOptRenderDestinationRatio() {
        return 255;
    }

    private static void configureDelegate(Graphics2D graphics) {
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, Font.textAntialiasHint());
        graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
    }

    private boolean drawWithOptRenderMode(Rectangle bounds, Consumer<Graphics2D> painter) {
        if (!needsOptRenderModeBlend()) {
            return false;
        }
        Rectangle targetBounds = intersectSurfaceBounds(bounds);
        if (targetBounds == null) {
            return true;
        }
        BufferedImage layer = new BufferedImage(targetBounds.width, targetBounds.height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = layer.createGraphics();
        graphics.setLogicalSize(surface.width(), surface.height());
        try {
            configureDelegate(graphics);
            graphics.setColor(new Color(color, true));
            graphics.setFont(font.awtFont());
            graphics.translate(-targetBounds.x, -targetBounds.y);
            Rectangle clipBounds = delegate.getClipBounds();
            if (clipBounds != null) {
                graphics.setClip(clipBounds);
            }
            painter.accept(graphics);
        } finally {
            graphics.dispose();
        }
        prepareSoftwareSurfaceMutation();
        blendOptRenderLayer(layer, targetBounds.x, targetBounds.y);
        if (shouldImmediatelyPresentOptLayer(targetBounds)) {
            oglRenderer.onSoftwareSurfaceMutation();
            oglRenderer.flushHardwarePresentation();
            traceOpenGlesSync("immediate opt-layer present outside lock");
            surface.flush(copyImage(surface.image()), false);
            return true;
        }
        flushSurfacePresentation(targetBounds);
        return true;
    }

    private boolean needsOptRenderModeBlend() {
        return usesOptRenderMode()
                && (currentOptRenderOperator() != OPT_RENDER_OP_REPL || currentOptRenderSourceRatio() != 255);
    }

    private Rectangle intersectSurfaceBounds(Rectangle bounds) {
        if (bounds == null) {
            return null;
        }
        Rectangle clipped = bounds.intersection(new Rectangle(0, 0, surface.width(), surface.height()));
        Rectangle clipBounds = delegate.getClipBounds();
        if (clipBounds != null) {
            clipped = clipped.intersection(clipBounds);
        }
        return clipped.isEmpty() ? null : clipped;
    }

    private boolean shouldImmediatelyPresentOptLayer(Rectangle targetBounds) {
        OpenGlesRendererMode mode = OpenDoJaLaunchArgs.openGlesRendererMode();
        if (mode != OpenGlesRendererMode.HARDWARE) {
            if (TRACE_OPEN_GLES_SYNC) {
                traceOutsideLockPresentDecision("opt", false, "mode=" + mode, null, targetBounds);
            }
            return false;
        }
        if (targetBounds == null || targetBounds.isEmpty()) {
            traceOutsideLockPresentDecision("opt", false, "empty-bounds", null, targetBounds);
            return false;
        }
        if (targetBounds.width < surface.width() - 32 || targetBounds.height < surface.height() - 32) {
            traceOutsideLockPresentDecision("opt", false,
                    "bounds=" + targetBounds.width + "x" + targetBounds.height,
                    null, targetBounds);
            return false;
        }
        boolean hasRepaintHook = surface.hasRepaintHook();
        boolean insideLock = surface.hasActiveGraphicsLock();
        boolean immediate = hasRepaintHook && !insideLock;
        traceOutsideLockPresentDecision("opt", immediate,
                "hook=" + hasRepaintHook + " insideLock=" + insideLock,
                null, targetBounds);
        return immediate;
    }

    private void traceOutsideLockPresentDecision(String kind, boolean immediate, String reason,
                                                 DesktopImage image, Rectangle bounds) {
        if (!TRACE_OPEN_GLES_SYNC) {
            return;
        }
        boolean oglImage = image != null && image.surface().hasOpenGlesActivity();
        String imageInfo = image == null
                ? ""
                : " image=" + image.width() + "x" + image.height() + " alpha=" + image.getAlpha()
                        + " ogl=" + oglImage;
        String boundsInfo = bounds == null
                ? " bounds=<null>"
                : " bounds=" + bounds.x + "," + bounds.y + " " + bounds.width + "x" + bounds.height;
        OpenDoJaLog.debug(Graphics.class,
                "outside-lock " + kind + " present immediate=" + immediate + " reason=" + reason
                        + imageInfo + boundsInfo);
    }

    /**
     * Blends a rendered opt-mode layer into the surface.
     *
     * <p>This runs for every blended text/primitive a title draws, so it must stay
     * allocation-free and avoid per-pixel virtual calls. Earlier code re-read the
     * full surface width for every layer row and resolved the render operator and
     * ratios again for each channel of each pixel, which dominated frame time in
     * text-heavy and HUD-heavy titles.</p>
     */
    private void blendOptRenderLayer(BufferedImage layer, int destX, int destY) {
        android.graphics.Bitmap destinationBmp = surface.image().getBitmap();
        android.graphics.Bitmap sourceBmp = layer.getBitmap();
        int layerWidth = layer.getWidth();
        int layerHeight = layer.getHeight();
        if (layerWidth <= 0 || layerHeight <= 0) {
            return;
        }
        int pixelCount = layerWidth * layerHeight;
        int[] destination = optDestinationPixels;
        if (destination == null || destination.length < pixelCount) {
            destination = new int[pixelCount];
            optDestinationPixels = destination;
        }
        int[] source = optSourcePixels;
        if (source == null || source.length < pixelCount) {
            source = new int[pixelCount];
            optSourcePixels = source;
        }
        // Only fetch/write the layer rectangle. The previous full-width strip copied
        // (and converted) roughly four times more pixels than the layer covered.
        destinationBmp.getPixels(destination, 0, layerWidth, destX, destY, layerWidth, layerHeight);
        sourceBmp.getPixels(source, 0, layerWidth, 0, 0, layerWidth, layerHeight);

        int operator = currentOptRenderOperator();
        int srcRatio = currentOptRenderSourceRatio();
        int dstRatio = currentOptRenderDestinationRatio();
        boolean opaqueReplace = operator == OPT_RENDER_OP_REPL && srcRatio == 255 && dstRatio == 255;

        for (int i = 0; i < pixelCount; i++) {
            int srcArgb = source[i];
            int srcAlpha = srcArgb >>> 24;
            if (srcAlpha == 0) {
                continue;
            }
            if (opaqueReplace && srcAlpha == 255) {
                destination[i] = srcArgb;
                continue;
            }
            int dstArgb = destination[i];
            int uncoveredNumerator = (255 - srcAlpha) * 255;
            int srcNumerator = srcAlpha * srcRatio;
            int dstNumerator = uncoveredNumerator + (operator == OPT_RENDER_OP_REPL ? 0 : srcAlpha * dstRatio);

            int dstRed = (dstArgb >>> 16) & 0xFF;
            int dstGreen = (dstArgb >>> 8) & 0xFF;
            int dstBlue = dstArgb & 0xFF;
            int srcRed = (srcArgb >>> 16) & 0xFF;
            int srcGreen = (srcArgb >>> 8) & 0xFF;
            int srcBlue = srcArgb & 0xFF;

            int outRed;
            int outGreen;
            int outBlue;
            if (operator == OPT_RENDER_OP_SUB) {
                outRed = blendOptRenderChannel(dstRed * dstNumerator - srcRed * srcNumerator);
                outGreen = blendOptRenderChannel(dstGreen * dstNumerator - srcGreen * srcNumerator);
                outBlue = blendOptRenderChannel(dstBlue * dstNumerator - srcBlue * srcNumerator);
            } else {
                outRed = blendOptRenderChannel(dstRed * dstNumerator + srcRed * srcNumerator);
                outGreen = blendOptRenderChannel(dstGreen * dstNumerator + srcGreen * srcNumerator);
                outBlue = blendOptRenderChannel(dstBlue * dstNumerator + srcBlue * srcNumerator);
            }

            int dstAlpha = dstArgb >>> 24;
            int outAlpha;
            if (operator == OPT_RENDER_OP_REPL) {
                outAlpha = (dstAlpha * (255 - srcAlpha) + 255 * srcAlpha + 127) / 255;
            } else {
                outAlpha = Math.max(dstAlpha, srcAlpha);
            }
            destination[i] = (outAlpha << 24) | (outRed << 16) | (outGreen << 8) | outBlue;
        }
        destinationBmp.setPixels(destination, 0, layerWidth, destX, destY, layerWidth, layerHeight);
    }

    private static int blendOptRenderChannel(int numerator) {
        if (numerator <= 0) {
            return 0;
        }
        // 255 * 255 * 255. All intermediate values fit in a signed int.
        if (numerator >= 16_581_375) {
            return 255;
        }
        return (numerator + 32_512) / 65_025;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static Rectangle normalizedRectangle(int x, int y, int width, int height) {
        int left = width >= 0 ? x : x + width;
        int top = height >= 0 ? y : y + height;
        int actualWidth = Math.abs(width);
        int actualHeight = Math.abs(height);
        return new Rectangle(left, top, Math.max(1, actualWidth), Math.max(1, actualHeight));
    }

    private static Rectangle rectangleFromPoints(int x1, int y1, int x2, int y2) {
        int left = Math.min(x1, x2);
        int top = Math.min(y1, y2);
        return new Rectangle(left, top, Math.max(1, Math.abs(x2 - x1) + 1), Math.max(1, Math.abs(y2 - y1) + 1));
    }

    private void flushSurfaceFrame() {
        // `Graphics3D.flush()` is the pass boundary for staged opt draws inside one locked frame.
        // Finish any deferred blended primitive batches before ending the shared depth frame.
        flushPending3DPasses();
        pendingOptRenderedContent = false;
        // Hardware presentation reads the GL framebuffer back into the software surface. That
        // does not make the surface "software dirty"; only later Java2D writes should trigger a
        // re-upload on the next GL pass, especially when the hardware path uses supersampling.
        //
        // For an on-screen canvas, defer that readback: the next 2D primitive runs
        // prepareSoftwareSurfaceMutation() (which reads back lazily), and unlock() reads it back
        // before presenting. Titles such as Kingdom Hearts coded flush 3D twice per frame; doing
        // a full-frame readback at every pass added ~13 ms per pass and halved their frame rate.
        // Offscreen images keep the eager flush because their content may be consumed by
        // Image.renderImage() without an unlock boundary.
        if (!surface.hasRepaintHook()) {
            oglRenderer.flushHardwarePresentation();
        }
        // The lock belongs to the surface, not to this Graphics object. Titles such as
        // Dragon Quest More Mystery Dungeon obtain a separate Graphics3D from
        // Canvas.getGraphics() and render the map while the application holds the frame lock
        // on another Graphics instance. Checking only this instance's lockDepth presented a
        // half-composed frame (3D map without the 2D sprites/dialogue drawn later in the same
        // lock scope), which flickered against the completed frame.
        if (surface.hasActiveGraphicsLock()) {
            // DoJa documents `Graphics3D.flush()` as applying pending 3D results, not as a
            // display-sync boundary. Some titles split one Canvas frame into several opt passes,
            // so syncing every flush would multiply the frame time. Keep the pass boundary
            // semantics here, but leave frame pacing to the eventual Canvas present.
            surface.endDepthFrame();
            return;
        }
        surface.flush(copyImage(surface.image()), false);
    }

    private void flushPending3DPasses() {
        doja3D.flushPendingOptPrimitiveBlends(delegate, surface.image());
    }

    private void finish3DDepthPassOnProjectionDepthModeChange(boolean projectionDepthModeChanged) {
        if (!projectionDepthModeChanged || !pendingOptRenderedContent) {
            return;
        }
        // Perspective and parallel draws encode depth differently. End the current pass
        // so later HUD-style 3D draws keep their pixels but get fresh depth.
        flushPending3DPasses();
        pendingOptRenderedContent = false;
        surface.endDepthFrame();
    }

    private void prepare3DDepthFrame() {
        // Games can submit 3D assets through separate 3D calls inside one
        // lock/unlock frame. They must share one z-buffer or later props ignore ramp depth.
        pendingOptRenderedContent = true;
        doja3D.setFrameDepthBuffer(surface.depthBufferForFrame());
    }

    private DojaGraphics3DRenderer.RenderTarget renderTarget() {
        return new DojaGraphics3DRenderer.RenderTarget(
                delegate,
                surface.image(),
                originX,
                originY,
                surface.width(),
                surface.height());
    }

    private void applyFlipTransform(int dx, int dy, int dw, int dh) {
        applyFlipTransform(delegate, dx, dy, dw, dh);
    }

    private void applyFlipTransform(Graphics2D graphics, int dx, int dy, int dw, int dh) {
        if (flipMode == FLIP_NONE) {
            return;
        }
        graphics.transform(flipTransform(dx, dy, dw, dh));
    }

    private Rectangle flippedBounds(Rectangle bounds, int dx, int dy, int dw, int dh) {
        if (flipMode == FLIP_NONE) {
            return bounds;
        }
        return flipTransform(dx, dy, dw, dh).createTransformedShape(bounds).getBounds();
    }

    private AffineTransform flipTransform(int dx, int dy, int dw, int dh) {
        AffineTransform transform = new AffineTransform();
        switch (flipMode) {
            case FLIP_NONE -> {
            }
            case FLIP_HORIZONTAL -> {
                transform.translate(originX + dx + dw, originY + dy);
                transform.scale(-1, 1);
                transform.translate(-(originX + dx), -(originY + dy));
            }
            case FLIP_VERTICAL -> {
                transform.translate(originX + dx, originY + dy + dh);
                transform.scale(1, -1);
                transform.translate(-(originX + dx), -(originY + dy));
            }
            case FLIP_ROTATE -> {
                transform.rotate(Math.toRadians(180), originX + dx + dw / 2.0, originY + dy + dh / 2.0);
            }
            case FLIP_ROTATE_RIGHT -> {
                transform.translate(originX + dx + dh, originY + dy);
                transform.rotate(Math.toRadians(90));
                transform.translate(-(originX + dx), -(originY + dy));
            }
            case FLIP_ROTATE_LEFT -> {
                transform.translate(originX + dx, originY + dy + dw);
                transform.rotate(Math.toRadians(-90));
                transform.translate(-(originX + dx), -(originY + dy));
            }
            case FLIP_ROTATE_RIGHT_HORIZONTAL -> {
                transform.rotate(Math.toRadians(90), originX + dx + dw / 2.0, originY + dy + dh / 2.0);
                transform.scale(-1, 1);
            }
            case FLIP_ROTATE_RIGHT_VERTICAL -> {
                transform.rotate(Math.toRadians(90), originX + dx + dw / 2.0, originY + dy + dh / 2.0);
                transform.scale(1, -1);
            }
            default -> {
            }
        }
        return transform;
    }

    /**
     * Sets clip Rect For3 D.
     */
    @Override
    public void setClipRectFor3D(int x, int y, int width, int height) {
        try {
            doja3D.setClipRectFor3D(originX, originY, x, y, width, height);
        } catch (RuntimeException e) {
            throw traceFailure("setClipRectFor3D", e);
        }
    }

    /**
     * Sets parallel View.
     */
    @Override
    public void setParallelView(int width, int height) {
        try {
            finish3DDepthPassOnProjectionDepthModeChange(doja3D.setParallelView(width, height));
        } catch (RuntimeException e) {
            throw traceFailure("setParallelView", e);
        }
    }

    /**
     * Sets perspective View.
     */
    @Override
    public void setPerspectiveView(float a, float b, int c, int d) {
        try {
            finish3DDepthPassOnProjectionDepthModeChange(doja3D.setPerspectiveView(a, b, c, d));
        } catch (RuntimeException e) {
            throw traceFailure("setPerspectiveView(float,float,int,int)", e);
        }
    }

    /**
     * Sets perspective View.
     */
    @Override
    public void setPerspectiveView(float a, float b, float c) {
        try {
            finish3DDepthPassOnProjectionDepthModeChange(doja3D.setPerspectiveView(a, b, c));
        } catch (RuntimeException e) {
            throw traceFailure("setPerspectiveView(float,float,float)", e);
        }
    }

    /**
     * Flushes any buffered drawing operations.
     */
    @Override
    public void flushBuffer() {
        try {
            if (TRACE_3D_CALLS) {
                OpenDoJaLog.debug(Graphics.class, "3D call flushBuffer");
            }
            flushSurfaceFrame();
        } catch (RuntimeException e) {
            throw traceFailure("flushBuffer", e);
        }
    }

    /**
     * Sets transform.
     */
    @Override
    public void setTransform(com.nttdocomo.ui.util3d.Transform transform) {
        try {
            doja3D.setTransform(transform);
        } catch (RuntimeException e) {
            throw traceFailure("setTransform", e);
        }
    }

    /**
     * Adds light.
     */
    @Override
    public void addLight(com.nttdocomo.ui.graphics3d.Light light, com.nttdocomo.ui.util3d.Transform transform) {
        try {
            doja3D.addLight(light);
        } catch (RuntimeException e) {
            throw traceFailure("addLight", e);
        }
    }

    /**
     * Resets lights.
     */
    @Override
    public void resetLights() {
        doja3D.resetLights();
    }

    /**
     * Sets fog.
     */
    @Override
    public void setFog(com.nttdocomo.ui.graphics3d.Fog fog) {
        doja3D.setFog(fog);
    }

    /**
     * Renders object3 D.
     */
    @Override
    public void renderObject3D(com.nttdocomo.ui.graphics3d.DrawableObject3D object, com.nttdocomo.ui.util3d.Transform transform) {
        try {
            doja3D.renderObject3D(renderTarget(), object, transform, this::prepare3DDepthFrame);
        } catch (RuntimeException e) {
            throw traceFailure("renderObject3D", e);
        }
    }

    /**
     * Sets view Trans.
     */
    @Override
    public void setViewTrans(com.nttdocomo.opt.ui.j3d.AffineTrans transform) {
        try {
            opt3D.setViewTrans(transform);
        } catch (RuntimeException e) {
            throw traceFailure("setViewTrans", e);
        }
    }

    /**
     * Sets view Trans Array.
     */
    @Override
    public void setViewTransArray(com.nttdocomo.opt.ui.j3d.AffineTrans[] transforms) {
        opt3D.setViewTransArray(transforms);
    }

    /**
     * Sets view Trans.
     */
    @Override
    public void setViewTrans(int index) {
        opt3D.setViewTrans(index);
    }

    /**
     * Sets screen Center.
     */
    @Override
    public void setScreenCenter(int x, int y) {
        try {
            opt3D.setScreenCenter(x, y);
        } catch (RuntimeException e) {
            throw traceFailure("setScreenCenter", e);
        }
    }

    /**
     * Sets screen Scale.
     */
    @Override
    public void setScreenScale(int x, int y) {
        try {
            opt3D.setScreenScale(x, y);
        } catch (RuntimeException e) {
            throw traceFailure("setScreenScale", e);
        }
    }

    /**
     * Sets screen View.
     */
    @Override
    public void setScreenView(int x, int y) {
        try {
            opt3D.setScreenView(x, y);
        } catch (RuntimeException e) {
            throw traceFailure("setScreenView", e);
        }
    }

    /**
     * Sets perspective.
     */
    @Override
    public void setPerspective(int near, int far, int width) {
        try {
            opt3D.setPerspective(near, far, width);
        } catch (RuntimeException e) {
            throw traceFailure("setPerspective(int,int,int)", e);
        }
    }

    /**
     * Sets perspective.
     */
    @Override
    public void setPerspective(int near, int far, int width, int height) {
        try {
            opt3D.setPerspective(near, far, width, height);
        } catch (RuntimeException e) {
            throw traceFailure("setPerspective(int,int,int,int)", e);
        }
    }

    /**
     * Draws figure.
     */
    @Override
    public void drawFigure(com.nttdocomo.opt.ui.j3d.Figure figure) {
        renderFigure(figure);
        flush();
    }

    /**
     * Renders figure.
     */
    @Override
    public void renderFigure(com.nttdocomo.opt.ui.j3d.Figure figure) {
        try {
            opt3D.renderFigure(figure, renderTarget(), this::prepare3DDepthFrame);
        } catch (RuntimeException e) {
            throw traceFailure("renderFigure", e);
        }
    }

    /**
     * Flushes any buffered drawing operations.
     */
    @Override
    public void flush() {
        try {
            if (TRACE_3D_CALLS) {
                OpenDoJaLog.debug(Graphics.class, "3D call flush");
            }
            flushSurfaceFrame();
        } catch (RuntimeException e) {
            throw traceFailure("flush", e);
        }
    }

    /**
     * Enables or disables sphere Map.
     */
    @Override
    public void enableSphereMap(boolean enabled) {
        opt3D.enableSphereMap(enabled);
    }

    /**
     * Sets sphere Texture.
     */
    @Override
    public void setSphereTexture(com.nttdocomo.opt.ui.j3d.Texture texture) {
        opt3D.setSphereTexture(texture);
    }

    /**
     * Enables or disables light.
     */
    @Override
    public void enableLight(boolean enabled) {
        opt3D.enableLight(enabled);
    }

    /**
     * Sets ambient Light.
     */
    @Override
    public void setAmbientLight(int color) {
        opt3D.setAmbientLight(color);
    }

    /**
     * Sets direction Light.
     */
    @Override
    public void setDirectionLight(com.nttdocomo.opt.ui.j3d.Vector3D direction, int color) {
        opt3D.setDirectionLight(direction, color);
    }

    /**
     * Enables or disables semi Transparent.
     */
    @Override
    public void enableSemiTransparent(boolean enabled) {
        opt3D.enableSemiTransparent(enabled);
    }

    /**
     * Sets clip Rect3 D.
     */
    @Override
    public void setClipRect3D(int x, int y, int width, int height) {
        try {
            opt3D.setClipRect3D(x, y, width, height);
        } catch (RuntimeException e) {
            throw traceFailure("setClipRect3D", e);
        }
    }

    private RuntimeException traceFailure(String operation, RuntimeException failure) {
        if (TRACE_FAILURES) {
            OpenDoJaLog.error(Graphics.class, "openDoJa graphics failure in " + operation, failure);
        }
        return failure;
    }

    /**
     * Enables or disables toon Shader.
     */
    @Override
    public void enableToonShader(boolean enabled) {
        opt3D.enableToonShader(enabled);
    }

    /**
     * Sets toon Param.
     */
    @Override
    public void setToonParam(int highlight, int mid, int shadow) {
        opt3D.setToonParam(highlight, mid, shadow);
    }

    /**
     * Sets primitive Texture Array.
     */
    @Override
    public void setPrimitiveTextureArray(com.nttdocomo.opt.ui.j3d.Texture texture) {
        opt3D.setPrimitiveTextureArray(texture);
    }

    /**
     * Sets primitive Texture Array.
     */
    @Override
    public void setPrimitiveTextureArray(com.nttdocomo.opt.ui.j3d.Texture[] textures) {
        opt3D.setPrimitiveTextureArray(textures);
    }

    /**
     * Sets primitive Texture.
     */
    @Override
    public void setPrimitiveTexture(int index) {
        opt3D.setPrimitiveTexture(index);
    }

    /**
     * Renders primitives.
     */
    @Override
    public void renderPrimitives(com.nttdocomo.opt.ui.j3d.PrimitiveArray primitives, int attr) {
        opt3D.renderPrimitives(renderTarget(), primitives, attr, this::prepare3DDepthFrame);
    }

    /**
     * Renders primitives.
     */
    @Override
    public void renderPrimitives(com.nttdocomo.opt.ui.j3d.PrimitiveArray primitives, int start, int count, int attr) {
        opt3D.renderPrimitives(renderTarget(), primitives, start, count, attr, this::prepare3DDepthFrame);
    }

    /**
     * Executes command List.
     */
    @Override
    public void executeCommandList(int[] commands) {
        opt3D.executeCommandList(commands, renderTarget(), this::prepare3DDepthFrame, this::flushSurfaceFrame);
    }


}
