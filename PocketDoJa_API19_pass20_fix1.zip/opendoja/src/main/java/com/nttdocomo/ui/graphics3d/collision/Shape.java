package com.nttdocomo.ui.graphics3d.collision;

import com.nttdocomo.ui.graphics3d.Primitive;
import com.nttdocomo.ui.util3d.Transform;

/**
 * Defines the common interface of collision shapes.
 */
public interface Shape {
    int TYPE_POINT = 1;
    int TYPE_LINE = 2;
    int TYPE_RAY = 3;
    int TYPE_TRIANGLE = 4;
    int TYPE_PLANE = 5;
    int TYPE_SPHERE = 6;
    int TYPE_BOX = 7;
    int TYPE_CYLINDER = 8;
    int TYPE_CAPSULE = 9;
    int TYPE_AAB_BOX = 10;
    int TYPE_AAB_CYLINDER = 11;
    int TYPE_AAB_CAPSULE = 12;

    int TRANS_SHAPE_WORLD = 1;
    int TRANS_SHAPE_WORLD_NOSCALE = 2;
    int TRANS_BV_SHAPE = 4;
    int TRANS_BV_WORLD = 5;
    int TRANS_BV_WORLD_NOSCALE = 6;

    int getShapeType();

    void createMesh(int slice, int stack, float scale);

    Primitive getMesh();

    Transform getMeshTransform(Transform transform);

    void deleteMesh();

    void setTransform(Transform transform);

    Transform getTransform(int type, Transform transform);

    float getScale();

    void setAttribute(Object attribute);

    Object getAttribute();
}
