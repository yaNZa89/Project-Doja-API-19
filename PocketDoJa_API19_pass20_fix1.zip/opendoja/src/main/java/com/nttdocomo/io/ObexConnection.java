package com.nttdocomo.io;

import javax.microedition.io.StreamConnection;

/**
 * Defines an OBEX network connection.
 */
public interface ObexConnection extends StreamConnection {
    int DISCONNECT = 129;
    int PUT = 130;
    int GET = 131;
    int CONTINUE = 16;
    int SUCCESS = 32;
    int CREATED = 33;
    int ACCEPTED = 34;
    int NON_AUTHORITATIVE_INFORMATION = 35;
    int NO_CONTENT = 36;
    int RESET_CONTENT = 37;
    int PARTIAL_CONTENT = 38;
    int MULTIPLE_CHOICES = 48;
    int MOVED_PERMANENTLY = 49;
    int MOVED_TEMPORARILY = 50;
    int SEE_OTHER = 51;
    int NOT_MODIFIED = 52;
    int USE_PROXY = 53;
    int BAD_REQUEST = 64;
    int UNAUTHORIZED = 65;
    int PAYMENT_REQUIRED = 66;
    int FORBIDDEN = 67;
    int NOT_FOUND = 68;
    int METHOD_NOT_ALLOWED = 69;
    int NOT_ACCEPTABLE = 70;
    int PROXY_AUTHENTICATION_REQUIRED = 71;
    int REQUEST_TIME_OUT = 72;
    int CONFLICT = 73;
    int GONE = 74;
    int LENGTH_REQUIRED = 75;
    int PRECONDITION_FAILED = 76;
    int REQUEST_ENTITY_TOO_LARGE = 77;
    int REQUEST_URL_TOO_LARGE = 78;
    int UNSUPPORTED_MEDIA_TYPE = 79;
    int INTERNAL_SERVER_ERROR = 80;
    int NOT_IMPLEMENTED = 81;
    int BAD_GATEWAY = 82;
    int SERVICE_UNAVAILABLE = 83;
    int GATEWAY_TIMEOUT = 84;
    int HTTP_VERSION_NOT_SUPPORTED = 85;
    int DATABASE_FULL = 96;
    int DATABASE_LOCKED = 97;
    int COMM_MODE_IRDA = 0;
    int COMM_MODE_IRSIMPLE_UNILATERALLY = 1;
    int COMM_MODE_IRSIMPLE_INTERACTIVE = 2;

    int getContentLength();

    void setName(String name);

    String getName();

    void setType(String type);

    String getType();

    void setTime(long time);

    long getTime();

    int getCommMode();
}
