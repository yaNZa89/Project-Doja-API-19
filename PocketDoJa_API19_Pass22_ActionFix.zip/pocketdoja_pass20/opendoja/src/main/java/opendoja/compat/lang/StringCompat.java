package opendoja.compat.lang;

/** Small java.lang.String compatibility helpers for legacy Android runtimes. */
public final class StringCompat {
    private StringCompat() {
    }

    /** Equivalent to String.isBlank(), which Android only added at API 33. */
    public static boolean isBlank(String value) {
        if (value == null || value.length() == 0) {
            return true;
        }
        for (int i = 0; i < value.length(); i++) {
            if (!Character.isWhitespace(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /** Equivalent to String.repeat(), available on Android only on newer releases. */
    public static String repeat(String value, int count) {
        if (value == null) {
            throw new NullPointerException("value");
        }
        if (count < 0) {
            throw new IllegalArgumentException("count is negative: " + count);
        }
        if (count == 0 || value.length() == 0) {
            return "";
        }
        long totalLength = (long) value.length() * count;
        if (totalLength > Integer.MAX_VALUE) {
            throw new OutOfMemoryError("required string size too large");
        }
        StringBuilder result = new StringBuilder((int) totalLength);
        for (int i = 0; i < count; i++) {
            result.append(value);
        }
        return result.toString();
    }

    /** String.join-compatible helper for iterable values. */
    public static String join(CharSequence delimiter, Iterable<?> values) {
        if (delimiter == null || values == null) {
            throw new NullPointerException();
        }
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Object value : values) {
            if (value == null) {
                throw new NullPointerException("element");
            }
            if (!first) {
                result.append(delimiter);
            }
            result.append(value);
            first = false;
        }
        return result.toString();
    }

    /** String.join-compatible helper for arrays. */
    public static String join(CharSequence delimiter, Object[] values) {
        if (delimiter == null || values == null) {
            throw new NullPointerException();
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (values[i] == null) {
                throw new NullPointerException("element");
            }
            if (i > 0) {
                result.append(delimiter);
            }
            result.append(values[i]);
        }
        return result.toString();
    }
}
