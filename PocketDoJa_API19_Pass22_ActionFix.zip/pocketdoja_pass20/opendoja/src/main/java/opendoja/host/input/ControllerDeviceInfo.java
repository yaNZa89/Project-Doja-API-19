package opendoja.host.input;

public record ControllerDeviceInfo(String id, String name, String productName) {
    public ControllerDeviceInfo {
        id = normalize(id);
        name = normalize(name);
        productName = normalize(productName);
    }

    public String displayName() {
        if (!opendoja.compat.lang.StringCompat.isBlank(productName) && !productName.equals(name)) {
            return productName + " (" + name + ")";
        }
        return !opendoja.compat.lang.StringCompat.isBlank(name) ? name : (!opendoja.compat.lang.StringCompat.isBlank(productName) ? productName : "Controller");
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim();
    }
}
