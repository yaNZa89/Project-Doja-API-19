# PocketDoJa Android 4.4 — Pass 22: fix latest Actions D8 input error

Date: 2026-11-22

## Evidence from latest Actions screenshot

The latest Actions screenshot reports `Unsupported source file type` from the Android R8/D8 toolchain. In the manual build script, the D8 command passed `$OUT_DIR/classes` directly as an input. That path is a directory, not a supported class/JAR/ZIP input. This is the concrete mismatch matching the reported error.

## Change made

- Keep the existing manual AAPT2 / javac / D8 / L8 / zipalign / apksigner workflow.
- After javac and resource copying, package the compiled output directory into `build-manual/deps/pocketdoja-app-classes.jar` using the JDK `jar` command.
- Pass that JAR to D8 instead of passing the raw classes directory.
- Add an explicit `jar` prerequisite check.
- Leave the original Monster Hunter JAM/JAR/SP assets and Android API 19 target unchanged.

## Local validation

- `bash -n tools/build-api19-manual.sh`: PASS.
- `bash -n` for every shell script in `tools/` and `porting-tests/`: PASS.
- `python3 porting-tests/check-api19-source.py`: PASS (1,169 shipped Java source files scanned).
- Full Android APK build: NOT RUN in this workspace because Android SDK Build Tools / platform SDK are not installed here. Therefore this ZIP is a source/build-fix package, not a completed APK.

## Next remote check

Run the existing workflow `PocketDoJa Android 4.4 manual toolchain build (no Gradle)` against this source. The expected D8 input-type failure should be cleared; any later compiler, L8, packaging, or API 19 verifier failure must be handled from the new log rather than guessed in advance.
