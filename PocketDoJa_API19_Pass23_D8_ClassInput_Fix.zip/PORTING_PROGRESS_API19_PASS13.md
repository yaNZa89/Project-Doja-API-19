# PocketDoJa API 19 — Pass 13

## Perubahan nyata

- Memindahkan 6 VectorDrawable dari `res/drawable/` ke `res/drawable-v21/`.
- Membuat fallback PNG untuk setiap ikon pada mdpi, hdpi, xhdpi, xxhdpi, dan xxxhdpi.
- Memperluas `porting-tests/check-api19-source.py` agar build CI gagal jika VectorDrawable berada di folder tanpa qualifier API atau tidak memiliki fallback PNG mdpi.
- Menambahkan `FREEJ2ME_PLUS_ADAPTATION_NOTES.md` yang membedakan fitur upstream yang sudah diverifikasi dari hal yang belum diintegrasikan.

## Mengapa perubahan resource diperlukan

Android 4.4 tidak memiliki dukungan native VectorDrawable; API native-nya baru tersedia mulai API 21. Ikon sebelumnya berada langsung di `res/drawable/` dan dipanggil melalui `Resources.getDrawable()`, sehingga ada risiko resource gagal dimuat pada API 19. Sekarang API 19 memilih PNG fallback, sedangkan Android 5.0+ tetap memakai XML vector di `drawable-v21`.

## Pemeriksaan lokal

| Pemeriksaan | Hasil |
|---|---|
| Python syntax untuk preflight | LULUS |
| API 19 source preflight | LULUS — 1.169 file Java |
| VectorDrawable API 21+ | 6 dipindah ke `drawable-v21` |
| Fallback PNG | 30 file (6 ikon × 5 density) |
| Semua PNG dapat dibaca dan ukuran sesuai density | LULUS |
| File XML resource | Valid secara XML |
| NIO desugaring API 19 | Didukung menurut dokumentasi Android; tetap perlu uji perangkat |
| Build Gradle APK | BELUM DIJALANKAN — Gradle/SDK tidak tersedia di workspace |
| Install/launch Android 4.4 | BELUM DIUJI |
| Gameplay Monster Hunter i | BELUM DIUJI |

## Koreksi temuan NIO sebelumnya

Pernyataan audit awal bahwa `java.nio.file` tidak dapat digunakan di API 19 terlalu luas dan perlu dianggap superseded. Android mendokumentasikan NIO desugaring melalui `desugar_jdk_libs_nio`, yang mengemulasikan API tersebut pada perangkat di bawah API 26. Ada batasan fitur tertentu (misalnya AsynchronousFileChannel, watch service, dan atribut POSIX); pemeriksaan source runtime saat ini tidak menemukan penggunaan fitur-fitur tersebut. Ini tetap bukan pengganti uji runtime.

## FreeJ2ME-Plus

README upstream memverifikasi konfigurasi DoJa 5.0 (`dojaversion=50`), parameter scratchpad `.sp`, serta renderer MascotCapsuleV3 yang disebut MIT. Namun frontend upstream adalah AWT/Libretro, bukan Android. Maka proyek ini tetap memakai PocketDoJa sebagai basis Android; FreeJ2ME-Plus menjadi referensi untuk audit renderer dan scratchpad, bukan pengganti langsung.

## Status dan langkah berikutnya

Masalah resource vector API 19 sudah diperbaiki pada source. Penghambat terbesar berikutnya tetap memperoleh build APK nyata dari CI. Setelah build tersedia, jalankan APK pada emulator/perangkat API 19, uji membuka aplikasi, impor JAM/JAR/SP, masuk ke layar awal game, kontrol, render 3D, dan audio.
