# PocketDoJa 1.3.0a — Android 4.4 porting pass 09

## Fokus

Memperbaiki kesiapan skrip uji perangkat API 19 dan mengulang pengujian host
terhadap paket Monster Hunter i for SH yang diberikan pengguna. Fokus porting
adalah aplikasi/mesin PocketDoJa; isi game tetap memakai JAM/JAR/SP asli.

## Pemeriksaan konfigurasi Android yang ada

Source pass08 yang diperiksa sudah memiliki:

- `minSdk 19` pada modul `app` dan `dexlib`.
- `multiDexEnabled true` pada aplikasi untuk runtime Dalvik API 19.
- `androidx.multidex.MultiDexApplication` pada manifest.
- `targetSdk 30`.
- Core-library desugaring melalui `desugar_jdk_libs_nio:2.1.4`.

Catatan: laporan audit awal yang menyebut `minSdk 24` sudah tidak menggambarkan
source pass08. Angka itu berasal dari pemeriksaan source sebelum perubahan API
19. Konfigurasi minSdk 19 sendiri belum membuktikan runtime berhasil pada API 19.

## Perubahan yang dibuat pada pass09

1. `run-api19-device-test.sh` sekarang menjalankan Gradle wrapper melalui
   `bash "$GRADLEW"`, sehingga tidak bergantung pada executable bit yang bisa
   hilang saat arsip ZIP diekstrak.
2. Skrip memeriksa ketersediaan `adb`, `ANDROID_HOME`/`ANDROID_SDK_ROOT`, dan
   Android SDK platform 34 sebelum memulai build/perangkat.
3. Bit executable `gradlew` ditandai aktif pada source tree untuk shell/Linux.
4. Shell syntax diperiksa dengan `bash -n` dan lulus.
5. Jalur guard prasyarat dijalankan tanpa ADB/SDK; skrip berhenti dengan pesan
   prasyarat yang jelas, bukan menunggu perangkat tanpa batas.

## Pengujian ulang terhadap game asli

Memakai `/mnt/data/mhi_9.jam` dan `/mnt/data/mhi_9.jar`:

- JAM/JAR static launch preflight: PASS.
- Metadata terdeteksi: DoJa-5.0, SH904i, 240x320, AppClass `main`.
- 5 class game dibaca; class-file major tertinggi 45.
- 27 referensi kelas API DoJa ditemukan dan seluruh 27 ada pada source.
- 12 nama resource yang diperiksa semuanya ada di JAR.
- `tdata.dat`: 57 record tervalidasi.
- MBAC: 18/18; MTRA: 10/10.
- Pasangan model/action: 10 cocok, 0 mismatch.
- 73 action dan 895 frame animasi dievaluasi tanpa exception.
- JAR→DEX: DEX 035, 5 class, 12 resource; signature SHA-1 dan checksum
  Adler-32 valid.

Pengujian tersebut host-side. Ini bukan pengujian emulator Android atau bukti
bahwa game sudah menampilkan title screen di Dalvik.

## Hambatan build/runtime yang masih ada

- Gradle 8.13 belum tersedia dalam cache; wrapper gagal mengunduh dari
  `services.gradle.org` karena DNS/jaringan tidak tersedia pada lingkungan ini.
- Android SDK platform/build-tools dan `adb` tidak tersedia.
- Karena itu `:app:assembleDebug` belum berhasil dijalankan.
- Belum ada instalasi APK, Dalvik `DexClassLoader`, title/menu frame, input,
  maupun audio yang diuji pada Android 4.4.

## Kesimpulan

Pass09 memperbaiki skrip uji perangkat dan mengonfirmasi ulang pipeline host
untuk paket game asli. Belum ada APK Android yang dihasilkan. Langkah penentu
berikutnya tetap build APK dengan Gradle 8.13 + Android SDK 34, lalu jalankan
skrip ini pada perangkat/emulator API 19.
