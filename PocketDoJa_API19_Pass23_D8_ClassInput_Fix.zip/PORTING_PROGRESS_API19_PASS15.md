# Pass 15 — fokus satu APK Legacy Android 4.4

Tanggal: 2026-11-20

## Koreksi arah

Sesuai arahan pengguna, proyek hanya menghasilkan satu aplikasi PocketDoJa Legacy untuk Android 4.4/API 19. Tidak ada varian Modern, aplikasi kedua, atau pemisahan produk. Basis tetap source PocketDoJa 1.3.0a yang sedang diadaptasi; bukan emulator baru.

## Perubahan

- Menghapus product flavors `legacy` dan `modern` dari konfigurasi Gradle.
- Mengunci `defaultConfig.minSdk` pada API 19 dan memberi nama versi `1.3.0a-api19`.
- Workflow CI kini hanya menjalankan lint/build satu APK debug dan memverifikasi minSdk 19.
- File game JAM/JAR/SP tidak dimasukkan ke proses modifikasi dan tidak disentuh.

## Batas pengujian

Perubahan konfigurasi dan workflow diverifikasi secara statis. APK belum dibangun di lingkungan ini karena Gradle wrapper memerlukan unduhan distribusi yang sebelumnya gagal akibat DNS; SDK Android dan perangkat/ emulator Android 4.4 juga belum tersedia untuk uji instalasi/gameplay.

## Hasil pemeriksaan

- `python3 -m py_compile porting-tests/check-api19-source.py porting-tests/verify-api19-apk.py`: PASS.
- `python3 porting-tests/check-api19-source.py`: PASS; 1.169 file Java runtime diperiksa, enam VectorDrawable versi API 21 memiliki fallback PNG API 19, dan audit mencatat 184 referensi NIO, 38 factory collection, 8 Base64, serta 116 deklarasi record.
- Percobaan `./gradlew --no-daemon :app:assembleDebug`: BLOCKED sebelum konfigurasi Gradle karena wrapper tidak dapat mengunduh Gradle 8.13 (`UnknownHostException: services.gradle.org`). APK belum dihasilkan.
- SHA-256 JAM/JAR/SP dicatat di `PocketDoJa_API19_pass15_game_files.sha256` di luar arsip source; file game tidak dimodifikasi.

Pass 14 multi-flavor sebelumnya dibatalkan dan digantikan oleh konfigurasi satu APK Legacy ini.
