package opendoja.android;

import android.content.Context;
import android.os.Build;

import java.io.File;

/** Returns a writable optimized-code cache on both legacy and modern Android. */
final class CodeCacheCompat {
    private CodeCacheCompat() {
    }

    static File getCodeCacheDir(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("context == null");
        }
        if (Build.VERSION.SDK_INT >= 21) {
            return Api21.getCodeCacheDir(context);
        }
        return context.getCacheDir();
    }

    private static final class Api21 {
        static File getCodeCacheDir(Context context) {
            return context.getCodeCacheDir();
        }
    }
}
