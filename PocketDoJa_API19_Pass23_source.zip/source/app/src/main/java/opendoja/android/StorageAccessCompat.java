package opendoja.android;

import android.app.Activity;
import android.os.Build;

/** API-isolated storage permission helpers for Android 4.4 compatibility. */
final class StorageAccessCompat {
    private StorageAccessCompat() {
    }

    static boolean hasAllFilesAccess() {
        return Build.VERSION.SDK_INT >= 30 && Api30.isExternalStorageManager();
    }

    static boolean hasReadExternalStoragePermission(Activity activity) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        return Api23.hasReadPermission(activity);
    }

    static void requestReadExternalStoragePermission(Activity activity, int requestCode) {
        if (Build.VERSION.SDK_INT >= 23) {
            Api23.requestReadPermission(activity, requestCode);
        }
    }

    private static final class Api30 {
        static boolean isExternalStorageManager() {
            return android.os.Environment.isExternalStorageManager();
        }
    }

    private static final class Api23 {
        static boolean hasReadPermission(Activity activity) {
            return activity.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }

        static void requestReadPermission(Activity activity, int requestCode) {
            activity.requestPermissions(
                    new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, requestCode);
        }
    }
}
