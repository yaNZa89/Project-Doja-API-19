package opendoja.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import opendoja.host.device.DoJaVibrationSupport;

/**
 * Haptic feedback.
 */
final class ButtonHaptics {
    /** SharedPreferences key for the 0-100 touch-haptic intensity. */
    static final String PREF_KEY = "hapticIntensity";
    static final int DEFAULT_INTENSITY = 15;

    // Long enough for the motor to spin up and be clearly felt. Short 10-20 ms
    // pulses are almost imperceptible on many phones.
    private static final int MIN_TICK_MS = 30;
    private static final int MAX_TICK_MS = 90;
    /** Amplitude floor so low slider values still produce a felt tick. */
    private static final int MIN_AMPLITUDE = 100;
    /** Avoids buzzing continuously while a finger slides across the keypad. */
    private static final long MIN_INTERVAL_MS = 30L;

    private static Vibrator vibrator;
    private static long lastTickMs;

    private ButtonHaptics() {
    }

    /** Reads the configured intensity (0 = off, 100 = strongest). */
    static int intensity(Context context) {
        if (context == null) {
            return DEFAULT_INTENSITY;
        }
        SharedPreferences prefs = context.getSharedPreferences(
                DisplayActivity.PREFS_NAME, Context.MODE_PRIVATE);
        return clamp(prefs.getInt(PREF_KEY, DEFAULT_INTENSITY), 0, 100);
    }

    /** Plays one tick at the configured intensity. */
    static void tick(Context context) {
        tick(context, intensity(context));
    }

    /** Plays one tick at an explicit intensity (used by the settings preview). */
    static void tick(Context context, int intensityPercent) {
        if (context == null) {
            return;
        }
        int percent = clamp(intensityPercent, 0, 100);
        if (percent == 0) {
            return;
        }
        // A game-requested vibration owns the motor. Replacing it with a tick
        // would stop the title's vibration until it sends its next ON request.
        try {
            if (DoJaVibrationSupport.isActive()) {
                return;
            }
        } catch (Throwable ignored) {
            // Host helper unavailable (desktop build): still allow UI ticks.
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastTickMs < MIN_INTERVAL_MS) {
            return;
        }
        lastTickMs = now;

        Vibrator device = vibrator(context);
        if (device == null) {
            return;
        }
        int durationMs = MIN_TICK_MS
                + Math.round((MAX_TICK_MS - MIN_TICK_MS) * percent / 100f);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Api26VibrationCompat.vibrate(device, durationMs, percent, MIN_AMPLITUDE);
            } else {
                device.vibrate(durationMs);
            }
        } catch (Throwable ignored) {
            // Haptics are best-effort; never break input.
        }
    }

    private static Vibrator vibrator(Context context) {
        if (vibrator != null) {
            return vibrator;
        }
        try {
            Context app = context.getApplicationContext();
            Context resolved = app != null ? app : context;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                vibrator = Api31VibratorCompat.getDefault(resolved);
            } else {
                vibrator = (Vibrator) resolved.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null && !vibrator.hasVibrator()) {
                vibrator = null;
            }
        } catch (Throwable ignored) {
            vibrator = null;
        }
        return vibrator;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
    /** API 26-only vibration methods; kept out of the API 19 verifier path. */
    private static final class Api26VibrationCompat {
        static void vibrate(Vibrator device, int durationMs, int percent, int minimumAmplitude) {
            if (device.hasAmplitudeControl()) {
                float t = percent / 100f;
                int amplitude = Math.round(minimumAmplitude
                        + (255f - minimumAmplitude) * (float) Math.pow(t, 0.6));
                device.vibrate(VibrationEffect.createOneShot(durationMs, amplitude));
            } else {
                device.vibrate(VibrationEffect.createOneShot(durationMs,
                        VibrationEffect.DEFAULT_AMPLITUDE));
            }
        }
    }

    /** API 31-only VibratorManager access. */
    private static final class Api31VibratorCompat {
        static Vibrator getDefault(Context context) {
            VibratorManager manager = (VibratorManager) context.getSystemService(
                    Context.VIBRATOR_MANAGER_SERVICE);
            return manager != null ? manager.getDefaultVibrator() : null;
        }
    }

}
