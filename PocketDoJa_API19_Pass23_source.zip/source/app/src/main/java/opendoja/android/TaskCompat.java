package opendoja.android;

import android.app.Activity;
import android.os.Build;

/** Isolates ActivityManager.AppTask, which was added in API 21. */
final class TaskCompat {
    private TaskCompat() {
    }

    static void finishAllTasks(Activity activity) {
        if (Build.VERSION.SDK_INT >= 21) {
            Api21.finishAllTasks(activity);
        } else {
            activity.finishAffinity();
        }
    }

    private static final class Api21 {
        static void finishAllTasks(Activity activity) {
            android.app.ActivityManager manager = (android.app.ActivityManager)
                    activity.getSystemService(Activity.ACTIVITY_SERVICE);
            if (manager != null) {
                for (android.app.ActivityManager.AppTask task : manager.getAppTasks()) {
                    try {
                        task.finishAndRemoveTask();
                    } catch (Exception ignored) {
                    }
                }
            }
            activity.finishAndRemoveTask();
        }
    }
}
