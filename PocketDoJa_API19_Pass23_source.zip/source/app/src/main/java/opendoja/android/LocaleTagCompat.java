package opendoja.android;

import java.util.Locale;

/**
 * Locale language-tag parser with an Android 4.4-compatible fallback.
 * Locale.forLanguageTag() was added in Android API 21, so keep that call in
 * a nested class that is only reached on API 21 and newer.
 */
final class LocaleTagCompat {
    private LocaleTagCompat() {
    }

    static Locale forLanguageTag(String languageTag, int sdkInt) {
        if (languageTag == null) {
            return Locale.getDefault();
        }
        String normalized = languageTag.trim().replace('_', '-');
        if (normalized.isEmpty()) {
            return Locale.getDefault();
        }
        if (sdkInt >= 21) {
            return Api21.forLanguageTag(normalized);
        }
        return legacyLocale(normalized);
    }

    private static Locale legacyLocale(String tag) {
        // The app's configured tags are simple BCP-47 language and optional
        // region pairs (for example "zh-CN" and "pt-BR"). Preserve a
        // possible remaining variant in the three-argument Locale constructor.
        String[] parts = tag.split("-");
        if (parts.length == 0 || parts[0].isEmpty()) {
            return Locale.getDefault();
        }
        String language = parts[0].toLowerCase(Locale.US);
        String country = "";
        StringBuilder variant = new StringBuilder();
        int next = 1;
        if (parts.length > 1 && isRegion(parts[1])) {
            country = parts[1].toUpperCase(Locale.US);
            next = 2;
        }
        for (int i = next; i < parts.length; i++) {
            if (variant.length() > 0) {
                variant.append('_');
            }
            variant.append(parts[i]);
        }
        return new Locale(language, country, variant.toString());
    }

    private static boolean isRegion(String value) {
        if (value.length() == 2) {
            return Character.isLetter(value.charAt(0)) && Character.isLetter(value.charAt(1));
        }
        if (value.length() == 3) {
            return Character.isDigit(value.charAt(0))
                    && Character.isDigit(value.charAt(1))
                    && Character.isDigit(value.charAt(2));
        }
        return false;
    }

    private static final class Api21 {
        static Locale forLanguageTag(String tag) {
            return Locale.forLanguageTag(tag);
        }
    }
}
