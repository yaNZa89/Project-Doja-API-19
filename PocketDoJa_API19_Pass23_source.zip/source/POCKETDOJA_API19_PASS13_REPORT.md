# Laporan Pass 13 — PocketDoJa Android 4.4

## Perubahan

1. Enam ikon VectorDrawable dipindahkan dari `drawable/` ke `drawable-v21/`.
2. Ditambahkan 30 fallback PNG (6 ikon pada lima tingkat density) agar Android 4.4 tidak mencoba memuat native VectorDrawable.
3. Preflight CI diperluas untuk mendeteksi vector drawable yang tidak kompatibel dengan API 19 atau kehilangan PNG fallback.
4. Ditambahkan catatan strategi FreeJ2ME-Plus berdasarkan README dan LICENSE upstream serta source PocketDoJa lokal.

## Hasil yang bisa diverifikasi

- `python3 -m py_compile porting-tests/check-api19-source.py`: PASS.
- `python3 porting-tests/check-api19-source.py`: PASS; 1.169 file Java runtime diperiksa.
- 6 vector XML sekarang hanya di `drawable-v21`.
- 30 PNG fallback dibuat; ukuran masing-masing 24, 36, 48, 72, dan 96 px sesuai mdpi sampai xxxhdpi.
- Semua XML resource berhasil diparse dan semua PNG dapat dibaca.
- `mhi_9.jam`, `mhi_9.jar`, dan `mhi_9.sp` tidak diubah.

## FreeJ2ME-Plus: keputusan

Upstream README menyatakan `dojaversion=50` untuk DoJa 5.0, parameter scratchpad `sp=...`, dan renderer MascotCapsuleV3 dari Roman Lahin/MascotME sebagai MIT. Tetapi FreeJ2ME-Plus sendiri menyediakan frontend AWT/Libretro dan build Ant, bukan Android Activity. Core utamanya GPLv3. Karena itu, tidak aman/efisien untuk menyalin seluruh runtime ke PocketDoJa; gunakan renderer MIT yang terpisah hanya bila audit file dan uji komparatif membuktikan perlu.

## Belum terbukti

- Build APK dengan Gradle.
- APK dapat dipasang/dibuka di Android 4.4.
- Monster Hunter i berhasil masuk gameplay.
- Render 3D, kontrol, audio, dan penyimpanan berjalan benar.

Workspace ini tidak memiliki Gradle terpasang, Android SDK, `android.jar`, atau `adb`; wrapper Gradle 8.13 sebelumnya gagal mengunduh karena DNS `services.gradle.org` tidak dapat di-resolve.

## File utama

- `PORTING_PROGRESS_API19_PASS13.md`
- `FREEJ2ME_PLUS_ADAPTATION_NOTES.md`
- `porting-tests/check-api19-source.py`
- `app/src/main/res/drawable-v21/`
- `app/src/main/res/drawable-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/`
