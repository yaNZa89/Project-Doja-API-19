# PocketDoJa 1.3.0a — API 19 porting pass 02

## Changes applied in this pass

### 1. Android 4.4 minimum SDK and multidex
- Changed `app` module `minSdk` from 24 to 19.
- Changed `dexlib` library `minSdk` from 24 to 19 so manifest merging does not raise the app minimum.
- Enabled `multiDexEnabled true` for Dalvik devices (API 19–20).
- Added `androidx.multidex:multidex:2.0.1` and set `MultiDexApplication` in the manifest.
- Enabled AndroidX in `gradle.properties`.

### 2. Java API compatibility
- Added `opendoja.compat.lang.StringCompat`.
- Replaced 119 runtime/source calls to `String.isBlank()` because Android's platform `String.isBlank()` is API 33, not available on Android 4.4.
- Replaced `String.repeat()` and `String.join()` call sites with compatibility helpers.
- Replaced `Collection.toArray(IntFunction)` usages with the older typed-array overload; the Android desugaring support table marks the IntFunction overload as unsupported at all minSdk levels.
- Replaced one `Objects.checkFromIndexSize()` call with an equivalent explicit bounds check.

### 3. Android framework API fallbacks
- Kept the existing API 19 drawable/touch-feedback fallbacks from pass 01.
- Added a legacy `SoundPool(int, streamType, 0)` path for API 19–20; API 21+ builder usage is isolated in a nested helper.
- Added a legacy `AudioTrack` constructor path for API 19–22; API 23+ `AudioTrack.Builder`, `AudioAttributes`, `AudioFormat.Builder`, and `WRITE_BLOCKING` references are isolated in a nested helper.
- Isolated API 26 vibration and API 31 `VibratorManager` references in nested helpers so old Dalvik does not need to load those newer framework classes.
- Guarded `PendingIntent.FLAG_IMMUTABLE` so it is only passed on API 23+.

## NIO desugaring correction

The previous pass report treated `java.nio.file` desugaring as not yet proven below API 24. The Android Developers documentation for `desugar_jdk_libs_nio` explicitly states that `java.nio.file` is emulated below API 26 using older `java.io`/`java.nio` facilities, including devices below Android 7. The project already declares `desugar_jdk_libs_nio:2.1.4`; API 19 also requires multidex, now configured above.

Known NIO limitations below API 26 include asynchronous file channels, POSIX ownership/permission features, watch services, and certain symbolic-link operations. The runtime source scan did not find use of those specific unsupported facilities, but a full runtime test is still required.

## Validation performed

- `StringCompat` compiled with the installed JDK 21.
- Smoke tests passed for blank detection, repeat, and iterable/array joining.
- Static source scans confirmed no remaining runtime uses of `String.isBlank`, `String.repeat`, `String.join`, `Objects.checkFromIndexSize`, or `Collection.toArray(IntFunction)` in the included app/runtime source set.
- Gradle build was attempted, but the wrapper could not download Gradle 8.13 because this environment could not resolve `services.gradle.org` (`UnknownHostException`).
- No Android SDK (`android.jar`, `aapt`, `d8`, or `adb`) is installed in this environment.

## Current status

This is a source-level API 19 compatibility pass. **No APK has been built, installed, or tested on Android 4.4.** The minSdk is now configured as 19, but the project is not yet certified API 19 compatible. Remaining work is a complete Android API audit, a successful Gradle/SDK build, and installation/runtime testing on an API 19 emulator or physical device.
