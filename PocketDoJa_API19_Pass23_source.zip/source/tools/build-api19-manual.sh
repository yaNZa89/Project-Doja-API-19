#!/usr/bin/env bash
# Gradle-independent PocketDoJa APK builder.
# Uses Android SDK command-line tools directly: aapt2, javac, D8, zipalign, apksigner.
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
BUILD_TOOLS_VERSION="${BUILD_TOOLS_VERSION:-35.0.0}"
PLATFORM_VERSION="${PLATFORM_VERSION:-android-34}"
DEPS_DIR="${POCKETDOJA_DEPS_DIR:-$ROOT/.build-deps}"
OUT_DIR="${POCKETDOJA_OUT_DIR:-$ROOT/build-manual}"

fail() { echo "ERROR: $*" >&2; exit 2; }
need_file() { [[ -f "$1" ]] || fail "Missing file: $1"; }
need_exec() { [[ -x "$1" ]] || fail "Missing executable: $1"; }

[[ -n "$ANDROID_HOME" ]] || fail "Set ANDROID_HOME or ANDROID_SDK_ROOT to an installed Android SDK."
BT="$ANDROID_HOME/build-tools/$BUILD_TOOLS_VERSION"
PLATFORM="$ANDROID_HOME/platforms/$PLATFORM_VERSION"
AAPT2="$BT/aapt2"
AAPT="$BT/aapt"
D8="$BT/d8"
R8_TOOL_JAR="$BT/lib/d8.jar"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"
ANDROID_JAR="$PLATFORM/android.jar"
for f in "$AAPT2" "$AAPT" "$D8" "$R8_TOOL_JAR" "$ZIPALIGN" "$APKSIGNER" "$ANDROID_JAR"; do need_file "$f"; done
for f in "$AAPT2" "$D8" "$ZIPALIGN" "$APKSIGNER"; do need_exec "$f"; done
command -v javac >/dev/null || fail "JDK javac is required (JDK 17 recommended)."
command -v java >/dev/null || fail "JDK java is required to run L8."
command -v keytool >/dev/null || fail "JDK keytool is required to create the debug keystore."
command -v zip >/dev/null || fail "zip is required."
command -v unzip >/dev/null || fail "unzip is required."

ASM_JAR="${POCKETDOJA_ASM_JAR:-$DEPS_DIR/asm-9.6.jar}"
MULTIDEX_AAR="${POCKETDOJA_MULTIDEX_AAR:-$DEPS_DIR/multidex-2.0.1.aar}"
DESUGAR_JAR="${POCKETDOJA_DESUGAR_LIB_JAR:-$DEPS_DIR/desugar_jdk_libs_nio-2.1.4.jar}"
DESUGAR_CONFIG="${POCKETDOJA_DESUGAR_CONFIG:-$DEPS_DIR/desugar_jdk_libs_configuration_nio-2.1.4.json}"
need_file "$ASM_JAR"
need_file "$MULTIDEX_AAR"
need_file "$DESUGAR_JAR"
need_file "$DESUGAR_CONFIG"

APP="$ROOT/app/src/main"
[[ -f "$APP/AndroidManifest.xml" ]] || fail "App manifest not found."
[[ -d "$APP/res" ]] || fail "App resources not found."
[[ -d "$APP/assets" ]] || fail "App assets not found."

rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR/gen" "$OUT_DIR/classes" "$OUT_DIR/dex" "$OUT_DIR/pkg" "$OUT_DIR/deps"
MULTIDEX_CLASSES="$OUT_DIR/deps/multidex-classes.jar"
unzip -p "$MULTIDEX_AAR" classes.jar > "$MULTIDEX_CLASSES"
[[ -s "$MULTIDEX_CLASSES" ]] || fail "Could not extract classes.jar from AndroidX multidex AAR."

# 1. Compile Android resources and generate opendoja.android.R.
"$AAPT2" compile --dir "$APP/res" -o "$OUT_DIR/compiled-res.zip"
"$AAPT2" link \
  -o "$OUT_DIR/resources-unsigned.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$APP/AndroidManifest.xml" \
  --java "$OUT_DIR/gen" \
  --custom-package opendoja.android \
  --rename-manifest-package com.shibesan.pocketdoja \
  --min-sdk-version 19 \
  --target-sdk-version 30 \
  --version-code 4 \
  --version-name 1.3.0a-api19 \
  --auto-add-overlay \
  -A "$APP/assets" \
  -R "$OUT_DIR/compiled-res.zip"

# 2. Compile only the Android source set used by the existing Gradle project.
find "$ROOT/opendoja/src/main/java" "$ROOT/app/src/main/java" "$ROOT/dexlib/src/main/java" \
  -type f -name '*.java' \
  ! -path '*/opendoja/launcher/*' \
  ! -path '*/opendoja/probes/*' \
  ! -path '*/opendoja/tools/*' \
  ! -name 'ControllerInputManagerProbe.java' \
  | sort > "$OUT_DIR/java-sources.txt"
find "$OUT_DIR/gen" -type f -name '*.java' | sort >> "$OUT_DIR/java-sources.txt"
CP="$ANDROID_JAR:$ASM_JAR:$MULTIDEX_CLASSES"
javac -encoding UTF-8 -source 17 -target 17 -Xmaxerrs 10000 \
  -classpath "$CP" -d "$OUT_DIR/classes" @"$OUT_DIR/java-sources.txt"
if [[ -d "$ROOT/opendoja/src/main/resources" ]]; then
  cp -a "$ROOT/opendoja/src/main/resources/." "$OUT_DIR/classes/"
fi

# Android 4.4 starts with Dalvik. These keep rules ask D8 to calculate the
# primary-DEX closure for the Application and every manifest Activity.
cat > "$OUT_DIR/main-dex-rules.pro" <<'RULES'
-keep class androidx.multidex.** { *; }
-keep class opendoja.android.** { *; }
-keep class opendoja.android.HomeActivity { *; }
-keep class opendoja.android.EntryActivity { *; }
-keep class opendoja.android.KeyMappingActivity { *; }
-keep class opendoja.android.DisplayActivity { *; }
-keep class opendoja.android.ThemeActivity { *; }
RULES
"$D8" \
  --min-api 19 \
  --lib "$ANDROID_JAR" \
  --desugared-lib "$DESUGAR_CONFIG" \
  --main-dex-rules "$OUT_DIR/main-dex-rules.pro" \
  --output "$OUT_DIR/dex" \
  "$OUT_DIR/classes" "$ASM_JAR" "$MULTIDEX_CLASSES"

# L8 emits the NIO backport library DEX separately, as AGP does for core-library
# desugaring. Put it after the app DEX files so the legacy multidex loader can load it.
mkdir -p "$OUT_DIR/desugar-dex"
java -cp "$R8_TOOL_JAR" com.android.tools.r8.L8 \
  --release --min-api 19 \
  --lib "$ANDROID_JAR" \
  --desugared-lib "$DESUGAR_CONFIG" \
  --output "$OUT_DIR/desugar-dex" "$DESUGAR_JAR"

# 3. Assemble, align, and sign a debug APK (no private release key is required).
cp "$OUT_DIR/resources-unsigned.apk" "$OUT_DIR/unsigned.apk"
shopt -s nullglob
DEX_FILES=("$OUT_DIR"/dex/classes*.dex)
((${#DEX_FILES[@]} > 0)) || fail "D8 produced no app DEX files."
L8_DEX="$OUT_DIR/desugar-dex/classes.dex"
need_file "$L8_DEX"
NEXT_DEX=$(( ${#DEX_FILES[@]} + 1 ))
cp "$L8_DEX" "$OUT_DIR/dex/classes${NEXT_DEX}.dex"
DEX_FILES=("$OUT_DIR"/dex/classes*.dex)
zip -j -q "$OUT_DIR/unsigned.apk" "${DEX_FILES[@]}"
KEYSTORE="$OUT_DIR/debug.keystore"
if [[ ! -f "$KEYSTORE" ]]; then
  keytool -genkeypair -v -keystore "$KEYSTORE" -storepass android \
    -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
    -validity 10000 -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
fi
"$ZIPALIGN" -f -p 4 "$OUT_DIR/unsigned.apk" "$OUT_DIR/aligned.apk"
"$APKSIGNER" sign --ks "$KEYSTORE" --ks-key-alias androiddebugkey \
  --ks-pass pass:android --key-pass pass:android \
  --out "$OUT_DIR/PocketDoJa-legacy-v1.3.0a-api19-debug.apk" "$OUT_DIR/aligned.apk"
"$APKSIGNER" verify --verbose "$OUT_DIR/PocketDoJa-legacy-v1.3.0a-api19-debug.apk"
"$ZIPALIGN" -c -v 4 "$OUT_DIR/PocketDoJa-legacy-v1.3.0a-api19-debug.apk"
python3 "$ROOT/porting-tests/verify-api19-apk.py" \
  "$OUT_DIR/PocketDoJa-legacy-v1.3.0a-api19-debug.apk" "$AAPT" 19

echo "BUILD SUCCESS: $OUT_DIR/PocketDoJa-legacy-v1.3.0a-api19-debug.apk"
