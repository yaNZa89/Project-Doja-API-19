# PocketDoJa 1.3.0a — Android 4.4 porting pass 07

## Fokus

Static launch preflight untuk pasangan JAM/JAR asli Monster Hunter i for SH,
sebagai langkah sebelum integrasi runtime Android/Dalvik.

## Hasil pemeriksaan JAM/JAR

Metadata dari `mhi_9.jam`:

- `AppName=Monster Hunter i for SH`
- `AppClass=main`
- `ProfileVer=DoJa-5.0`
- `TargetDevice=SH904i`
- `DrawArea=240x320`
- `SPsize=56320`
- `AppParam=10000i/mh/`

JAR asli berisi 5 class: `main`, `a`, `b`, `c`, dan `d`. Class `main` memiliki
superclass `com.nttdocomo.ui.IApplication`. Bytecode class tertinggi adalah
class-file major 45 (Java 1.1), sehingga versi class game sendiri bukan
penghalang format Java modern.

Dari seluruh constant-pool class game ditemukan 27 referensi class API DoJa
pada namespace `com.nttdocomo`/`com.docomostar`. Semua 27 nama class tersebut
memiliki source Java dalam `opendoja/src/main/java`.

Ditemukan 12 literal nama resource dari bytecode yang cocok dengan entry pada
JAR: `SH903i.dat`, `exceldata.dat`, `hitdata.dat`, `idata.dat`, `map.dat`,
`mons.dat`, `enemy.dat`, `pal.dat`, `syokibugu`, `sozai.dat`, `sset.dat`, dan
`tdata.dat`. Semua entry tersedia dalam arsip.

## Uji konversi ulang JAR → DEX

Perintah `porting-tests/run-jam-dex-smoke.sh /mnt/data/mhi_9.jar` dijalankan
ulang terhadap JAR asli:

- Magic DEX: `dex\\n035`
- Class pada JAR: 5
- Class pada DEX: 5
- Entry resource game: 12
- SHA-1 signature: valid
- Adler-32 checksum: valid

Semua pemeriksaan host-side tersebut lulus.

## Artefak baru

- `porting-tests/mhi/runtime_preflight.py`
- `porting-tests/mhi/README.md` (petunjuk reproduksi)
- `porting-tests/README.md` (tautan ke preflight)

Perintah reproduksi:

```sh
python3 porting-tests/mhi/runtime_preflight.py \\
  /path/to/mhi_9.jam /path/to/mhi_9.jar \\
  --opendoja-src opendoja/src/main/java
```

## Batasan yang belum terselesaikan

Ini adalah pemeriksaan statis terhadap class-file, nama API, resource JAR, dan
format DEX. Ini **belum** memanggil `DexClassLoader` Android, belum
menginstansiasi `main` pada Dalvik, belum memanggil lifecycle `IApplication`
melalui perangkat Android, dan belum membuktikan `Display`/`Canvas` atau
`Graphics3D` menghasilkan frame game.

Tidak ada APK baru yang berhasil dibangun pada tahap ini. Lingkungan kerja
belum menyediakan Android SDK/Gradle dependency cache yang diperlukan untuk
build aplikasi Android penuh. Pengujian Android 4.4 tetap harus dilakukan
pada emulator/perangkat API 19.

## Langkah berikutnya

Tahap berikutnya adalah memperoleh build environment Android yang lengkap,
kemudian menjalankan uji runtime terinstrumentasi: `DexClassLoader` → resolve
`main` → constructor → `DoJaRuntime` bootstrap → `IApplication.start()` →
`Display.setCurrent()` → frame pertama pada surface. Kegagalan pertama dari
rantai tersebut akan menjadi target perbaikan berikutnya.
