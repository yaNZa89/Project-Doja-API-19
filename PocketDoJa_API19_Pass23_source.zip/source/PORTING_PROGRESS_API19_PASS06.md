# PocketDoJa 1.3.0a — Android 4.4 porting pass 06

## Fokus: validasi parser model MBAC dan animasi MTRA dengan aset game asli

Tahap ini menguji parser yang memang sudah ada di PocketDoJa (`MascotLoader`),
bukan membuat parser tiruan. Pengujian memakai `mhi_9.jar` yang diberikan user.

## Koreksi interpretasi format dari analisis sebelumnya

Sumber `opendoja.g3d.MascotLoader` menetapkan pemetaan format berikut:

- `Figure(byte[])` membaca **MBAC** (magic `MB`).
- `ActionTable(byte[])` membaca **MTRA** (magic `MT`).

Dengan demikian, `.mbac` adalah data model/geometri dan `.mtra` adalah data
action/animasi. Pemeriksaan MTRA pada tahap analisis sebelumnya tidak boleh
dianggap sebagai pemetaan geometri; hasil blok MTRA hanya inventaris byte mentah.

## Hasil pengujian pada aset asli

`tdata.dat` diekstrak dan seluruh 57 record ZIP divalidasi terhadap ukuran,
metode kompresi, dan CRC32. Setelah itu parser `MascotLoader` dipanggil pada
semua aset MBAC/MTRA.

| Pemeriksaan | Hasil |
|---|---:|
| Resource terindeks diekstrak dan tervalidasi | 57/57 |
| MBAC model berhasil diparse | 18/18 |
| MTRA action table berhasil diparse | 10/10 |
| Pasangan model/action dengan nama dasar sama | 10/10 cocok |
| Pasangan dengan jumlah bone berbeda | 0 |
| Action yang dievaluasi | 73 |
| Frame action yang dievaluasi | 895 |

Setiap pasangan model/action yang tersedia memiliki jumlah bone yang sama.
Contoh: `f_reusu.mbac` dan `m_reusu.mtra` masing-masing memiliki 84 bone;
`f_ranpos.mbac` dan `m_ranpos.mtra` masing-masing 38 bone.

Pengujian animasi menjalankan `writeMatricesFixed` pada setiap frame mulai
frame 0 hingga frame maksimum masing-masing action. Seluruh 895 evaluasi frame
selesai tanpa exception.

## Artefak uji yang ditambahkan

- `porting-tests/mhi/extract_tdata_index.py`
- `porting-tests/mhi/MascotAssetSmokeTest.java`
- `porting-tests/mhi/MascotPairSmokeTest.java`
- `porting-tests/mhi/MascotAnimationSmokeTest.java`
- `porting-tests/mhi/run-mascot-smoke.sh`
- `porting-tests/mhi/README.md`

Perintah reproduksi:

```sh
./porting-tests/mhi/run-mascot-smoke.sh /path/to/mhi_9.jar
```

## Makna hasil dan batasan

Hasil ini membuktikan bahwa parser MBAC/MTRA yang ada di source PocketDoJa
mampu membaca seluruh aset model/action game yang terindeks, pasangan bone
cocok, dan matriks animasi dapat dievaluasi untuk semua frame terdeklarasi.

Hasil ini **belum** membuktikan hasil render visual benar, karena belum ada
perbandingan gambar dengan perangkat SH904i/original emulator. Ini juga belum
membuktikan bahwa pemanggilan DoJa dari DEX game tersambung ke runtime Android,
atau bahwa game bisa mencapai title screen/gameplay.

Belum ada APK baru yang dibangun atau diuji pada Android 4.4 pada tahap ini.

## Langkah berikutnya

Berikutnya perlu menguji integrasi runtime end-to-end: load JAR game melalui
`JamDexHost`, resolve class `main`, panggil lifecycle DoJa, lalu pastikan
`Display`/`Canvas` dan `Graphics3D` terhubung ke backend Android. Setelah itu
baru dilakukan uji render pada perangkat/emulator Android 4.4.
