# Pass 14 — fondasi build multi-versi Android

Tanggal: 2026-11-20

## Tujuan

Menerapkan pola satu codebase dengan dua paket Android untuk kelas perangkat berbeda, tanpa menggandakan atau mengubah runtime DoJa dan file game.

## Perubahan

1. `app/build.gradle` kini memiliki product flavor `legacy` (minSdk 19) dan `modern` (minSdk 26) dalam dimensi `androidApi`.
2. Kedua flavor menggunakan source set/runtime DoJa, loader JAM/JAR, mekanisme scratchpad, pemetaan input, serta renderer yang sama. Flavor menghasilkan `BuildConfig.LEGACY_ANDROID` dan `BuildConfig.PLATFORM_MIN_API` agar pemisahan adapter berikutnya bisa dilakukan eksplisit.
3. `versionCode` modern dibuat lebih tinggi (10004) daripada legacy (4), sesuai pola distribusi beberapa APK untuk satu aplikasi. `versionName` diberi suffix `-legacy` dan `-modern`.
4. Nama APK menyertakan nama variant sehingga dua hasil build tidak saling menimpa.
5. CI membangun dan menjalankan lint untuk `legacyDebug` serta `modernDebug`, lalu memverifikasi minSdk masing-masing dan format DEX 035.
6. `verify-api19-apk.py` kini menerima expected minSdk opsional, sehingga dapat memeriksa kedua artefak.
7. Preflight source memeriksa keberadaan dua flavor dan BuildConfig.

## Hasil uji yang benar-benar dijalankan

- `python3 -m py_compile porting-tests/check-api19-source.py`: PASS.
- `python3 porting-tests/check-api19-source.py`: PASS; 1.169 file Java runtime dipindai, 6 VectorDrawable qualified dan fallback API 19 terdeteksi.
- `python3 -m py_compile porting-tests/verify-api19-apk.py`: PASS.
- Gradle task discovery/build: BLOCKED. Wrapper mencoba mengunduh Gradle 8.13 dari `services.gradle.org`, tetapi DNS environment menghasilkan `UnknownHostException`. Karena Gradle/SDK belum tersedia, kedua APK belum terbentuk dan belum ada klaim hasil build.

## Batas penting

Pass ini membuat dua build track pada tingkat konfigurasi Gradle; belum memecah seluruh kode Android menjadi dua implementasi adapter terpisah. Belum ada optimisasi renderer modern atau pengurangan fitur opsional legacy. Keduanya harus dilakukan setelah audit call-site Android API dan tes runtime, agar gameplay serta perilaku DoJa tidak berubah.

File `mhi_9.jam`, `mhi_9.jar`, dan `mhi_9.sp` tetap di luar source set dan tidak disentuh.

## Rujukan desain

- Android Gradle product flavors/build variants: https://developer.android.com/build/build-variants
- FreeJ2ME-Plus DoJa profile, scratchpad, and key-layout settings: https://github.com/TASEmulators/freej2me-plus/blob/devel/README.md
- MascotME MIT implementation reference: https://github.com/rmn20/MascotME
