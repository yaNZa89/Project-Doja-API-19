# PocketDoJa Android 4.4 — Pass 21: fresh validation and build gate

Date: 2026-11-20

## Scope

Resumed from the Pass 20 manual-build source package. The target remains a playable PocketDoJa Legacy APK for Android 4.4 / API 19, using the original Monster Hunter i for SH JAM/JAR/SP files without modifying those game files.

## Fresh checks performed in this pass

- Extracted the Pass 20 source archive and reviewed the manual build script and GitHub Actions workflow.
- `python3 porting-tests/check-api19-source.py`: PASS; 1,169 shipped Java source files scanned. The configured source check confirms minSdk 19, MultiDex, NIO/Java 11 desugaring configuration, versioned vector fallback resources, and D8 record-desugaring assumptions.
- `bash -n` on every shell script in `tools/` and `porting-tests/`: PASS.
- `porting-tests/mhi/runtime_preflight.py` against the original JAM/JAR: PASS. DoJa-5.0, SH904i, 240x320, AppClass `main`; 5 game classes; 27/27 DoJa API references and 12/12 checked resource names found.
- `porting-tests/mhi/run-mascot-smoke.sh` against the original JAR: PASS. 57 indexed records validated (959,446 bytes); 18 MBAC models and 10 MTRA tables parsed; 10 model/action pairs matched; 73 actions and 895 frames evaluated without failure.
- SHA-256 values of the original JAM/JAR/SP match the recorded originals.

## Build attempt / blocker

Ran `tools/build-api19-manual.sh`. It stops before compilation because neither `ANDROID_HOME` nor `ANDROID_SDK_ROOT` is configured and no Android SDK platform/build-tools are installed in this workspace. The required AAPT2, Android platform `android.jar`, D8/L8, zipalign and apksigner are absent. Therefore no APK was generated in this pass.

## Remote build status

The manual build workflow is present at `.github/workflows/android-api19-manual-build.yml` and is configured to upload an APK artifact named `pocketdoja-android44-legacy-manual-debug` if successful. However, the two previously supplied GitHub repositories (`yaNZa89/Project-Doja-API-19` and `yaNZa89/Project-legacy`) were checked and both currently report as empty. This session has no authenticated GitHub write/build connection, so it cannot push the source or trigger Actions on the user's behalf.

## Conclusion

Asset/parser validation remains green, and the Gradle-independent remote build path is prepared. The deliverable is still NOT an APK. No claim is made that the game installs, launches, renders, or is playable on Android 4.4 until a successful APK build and API 19 device/emulator test are completed.
