# PocketDoJa Android 4.4 — Pass 20: build system progress

Date: 2026-11-20

## Scope

Continue the single PocketDoJa 1.3.0a Legacy adaptation for Android 4.4/API 19. No new emulator or game port was created. The original `mhi_9.jam`, `mhi_9.jar`, and `mhi_9.sp` were not modified.

## What was inspected

The actual project tree at `pass18_work` was inspected, including `app/build.gradle`, `dexlib/build.gradle`, the Android manifest, source-set exclusions, resources, dependencies, and the existing GitHub Actions Gradle workflow.

The current project source sets contain 1,347 Java files in total; the existing API19 preflight scans 1,169 shipped Java source files after excluding desktop launchers and development probes/tools. The app uses `android-34`, `minSdk 19`, `targetSdk 30`, Java 17, AndroidX multidex, ASM 9.6, and `desugar_jdk_libs_nio:2.1.4`.

## Changes made

1. Added `tools/build-api19-manual.sh`, a Gradle-independent build route using Android SDK `aapt2`, `javac`, D8, L8, `zipalign`, and `apksigner`.
2. Added `.github/workflows/android-api19-manual-build.yml`. On a GitHub runner it installs the Android platform/build-tools, downloads the exact Maven dependencies, extracts the NIO desugaring configuration, and invokes the manual build script. It does not invoke Gradle.
3. Added `MANUAL_BUILD_API19.md` with the required toolchain, dependencies, command, output path, and limitations.
4. Removed the explicit `com.android.tools:r8:8.5.35` runtime dependencies from `app/build.gradle` and `dexlib/build.gradle`. A source-wide search found no imports or direct references to `com.android.tools.r8`; the app uses its in-tree `com.android.dx` implementation for game JAR conversion. The Android SDK D8/L8 tools remain used by the build pipeline. This dependency removal is source-reviewed but not yet verified by a complete Android build.

## Tests actually run

- `bash -n tools/build-api19-manual.sh`: PASS.
- `python3 porting-tests/check-api19-source.py`: PASS; 1,169 shipped Java source files scanned. It reports 184 `java.nio.file` references, 38 collection-factory references, 8 Base64 references, and 116 Java record declarations; the project relies on core-library desugaring and modern D8 support for these.
- `./porting-tests/run-jam-dex-smoke.sh /mnt/data/mhi_9.jar`: PASS. The existing in-tree dx pipeline converted the game JAR to DEX 035; 5 classes and 12 resource entries were read, and the DEX signature/checksum validated.
- Manual APK build preflight: BLOCKED before compilation because this workspace has no `ANDROID_HOME`/`ANDROID_SDK_ROOT`, no Android platform `android.jar`, and no Android Build Tools (`aapt2`, `d8`, `L8` runtime jar, `zipalign`, `apksigner`). No Gradle/Maven caches or Git remote are configured either.
- No APK was produced. No install or Android 4.4 runtime test was possible.

## Original game-file integrity

SHA-256 values still match the earlier recorded originals:

- `mhi_9.jam`: `e3af87b522e42161bd4dfec3ffb4c5e16dd6c7c07872ede832237c078de9f2dc`
- `mhi_9.jar`: `29239c996d454c53bc32af959537eb76c72f25ece24b8207b8034daa35d8948e`
- `mhi_9.sp`: `97cac37b3b4f468c1520d1c7e01a5b2f9b1324892fe4bcb6c9720878ffa3906d`

## What is still needed to obtain the APK

The manual workflow is now prepared but cannot be triggered from this isolated workspace: the project has no configured Git remote or authenticated GitHub connection. The updated project archive must be pushed/uploaded to a GitHub repository, then the workflow `PocketDoJa Android 4.4 manual toolchain build (no Gradle)` can run on GitHub-hosted Linux. The workflow artifact is named `pocketdoja-android44-legacy-manual-debug` and should contain `PocketDoJa-legacy-v1.3.0a-api19-debug.apk` if the manual pipeline succeeds.

A green workflow is still only a packaging/build result. Android 4.4 installation, startup, DoJa 5.0 class loading, MascotCapsule V3 rendering, audio, input, and storage remain device/emulator tests.
