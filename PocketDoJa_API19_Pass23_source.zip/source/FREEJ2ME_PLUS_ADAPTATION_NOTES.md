# FreeJ2ME-Plus: relevansi untuk PocketDoJa Android 4.4

Tanggal pemeriksaan: 2026-11-20

## Fakta yang diverifikasi dari README repository upstream

Repository: https://github.com/TASEmulators/freej2me-plus

- FreeJ2ME-Plus menyediakan frontend AWT dan Libretro; build AWT menghasilkan `freej2me_plus.jar`, sedangkan frontend Libretro memakai JAR runtime dan native core terpisah.
- Konfigurasi command line menyediakan `dojaversion=50` untuk DoJa 5.0.
- Konfigurasi `keyLayout=2` pada README saat ini menggabungkan Motorola/Softbank/Sharp; ini kandidat profil untuk target SH904i, tetapi pemetaan tombol SH904i tetap harus diuji. `keyLayout=8` pada branch ini adalah Siemens, bukan Sharp. Jangan mengasumsikan angka profil dari versi/fork lain.
- Scratchpad DoJa dapat diberikan sebagai `sp=path/to/scratchpad.[sp,sp0]`.
- README mencantumkan renderer MascotCapsuleV3 oleh Roman Lahin (MascotME) sebagai komponen MIT.
- LICENSE repository menyertakan GNU GPL v3 untuk FreeJ2ME. Jangan menyalin seluruh runtime FreeJ2ME-Plus ke PocketDoJa tanpa memeriksa konsekuensi lisensi distribusinya.

## Apa artinya untuk Monster Hunter i

Data game yang tersedia di proyek ini adalah JAM/JAR/SP dan metadata game sebelumnya menunjukkan DoJa 5.0, layar 240x320, target SH904i. Jadi tiga hal dari FreeJ2ME-Plus layak dipakai sebagai pembanding:

1. Pemilihan profil DoJa 5.0.
2. Cara membaca/menulis scratchpad `.sp`.
3. Implementasi MascotCapsuleV3 dan jalur render animasi 3D.

## Keputusan implementasi

FreeJ2ME-Plus **bukan drop-in Android engine**: README upstream menunjukkan frontend desktop AWT dan Libretro, bukan Activity/View Android. Mengintegrasikan seluruh proyek juga membawa pertimbangan GPLv3. Karena PocketDoJa saat ini sudah memiliki runtime DoJa, loader Mascot, model/action table reader, dan renderer 3D sendiri, strategi paling aman adalah:

- pertahankan PocketDoJa sebagai basis Android;
- gunakan FreeJ2ME-Plus sebagai reference implementation untuk memeriksa perbedaan DoJa 5.0, scratchpad, dan MascotCapsule;
- bila perlu mengambil kode, batasi kajian awal ke renderer MascotME yang README sebut MIT dan verifikasi lisensi file sumber yang benar-benar dipilih;
- jangan mengganti mesin PocketDoJa sebelum uji silang menunjukkan bug spesifik yang tidak dapat diperbaiki di renderer saat ini.

J2ME-Loader juga menarik sebagai pembanding frontend Android karena README resminya menyebut Android 4.0+ dan dukungan game J2ME 2D/3D termasuk Mascot Capsule. Namun README tersebut tidak menyatakan dukungan DoJa 5.0, jadi belum cukup untuk menggantikan runtime PocketDoJa untuk game ini.

## Batas pemeriksaan

Pada pass ini README, dokumentasi repository, dan source PocketDoJa lokal diperiksa. Source Java FreeJ2ME-Plus belum di-vendor atau diintegrasikan ke proyek ini; tidak ada klaim bahwa kode renderer upstream telah berhasil dibangun atau dijalankan dengan `mhi_9.jar`.
