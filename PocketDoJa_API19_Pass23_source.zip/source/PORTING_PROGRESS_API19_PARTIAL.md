# PocketDoJa 1.3.0a — Porting progress (API 19 partial patch)

## Changes made in this pass

1. `JamSurfaceView`: replaced `Context.getDrawable(int)` (API 21) with `Context.getResources().getDrawable(int)` (available before API 19).
2. `HomeActivity`: replaced `Activity.getDrawable(int)` with `getResources().getDrawable(int)`.
3. `HomeActivity`: guarded `PopupWindow.setElevation(float)` behind API 21.
4. `HomeActivity`: added API-aware touch feedback. API 21+ uses `RippleDrawable`; API 19–20 uses `StateListDrawable` pressed/focused states.
5. `HomeActivity`: routed `View.setForeground(Drawable)` through an API 23 helper and uses `setBackground()` on older Android versions.

## Validation

- Static inspection confirms the direct call sites above now use compatibility wrappers or SDK guards.
- This is a source-level partial patch only. No APK was built and no Android 4.4 runtime test was performed.
- `minSdk` remains 24 in both `app` and `dexlib` deliberately. The application runtime still uses `java.nio.file` extensively; the current `desugar_jdk_libs_nio` setup is not yet proven to support API 19. Changing `minSdk` now would produce an unverified/incompatible build.
- Additional Java 9/11 APIs and modern language/runtime features still require a complete API 19 audit. The current Gradle wrapper requires Gradle 8.13 and this environment has neither that distribution cached nor an Android SDK.

## Next blockers

1. Replace or backport all shipped-runtime `java.nio.file` use (not just dev probes/tools).
2. Confirm the desugaring strategy and the minimum API supported by all dependencies, including `dexlib` and zip4j.
3. Audit Java library calls (`String.isBlank`, `List.of`, `Map.of`, stream APIs) and DEX/runtime requirements.
4. Run a full build with Android SDK, then install and launch on an API 19 emulator/device.
