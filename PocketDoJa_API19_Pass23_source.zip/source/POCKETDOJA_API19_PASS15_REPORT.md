# PocketDoJa Android 4.4 — Pass 15

Tanggal: 2026-11-20

## Keputusan produk

Pengguna menegaskan hanya membutuhkan aplikasi PocketDoJa Legacy untuk Android 4.4. PocketDoJa asli sudah ada, sehingga pekerjaan ini adalah adaptasi source PocketDoJa 1.3.0a, bukan pembuatan emulator kedua atau varian Android modern. Pass 14 yang menambahkan product flavors `legacy` dan `modern` dibatalkan.

## Perubahan nyata

1. Menghapus product flavors dari `app/build.gradle`; hanya satu Android application variant yang tersisa.
2. Menetapkan `minSdk 19`, `targetSdk 30`, multidex, dan NIO/Java API desugaring pada konfigurasi tunggal.
3. Memberi version name `1.3.0a-api19` dan nama output APK `PocketDoJa-legacy-v1.3.0a-api19.apk`.
4. Mengubah workflow CI agar hanya menjalankan lint dan assemble satu APK debug serta memverifikasi minSdk 19.
5. Mengubah `check-api19-source.py` agar memeriksa satu aplikasi API 19 dan menolak penambahan product flavor/varian modern.
6. Menambahkan catatan Pass 15 dan checksum file game.

## Validasi

- Python syntax check untuk dua skrip preflight/verifikasi: PASS.
- API 19 source preflight: PASS, 1.169 file Java runtime dipindai.
- Hasil inventory: 184 referensi NIO, 38 pemakaian factory collection, 8 pemakaian Base64, dan 116 deklarasi Java record. Ini masih memerlukan verifikasi hasil D8/desugaring dalam build nyata.
- Enam VectorDrawable berada pada qualifier versi baru dan diperiksa fallback PNG API 19.
- Build APK: BLOCKED. Gradle wrapper gagal mengunduh Gradle 8.13 karena `UnknownHostException: services.gradle.org`. Belum ada APK hasil build, belum ada uji instalasi Android 4.4, dan belum ada verifikasi gameplay.
- File game `mhi_9.jam`, `mhi_9.jar`, dan `mhi_9.sp` tidak diubah; checksum dicatat pada file pendamping.

## Langkah berikutnya

Pulihkan akses distribusi Gradle 8.13 atau sediakan Gradle 8.13 lokal, pasang Android SDK platform 34/build-tools 35, jalankan workflow Legacy tunggal, perbaiki error compile/lint/runtime yang ditemukan, lalu instal APK pada Android 4.4/API 19 untuk uji buka game, input, grafis MascotCapsule, audio, save/SP, dan lifecycle.
