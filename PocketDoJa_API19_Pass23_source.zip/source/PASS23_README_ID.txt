PocketDoJa API 19 — PASS 23

Isi paket: source PocketDoJa + workflow GitHub Actions yang diselaraskan dengan struktur folder source/.
Target APK: Android 4.4 (API 19), debug build.

Perbaikan utama Pass 23:
- Workflow memasang Android SDK platform android-34 dan build-tools 35.0.0 secara eksplisit.
- Workflow memeriksa keberadaan android.jar, AAPT2, D8, dan apksigner sebelum build.
- Dependensi Java (ASM, AndroidX multidex, NIO desugaring) diunduh ke source/.build-deps.
- Build dijalankan dari direktori source agar output berada di source/build-manual.
- Upload artifact diarahkan ke source/build-manual, memperbaiki mismatch path yang menyebabkan pesan "No files were found" pada run sebelumnya.
- Jika APK tidak terbentuk, workflow kini gagal dengan jelas alih-alih mengunggah artifact kosong.

PENTING:
Ini adalah paket SOURCE Pass 23, bukan APK jadi. APK belum dapat diklaim berhasil dibangun atau diuji di perangkat. GitHub Actions harus menjalankan workflow di runner yang memiliki Android SDK.

Struktur ZIP sengaja memakai folder source/ di root agar sesuai dengan path artifact workflow.
