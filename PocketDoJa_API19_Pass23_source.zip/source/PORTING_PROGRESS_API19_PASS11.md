# PocketDoJa Android 4.4 / API 19 — Pass 11

## Keputusan jalur build

Saya mempertahankan toolchain modern untuk sementara: Gradle Wrapper 8.13, Android Gradle Plugin 8.13.2, JDK 17 di CI, compileSdk 34, minSdk 19. Menurunkan Gradle/AGP sekarang tidak menyelesaikan runtime compatibility dan justru memaksa migrasi build script/dependensi.

## Koreksi temuan audit sebelumnya

Audit terdahulu menyebut `java.nio.file` tidak tersedia pada Android 4.4. Itu terlalu menyederhanakan dan tidak tepat untuk konfigurasi proyek ini. Android API desugaring dengan `com.android.tools:desugar_jdk_libs_nio:2.1.4` dapat mengemulasi `java.nio.file` di perangkat di bawah API 26, termasuk API 19. Batasan yang didokumentasikan meliputi asynchronous file channel, POSIX ownership/permissions, watch service, serta beberapa perbedaan semantik operasi file.

Referensi resmi:
- https://developer.android.com/studio/write/java11-nio-support-table
- https://developer.android.com/studio/write/java8-support

Ada satu masalah konkret yang tetap perlu diperbaiki: `Path.of(...)` tidak termasuk API Android `Path` yang tersedia pada compile SDK Android. `Paths.get(...)` adalah bentuk kompatibel yang tersedia melalui spesifikasi NIO desugaring. Saya mengganti `Path.of(...)` pada source runtime yang masuk ke APK dengan `Paths.get(...)` di:

- `MediaManager.java`
- `DoJaProfile.java`
- `OpenDoJaPaths.java`
- `DoJaRuntime.java`
- `JamLauncher.java`
- `LaunchCompatibility.java`
- `DoJaStorageHostProbe.java` (file ini berada di source tree host yang ikut dikompilasi)

Panggilan `String.isBlank()`/`String.repeat()` di runtime sudah menggunakan `StringCompat`, bukan method `String` yang tidak ada pada Android 4.4. `List.of`/`Map.of` dipertahankan karena disediakan oleh NIO desugaring yang sedang dikonfigurasi.

## Perubahan Pass 11

1. Mengganti `Path.of(...)` menjadi `Paths.get(...)` pada source runtime yang ikut dikompilasi.
2. Menambahkan `porting-tests/check-api19-source.py` sebagai preflight yang memindai source set APK dan memverifikasi konfigurasi minSdk 19, multidex, serta NIO desugaring.
3. Memperbarui GitHub Actions agar menjalankan preflight, `:app:lintDebug`, dan `:app:assembleDebug`.
4. Mengunggah APK dan laporan lint/build sebagai artifact CI.

## Hasil yang benar-benar dijalankan di workspace ini

- `python3 porting-tests/check-api19-source.py`: PASS; 802 file Java pada source set yang dipindai.
- Pemindaian source: tidak ada `Path.of(...)` tersisa di source runtime APK.
- Pemindaian source: tidak ada pemanggilan langsung `String.isBlank()` atau `String.repeat()` pada source runtime APK.
- Belum dapat menjalankan Gradle build, lint Android, instalasi, atau uji runtime karena workspace ini tidak memiliki Android SDK/`android.jar`/ADB dan Gradle 8.13 tidak dapat diunduh dari lingkungan ini.

## Status

Ini kemajuan kompatibilitas source dan pipeline, bukan APK yang sudah teruji. Langkah pembuktian selanjutnya adalah menjalankan workflow di GitHub, memperbaiki error compile/lint yang benar-benar muncul, lalu menguji hasil APK pada emulator/perangkat API 19. API framework yang hanya tersedia mulai API 21/23/28/30/33 tetap harus dipastikan berada di cabang pemeriksaan versi yang benar; linter API Android di CI akan membantu menemukan pemanggilan yang terlewat.
