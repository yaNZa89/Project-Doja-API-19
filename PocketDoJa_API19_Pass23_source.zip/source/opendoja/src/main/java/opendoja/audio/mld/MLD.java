// -*- Mode: Java; indent-tabs-mode: nil; tab-width: 4 -*-
// ---------------------------------------------------------------------------
// Keitai Wiki Community Music Implementation
//     Originally written and contributed by Guy Perfect
//     Continued maintenance and upkeep by SquirrelJME/Stephanie Gawroriski
// ---------------------------------------------------------------------------
// This specific file is under the given license:
// This is free and unencumbered software released into the public domain.
//
// Anyone is free to copy, modify, publish, use, compile, sell, or
// distribute this software, either in source code form or as a compiled
// binary, for any purpose, commercial or non-commercial, and by any
// means.
//
// In jurisdictions that recognize copyright laws, the author or authors
// of this software dedicate any and all copyright interest in the
// software to the public domain. We make this dedication for the benefit
// of the public at large and to the detriment of our heirs and
// successors. We intend this dedication to be an overt act of
// relinquishment in perpetuity of all present and future rights to this
// software under copyright law.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
//
// For more information, please refer to <https://unlicense.org/>
// ---------------------------------------------------------------------------

package opendoja.audio.mld;

import opendoja.host.DoJaEncoding;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Decoder for i-melody MLD sequences.
 */

public class MLD
{
    static final int CUEPOINT_END = 1;

    /**
     * Cuepoints
     */
    static final int CUEPOINT_START = 0;

    public static final int EVENT_BANK_CHANGE = 0xE1;

    static final int EVENT_CHANNEL_ASSIGN = 0xE5;

    static final int EVENT_CUEPOINT = 0xD0;

    /**
     * Native lib002 treats `0xDC` as an extended wait opcode: the parameter is
     * the high byte of the next track delay, and the following raw track byte is
     * the low byte. It is not a normal sampler control event.
     */
    static final int EVENT_EXTENDED_WAIT = 0xDC;

    /**
     * Raw track-control opcode present in multiple MLD corpora. Concrete
     * runtime semantics depend on the selected sequencer/control model.
     */
    static final int EVENT_TRACK_CONTROL = 0xDD;

    static final int EVENT_END_OF_TRACK = 0xDF;

    static final int EVENT_JUMP = 0xD1;

    public static final int EVENT_MASTER_TUNE = 0xB3;

    /**
     * Event ext-B IDs
     */
    public static final int EVENT_MASTER_VOLUME = 0xB0;

    static final int EVENT_NOP = 0xDE;

    public static final int EVENT_PANPOT = 0xE3;

    static final int EVENT_PART_CONFIGURATION = 0xB9;

    static final int EVENT_PAUSE = 0xBD;

    public static final int EVENT_PITCHBEND = 0xE4;

    public static final int EVENT_PITCHBEND_RANGE = 0xE7;

    public static final int EVENT_PROGRAM_CHANGE = 0xE0;

    static final int EVENT_RESET = 0xBF;

    static final int EVENT_STOP = 0xBE;

    static final int EVENT_TIMEBASE_TEMPO = 0xC0;

    static final int EVENT_TYPE_RESOURCE = 3;

    static final int EVENT_TYPE_EXT_B = 1;

    static final int EVENT_TYPE_EXT_INFO = 2;

    static final int EVENT_TYPE_NOTE = 0;

    /**
     * Event types
     */
    static final int EVENT_TYPE_UNKNOWN = -1;

    public static final int EVENT_VOLUME = 0xE2;

    public static final int EVENT_WAVE_CHANNEL_PANPOT = 0xE9;

    public static final int EVENT_WAVE_CHANNEL_VOLUME = 0xE8;

    public static final int EVENT_X_DRUM_ENABLE = 0xBA;

    public static final int EVENT_RESOURCE_START = 0x00;

    public static final int EVENT_RESOURCE_STOP = 0x01;

    public static final int EVENT_RESOURCE_LEVEL = 0x80;

    public static final int EVENT_RESOURCE_PAN = 0x81;

    public static final int EVENT_RESOURCE_CONFIG = 0x90;

    public static final int EVENT_RESOURCE_AUX = 0xF0;

    /**
     * FourCCs
     * "adat"
     */
    static final int FOURCC_ADAT = 0x61646174;

    /**
     * "ainf"
     */
    static final int FOURCC_AINF = 0x61696E66;

    /**
     * "auth"
     */
    static final int FOURCC_AUTH = 0x61757468;

    /**
     * "copy"
     */
    static final int FOURCC_COPY = 0x636F7079;

    /**
     * "cuep"
     */
    static final int FOURCC_CUEP = 0x63756570;

    /**
     * "date"
     */
    static final int FOURCC_DATE = 0x64617465;

    /**
     * "exst"
     */
    static final int FOURCC_EXST = 0x65787374;

    /**
     * "melo"
     */
    static final int FOURCC_MELO = 0x6D656C6F;

    /**
     * "note"
     */
    static final int FOURCC_NOTE = 0x6E6F7465;

    /**
     * "prot"
     */
    static final int FOURCC_PROT = 0x70726F74;

    /**
     * "sorc"
     */
    static final int FOURCC_SORC = 0x736F7263;

    /**
     * "supt"
     */
    static final int FOURCC_SUPT = 0x73757074;

    /**
     * "thrd"
     */
    static final int FOURCC_THRD = 0x74687264;

    /**
     * "titl"
     */
    static final int FOURCC_TITL = 0x7469746C;

    /**
     * "trac"
     */
    static final int FOURCC_TRAC = 0x74726163;

    /**
     * "vers"
     */
    static final int FOURCC_VERS = 0x76657273;

    /**
     * "note" types
     */
    static final int NOTE_3 = 0;

    static final int NOTE_4 = 1;

    /**
     * Sample data
     */
    MLDADPCM[] adpcms;

    /**
     * Header subchunks
     */
    byte[] ainf;

    int ainfCount;

    boolean ainfRejectExternalLink;

    byte[] auth;

    /**
     * Content type header fields
     */
    int contentType;

    String copy;

    int[] cuep;

    String date;

    /**
     * Total runtime in seconds, or POSITIVE_INFINITY
     */
    double duration;

    byte[] exst;

    int exstCount;

    boolean hasFemaleVocals;

    boolean hasImageData;

    boolean hasMaleVocals;

    boolean hasMusicEvents;

    boolean hasOtherVocals;

    boolean hasTextData;

    boolean hasWaveData;

    /**
     * Encoded header chunk
     */
    byte[] header;

    int note;

    String prot;

    int sorc;

    String supt;

    byte[] thrd;

    /**
     * Tick count at the end of the last event
     */
    long tickEnd;

    /**
     * Tick count of the loop destination
     */
    long tickLoop;

    String titl;

    /**
     * Event lists
     */
    MLDTrack[] tracks;

    String vers;


    /**
     * Decode from a byte array. Same as invoking
     * {@code MLD(data, 0, data.length)}.
     *
     * @param data A byte array contining the MLD resource.
     * @throws NullPointerException if {@code data} is {@code null}.
     * @throws RuntimeException if an error occurs during decoding.
     * @see MLD(byte[],int,int)
     */

    public MLD(byte[] data)
    {
        this(data, 0, data.length);
    }

    /**
     * Decode from a byte array. If the {@code length} argument specifies
     * bytes
     * beyond the end of the MLD resource, the extra bytes will not be
     * processed.
     *
     * @param data A byte array contining the MLD resource.
     * @param offset The position in {@code data} of the first byte of the MLD
     * resource.
     * @param length The number of bytes to consider when decoding the MLD
     * resource. Must be greater than or equal to the size of the MLD.
     * @throws NullPointerException if {@code data} is {@code null}.
     * @throws IllegalArgumentException if {@code length} is negative.
     * @throws ArrayIndexOutOfBoundsException if {@code offset} is negative
     * or {@code offset + length > data.length}.
     * @throws RuntimeException if an error occurs during decoding.
     */

    public MLD(byte[] data, int offset, int length)
    {

        // Error checking
        if (data == null)
            throw new NullPointerException("A byte buffer is required.");
        if (length < 0)
            throw new IllegalArgumentException("Invalid length.");
        if (offset < 0 || length >= 0 && offset + length > data.length)
        {
            throw new ArrayIndexOutOfBoundsException(
                "Invalid range in byte buffer.");
        }

        // Parse the data
        try (ByteArrayInputStream stream = new ByteArrayInputStream(data,
            offset, length))
        {
            this.parse(new DataInputStream(stream));
        }
        catch (IOException e)
        {
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * Decode from an input stream. The data at the current position in the
     * stream must be an MLD resource.<br><br>
     * After returning, the stream will be at the position of the byte
     * following the MLD data. If an error occurs during decoding, the stream
     * position will be indeterminate.
     *
     * @param in The stream to decode from.
     * @throws RuntimeException if an error occurs during decoding.
     * @throws IOException if a stream access error occurs.
     */

    public MLD(InputStream in)
        throws IOException
    {
        this.parse(in instanceof DataInputStream ? (DataInputStream)in :
            new DataInputStream(in));
    }


    /**
     * Retrieve the copyright of the MLD resource.
     *
     * @return The copyright text if available, or {@code null} otherwise.
     */
    public String getCopyright()
    {
        return this.copy;
    }

    /**
     * Retrieve the date of the MLD resource.
     *
     * @return The date text if available, or {@code null} otherwise.
     */
    public String getDate()
    {
        return this.date;
    }

    /**
     * Determine the total length of the MLD sequence in seconds.
     *
     * @param withoutLooping Whether or not to consider looping in the return
     * value.
     * @return If the sequence does not loop, the number of seconds in the
     * sequence. If the sequence loops and {@code withoutLooping} is
     * {@code false}, returns {@code Double.POSITIVE_INFINITY}. If the
     * sequence
     * loops and {@code withoutLooping} is {@code true}, returns the number of
     * seconds in the sequence up until the first loop occurs.
     * @see MLDPlayer#getTime()
     * @see MLDPlayer#setTime(double)
     */

    public double getDuration(boolean withoutLooping)
    {
        return withoutLooping || this.tickLoop == -1 ? this.duration :
            Double.POSITIVE_INFINITY;
    }

    /**
     * Retrieve the title of the MLD resource.
     *
     * @return The title text if available, or {@code null} otherwise.
     */
    public String getTitle()
    {
        return this.titl;
    }


    /**
     * Retrieve the version of the MLD resource.
     *
     * @return The version text if available, or {@code null} otherwise.
     */
    public String getVersion()
    {
        return this.vers;
    }


    /**
     * Parse an ADPCM chunk
     */
    MLDADPCM adpcm(MLDBinaryReader reader)
    {
        if (reader.u32() != MLD.FOURCC_ADAT)
            throw new RuntimeException("Missing \"adat\" chunk.");
        MLDADPCM ret = new MLDADPCM();
        ret.data = reader.bytes(reader.u32());
        this.parseAdpcmDescriptor(ret);
        return ret;
    }


    /**
     * Parse an event
     */
    MLDEvent event(int note, int track, MLDBinaryReader reader)
    {
        MLDEvent event = new MLDEvent();

        // Common fields
        event.offset = reader.offset;
        event.delta = reader.u8();
        event.status = reader.u8();

        if (event.status == 0x7F)
        {
            event.id = reader.u8();
            return this.finishEvent(this.eventResource(track, event, reader),
                reader);
        }

        // Note event
        if ((event.status & 0x3F) != 63)
            return this.finishEvent(this.eventNote(note, track, event, reader),
                reader);

        // Meta event fields
        event.id = reader.u8();
        return this.finishEvent(this.eventMeta(track, event, reader), reader);
    }

    private MLDEvent eventMeta(int track, MLDEvent event,
        MLDBinaryReader reader)
    {
        // ext-info event
        if (event.id >= 0xF0)
            return this.eventExtInfo(event, reader);

        // Unknown event
        if (event.id < 0x80)
        {
            event.type = MLD.EVENT_TYPE_UNKNOWN;
            event.data = reader.bytes(2);
            return event;
        }

        // Common ext-B processing
        event.type = MLD.EVENT_TYPE_EXT_B;
        event.param = reader.u8();
        event.channelIndex = event.param >> 6;
        event.channel = track << 2 | event.channelIndex;

        // timebase-tempo event
        if ((event.id & 0xF0) == MLD.EVENT_TIMEBASE_TEMPO)
            return this.finishEvent(this.eventTimebaseTempo(event), reader);

        // Other event
        switch (event.id)
        {

            // Events that need further processing
            case MLD.EVENT_BANK_CHANGE:
                return this.eventBankChange(event);
            case MLD.EVENT_CUEPOINT:
                return this.eventCuepoint(event);
            case MLD.EVENT_JUMP:
                return this.eventJump(event);
            case MLD.EVENT_MASTER_TUNE:
                return this.eventMasterTune(event);
            case MLD.EVENT_MASTER_VOLUME:
                return this.eventMasterVolume(event);
            case MLD.EVENT_PANPOT:
                return this.eventPanPot(event);
            case MLD.EVENT_PITCHBEND:
                return this.eventPitchBend(event);
            case MLD.EVENT_PITCHBEND_RANGE:
                return this.eventPitchBendRange(event);
            case MLD.EVENT_PROGRAM_CHANGE:
                return this.eventProgramChange(event);
            case MLD.EVENT_VOLUME:
                return this.eventVolume(event);
            case MLD.EVENT_WAVE_CHANNEL_PANPOT:
                return this.eventPanPot(event);
            case MLD.EVENT_WAVE_CHANNEL_VOLUME:
                return this.eventVolume(event);
            case MLD.EVENT_X_DRUM_ENABLE:
                return this.eventDrumEnable(event);

            // Events that do not need further processing
            case MLD.EVENT_CHANNEL_ASSIGN:      // Not implemented
            case MLD.EVENT_PART_CONFIGURATION:  // Not implemented
            case MLD.EVENT_END_OF_TRACK:
            case MLD.EVENT_NOP:
            case MLD.EVENT_PAUSE:
            case MLD.EVENT_RESET:
            case MLD.EVENT_STOP:
                break;

            // Unrecognized events
            default:
        }
        return event;
    }

    MLDEvent eventResource(int track, MLDEvent event, MLDBinaryReader reader)
    {
        event.type = MLD.EVENT_TYPE_RESOURCE;
        if (event.id == MLD.EVENT_RESOURCE_AUX)
        {
            event.data = reader.bytes(reader.u16());
            if (event.data.length >= 6)
            {
                int packed = event.data[0] & 0xFF;
                event.param = packed;
                event.channelIndex = packed >> 6;
                event.channel = track << 2 | event.channelIndex;
                event.resourceIndex = packed & 0x1F;
                event.resourceAuxStrength = event.data[1] & 0xFF;
                event.resourceAuxAzimuthDegrees =
                    this.decodeResourceAuxAzimuth(event.data[2] & 0xFF);
                event.resourceAuxElevationDegrees =
                    this.decodeResourceAuxElevation(event.data[3] & 0xFF);
                event.resourceAuxDurationRaw = this.readBe16(event.data, 4);
            }
            return event;
        }

        event.data = reader.bytes(this.resourceBodyLength(event.id));
        if (event.data.length == 0)
            return event;

        int packed = event.data[0] & 0xFF;
        int low6 = packed & 0x3F;
        event.param = packed;
        event.channelIndex = packed >> 6;
        event.channel = track << 2 | event.channelIndex;

        switch (event.id)
        {
            case MLD.EVENT_RESOURCE_START:
            case MLD.EVENT_RESOURCE_STOP:
                event.resourceIndex = low6;
                if (event.id == MLD.EVENT_RESOURCE_START)
                {
                    event.resourcePitchByte = event.data.length > 1 ?
                        (event.data[1] & 0x3F) : 0x37;
                }
                break;
            case MLD.EVENT_RESOURCE_LEVEL:
            case MLD.EVENT_RESOURCE_PAN:
                event.value2x = low6 << 1;
                break;
            case MLD.EVENT_RESOURCE_CONFIG:
                event.resourceAudioTarget = (packed & 0x20) != 0;
                event.resourceConfigRawValue = packed & 0x1F;
                event.resourceConfigClear = event.resourceConfigRawValue == 31;
                break;
            default:
                event.resourceIndex = low6;
                break;
        }
        return event;
    }

    private MLDEvent finishEvent(MLDEvent event, MLDBinaryReader reader)
    {
        event.endOffset = reader.offset;
        return event;
    }

    /**
     * Parse a bank-change event
     */
    MLDEvent eventBankChange(MLDEvent event)
    {
        event.bank = event.param & 0x3F;
        return event;
    }

    /**
     * Parse a cuepoint event
     */
    MLDEvent eventCuepoint(MLDEvent event)
    {
        event.cuepoint = event.param;
        return event;
    }

    /**
     * Parse a drum-enable event
     */
    MLDEvent eventDrumEnable(MLDEvent event)
    {
        event.channel = event.param >> 3 & 15;
        event.enable = (event.param & 1) != 0;
        return event;
    }

    /**
     * Parse an ext-info event
     */
    MLDEvent eventExtInfo(MLDEvent event, MLDBinaryReader reader)
    {
        event.type = MLD.EVENT_TYPE_EXT_INFO;
        event.data = reader.bytes(reader.u16());
        return event;
    }

    /**
     * Parse a jump event
     */
    MLDEvent eventJump(MLDEvent event)
    {
        event.jumpCount = event.param & 15;
        event.jumpId = event.param >> 4 & 3;
        event.jumpPoint = event.param >> 6;
        return event;
    }

    /**
     * Parse a master-tune event
     */
    MLDEvent eventMasterTune(MLDEvent event)
    {
        event.semitones = ((event.param & 0x7F) - 64) / 64.0f;
        return event;
    }

    /**
     * Parse a master-volume event
     */
    MLDEvent eventMasterVolume(MLDEvent event)
    {
        event.volume = this.volumeToAmplitude((event.param & 0x7F) / 127.0f);
        return event;
    }

    /**
     * Parse a note event
     */
    MLDEvent eventNote(int note, int track, MLDEvent event,
        MLDBinaryReader reader)
    {

        // Common processing
        event.type = MLD.EVENT_TYPE_NOTE;
        event.channelIndex = event.status >> 6;
        event.gateTime = reader.u8();
        event.keyNumber = event.status & 63;

        // Note events are 3 bytes
        if (note == MLD.NOTE_3)
        {
            event.octaveShift = 0;
            event.velocity = 1.0f;
        }

        // Note events are 4 bytes
        else
        {
            int bits = reader.u8();
            event.octaveShift = bits << 30 >> 30;
            event.velocity = (bits >> 2) / 63.0f;
        }

        // Compute normalized fields
        event.channel = track << 2 | event.channelIndex;
        event.key = event.octaveShift * 12 + event.keyNumber - 24;
        return event;
    }

    /**
     * Parse a panpot event
     */
    MLDEvent eventPanPot(MLDEvent event)
    {
        int param = event.param & 0x3F;
        event.panpot = param < 32 ? param / 32.0f - 1 : (param - 32) / 31.0f;
        return event;
    }

    /**
     * Parse a pitchbend event
     */
    MLDEvent eventPitchBend(MLDEvent event)
    {
        event.semitones = ((event.param & 0x3F) - 32) / 3200.0f;
        return event;
    }

    /**
     * Parse a pitchbend-range event
     */
    MLDEvent eventPitchBendRange(MLDEvent event)
    {
        event.range = event.param & 0x3F;
        return event;
    }

    /**
     * Parse a program-change event
     */
    MLDEvent eventProgramChange(MLDEvent event)
    {
        event.program = event.param & 0x3F;
        return event;
    }

    /**
     * Parse a timebase-tempo event
     */
    MLDEvent eventTimebaseTempo(MLDEvent event)
    {
        event.bank = event.id;
        event.tempo = event.param;
        event.timebase = (event.id & 7) == 7 ? -1 :
            ((event.id & 15) > 7 ? 15 : 6) << (event.id & 7);
        event.id = MLD.EVENT_TIMEBASE_TEMPO;
        return event;
    }

    /**
     * Parse a volume event
     */
    MLDEvent eventVolume(MLDEvent event)
    {
        event.volume = this.volumeToAmplitude((event.param & 0x3F) / 63.0f);
        return event;
    }


    /**
     * Parse the file header
     */
    void header(MLDBinaryReader reader)
    {
        reader = reader.reader(reader.u16());
        this.header = reader.bytes(reader.length);
        reader.offset -= reader.length;

        // Content type
        this.contentType = reader.u16();
        if ((this.contentType & 0xFF00) == 0x0200)
        {
            int bits = this.contentType & 0x00FF;
            this.hasMusicEvents = (bits & 0x01) != 0;
            this.hasWaveData = (bits & 0x02) != 0;
            this.hasTextData = (bits & 0x04) != 0;
            this.hasImageData = (bits & 0x08) != 0;
            this.hasFemaleVocals = (bits & 0x10) != 0;
            this.hasMaleVocals = (bits & 0x20) != 0;
            this.hasOtherVocals = (bits & 0x40) != 0;
        }

        // The vendor player accepts the common 0x0101 music-only header as
        // well as the 0x0201 variant seen in bundled DoJa assets.
        if (this.contentType != 0x0101 && this.contentType != 0x0201)
        {
            throw new RuntimeException(
                String.format("Unsupported content type: 0x%04X",
                    this.contentType));
        }

        // Number of tracks
        int numTracks = reader.u8();
        if (numTracks > 4)
            throw new RuntimeException("Invalid track count: " + numTracks);
        this.cuep = new int[numTracks];
        this.tracks = new MLDTrack[numTracks];

        // Header subchunks
        while (!reader.isEOF())
        {
            int id = reader.u32();
            MLDBinaryReader chunk = reader.reader(reader.u16());
            switch (id)
            {
                case MLD.FOURCC_AINF:
                    this.headerAINF(chunk);
                    break;
                case MLD.FOURCC_AUTH:
                    this.headerAUTH(chunk);
                    break;
                case MLD.FOURCC_COPY:
                    this.headerCOPY(chunk);
                    break;
                case MLD.FOURCC_CUEP:
                    this.headerCUEP(chunk);
                    break;
                case MLD.FOURCC_DATE:
                    this.headerDATE(chunk);
                    break;
                case MLD.FOURCC_EXST:
                    this.headerEXST(chunk);
                    break;
                case MLD.FOURCC_NOTE:
                    this.headerNOTE(chunk);
                    break;
                case MLD.FOURCC_PROT:
                    this.headerPROT(chunk);
                    break;
                case MLD.FOURCC_SORC:
                    this.headerSORC(chunk);
                    break;
                case MLD.FOURCC_SUPT:
                    this.headerSUPT(chunk);
                    break;
                case MLD.FOURCC_THRD:
                    this.headerTHRD(chunk);
                    break;
                case MLD.FOURCC_TITL:
                    this.headerTITL(chunk);
                    break;
                case MLD.FOURCC_VERS:
                    this.headerVERS(chunk);
                    break;
            }
        }

    }

    /**
     * Parse a header "ainf" subchunk
     */
    void headerAINF(MLDBinaryReader reader)
    {
        this.ainf = reader.bytes(reader.length);
        if (this.ainf.length > 0)
        {
            int bits = this.ainf[0] & 0xFF;
            this.ainfCount = bits & 0x3F;
            this.ainfRejectExternalLink = (bits & 0x40) != 0;
            this.adpcms = new MLDADPCM[this.ainfCount];
        }
    }

    /**
     * Parse a header "auth" subchunk
     */
    void headerAUTH(MLDBinaryReader reader)
    {
        this.auth = reader.bytes(reader.length);
    }

    /**
     * Parse a header "copy" subchunk
     */
    void headerCOPY(MLDBinaryReader reader)
    {
        this.copy = this.shiftJIS(reader.bytes(reader.length));
    }

    /**
     * Parse a header "cuep" subchunk
     */
    void headerCUEP(MLDBinaryReader reader)
    {
        for (int x = 0; x < this.cuep.length; x++)
            this.cuep[x] = reader.u32();
    }

    /**
     * Parse a header "date" subchunk
     */
    void headerDATE(MLDBinaryReader reader)
    {
        this.date = this.shiftJIS(reader.bytes(reader.length));
    }

    /**
     * Parse a header "exst" subchunk
     */
    void headerEXST(MLDBinaryReader reader)
    {
        this.exst = reader.bytes(reader.length);
        if (this.exst.length >= 2)
            this.exstCount = this.readBe16(this.exst, 0);
    }

    /**
     * Parse a header "note" subchunk
     */
    void headerNOTE(MLDBinaryReader reader)
    {
        this.note = reader.u16();
        if (this.note >> 1 == 0)
            return;
        throw new RuntimeException(
            String.format("Invalid \"note\": 0x%04X", this.note));
    }

    /**
     * Parse a header "prot" subchunk
     */
    void headerPROT(MLDBinaryReader reader)
    {
        this.prot = this.shiftJIS(reader.bytes(reader.length));
    }

    /**
     * Parse a header "sorc" subchunk
     */
    void headerSORC(MLDBinaryReader reader)
    {
        this.sorc = reader.u8();
    }

    /**
     * Parse a header "supt" subchunk
     */
    void headerSUPT(MLDBinaryReader reader)
    {
        this.supt = this.shiftJIS(reader.bytes(reader.length));
    }

    /**
     * Parse a header "thrd" subchunk
     */
    void headerTHRD(MLDBinaryReader reader)
    {
        this.thrd = reader.bytes(reader.length);
    }

    /**
     * Parse a header "titl" subchunk
     */
    void headerTITL(MLDBinaryReader reader)
    {
        this.titl = this.shiftJIS(reader.bytes(reader.length));
    }

    /**
     * Parse a header "vers" subchunk
     */
    void headerVERS(MLDBinaryReader reader)
    {
        this.vers = this.shiftJIS(reader.bytes(reader.length));
    }

    /**
     * Measure the duration and tick counters
     */
    void inspect()
    {
        double tempo = 60.0 / (48 * 128);
        long tickNow = 0;
        int[] trkPos = new int[this.tracks.length];
        int[] trkUntil = new int[this.tracks.length];
        // Resource-only MLDs can end the track on the same tick as the start
        // command, so duration must also account for live top-level adat clips.
        ArrayList<ResourceClipSpan> resourceClips = new ArrayList<>();

        // Initialize instance fields
        this.duration = 0.0;
        this.tickEnd = 0;
        this.tickLoop = -1;

        // Record the start time of each track's first event
        for (int x = 0; x < this.tracks.length; x++)
        {
            MLDTrack track = this.tracks[x];
            if (track.size() != 0)
            {
                trkPos[x] = 0;
                trkUntil[x] = track.get(0).delta;
            }
            else
                trkUntil[x] = -1;
        }

        // Inspect all events
        for (; ; )
        {

            // Determine the number of ticks until the next event
            int until = -1;
            for (int x = 0; x < this.tracks.length; x++)
            {
                int tu = trkUntil[x];
                if (tu != -1 && (until == -1 || tu < until))
                    until = tu;
            }

            // All tracks have finished
            if (until == -1)
                break;

            // Advance to the next event
            this.duration += until * tempo;
            tickNow += until;
            this.tickEnd = Math.max(this.tickEnd, tickNow);
            for (int x = 0; x < this.tracks.length; x++)
            {
                if (trkUntil[x] != -1)
                    trkUntil[x] -= until;
            }

            // Process all relevant events that happen right now
            for (int x = 0; x < this.tracks.length; x++)
            {

                // No more events right now on this track
                if (trkUntil[x] != 0)
                    continue;

                // Retrieve the next event
                MLDTrack track = this.tracks[x];
                MLDEvent event = track.get(trkPos[x]++);

                // Additional events on this track
                if (trkPos[x] < track.size())
                    trkUntil[x] = track.get(trkPos[x]).delta;

                    // No more events ever on this track
                else
                    trkUntil[x] = -1;

                // end-of-track
                if (event.type == MLD.EVENT_TYPE_EXT_B && event.id == MLD.EVENT_END_OF_TRACK)
                {
                    trkUntil[x] = -1;
                    continue;
                }

                // Check this track again next iteration
                x--;

                // note
                if (event.type == MLD.EVENT_TYPE_NOTE)
                {
                    this.tickEnd = Math.max(this.tickEnd,
                        tickNow + event.gateTime);
                    continue;
                }

                // top-level resource audio
                if (event.type == MLD.EVENT_TYPE_RESOURCE)
                {
                    this.inspectResource(resourceClips, event);
                    continue;
                }

                // Next must be ext-B
                if (event.type != MLD.EVENT_TYPE_EXT_B)
                    continue;

                // timebase-tempo
                if ((event.id & 0xF0) == MLD.EVENT_TIMEBASE_TEMPO)
                {
                    tempo = 60.0 / (event.timebase * event.tempo);
                    continue;
                }

                // Next must be cuepoint
                if (event.id != MLD.EVENT_CUEPOINT)
                    continue;

                // cuepoint start
                if (event.cuepoint == MLD.CUEPOINT_START)
                {
                    this.tickLoop = tickNow;
                    continue;
                }

                // cuepoint end, but the loop point isn't set
                if (this.tickLoop == -1)
                    continue;

                // If a cuepoint end and note both happen on the
                // same tick and the cuepoint end is "first", does
                // it still play the note?

                // cuepoint end
                this.tickEnd = tickNow;
                this.finishResourceInspection(resourceClips);
                return;
            }

        }

        // The entire sequence was scanned
        this.finishResourceInspection(resourceClips);
        this.tickLoop = -1;
    }

    /**
     * Parse an MLD file
     */
    void parse(DataInputStream stream)
        throws IOException
    {

        // File signature
        if (stream.readInt() != MLD.FOURCC_MELO)
            throw new RuntimeException("Missing \"melo\" signature.");

        // File length
        int length = stream.readInt();
        if (length < 0)
            throw new RuntimeException("Unsupported file length.");

        // Read the file into a byte array
        byte[] data = new byte[8 + length];
        int offset = 8;
        while (offset < data.length)
        {
            int readed = stream.read(data, offset, data.length - offset);
            if (readed == -1)
                throw new RuntimeException("Unexpected EOF.");
            offset += readed;
        }

        // Default fields
        this.adpcms = new MLDADPCM[0];
        this.exstCount = 1;
        this.note = MLD.NOTE_3;
        this.thrd = new byte[0];

        // Working variables
        MLDBinaryReader reader = new MLDBinaryReader(data, 8, length);

        // Parse the file
        this.header(reader);
        for (int x = 0; x < this.adpcms.length; x++)
            this.adpcms[x] = this.adpcm(reader);
        for (int x = 0; x < this.tracks.length; x++)
            this.tracks[x] = this.track(this.note, x, reader);

        // Measure the duration and tick counters
        this.inspect();
    }

    /**
     * Decode a string with the default DoJa charset.
     */
    String shiftJIS(byte[] bytes)
    {
        return (bytes == null ? null :
            new String(bytes, DoJaEncoding.DEFAULT_CHARSET));
    }

    private void parseAdpcmDescriptor(MLDADPCM adpcm)
    {
        if (adpcm.data.length < 4)
            return;

        int headerLength = this.readBe16(adpcm.data, 0);
        int headerEnd = 2 + headerLength;
        if (headerLength < 2 || headerEnd > adpcm.data.length)
            return;

        adpcm.selectorHeaderLength = headerLength;
        adpcm.selectorId = adpcm.data[2] & 0xFF;
        adpcm.selectorFlags = adpcm.data[3] & 0xFF;

        int offset = 4;
        while (offset + 6 <= headerEnd)
        {
            String id = new String(adpcm.data, offset, 4,
                StandardCharsets.US_ASCII);
            int length = this.readBe16(adpcm.data, offset + 4);
            int bodyStart = offset + 6;
            int bodyEnd = bodyStart + length;
            if (bodyEnd > headerEnd)
                return;
            if ("adpm".equals(id) && length >= 3)
            {
                adpcm.sampleRateHz = (adpcm.data[bodyStart] & 0xFF) * 1000;
                adpcm.codedBits = adpcm.data[bodyStart + 1] & 0xFF;
                int mode = adpcm.data[bodyStart + 2] & 0xFF;
                adpcm.channelCount = mode & 0x07;
                adpcm.variantBit = (mode & 0x08) != 0;
            }
            offset = bodyEnd;
        }

        adpcm.payload = Arrays.copyOfRange(adpcm.data, headerEnd,
            adpcm.data.length);
    }

    public MLDADPCM[] resourceAdpcms()
    {
        return this.adpcms.clone();
    }

    public byte[] resourceThreadDefaults()
    {
        return this.thrd == null ? new byte[0] : this.thrd.clone();
    }

    private int readBe16(byte[] data, int offset)
    {
        return ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF);
    }

    private int decodeResourceAuxAzimuth(int raw)
    {
        int value = raw * 3 - 0x180;
        if (value < -180)
            value = -180;
        else if (value >= 180)
            value = 180;
        if (value < 0)
            value += 360;
        return value;
    }

    private int decodeResourceAuxElevation(int raw)
    {
        int value = raw * 3 - 0x180;
        if (value < -90)
            return -90;
        if (value >= 90)
            return 90;
        return value;
    }

    private int resourceBodyLength(int command)
    {
        switch (command)
        {
            case MLD.EVENT_RESOURCE_START:
            case MLD.EVENT_RESOURCE_STOP:
                return 1 + this.exstCount;
            case MLD.EVENT_RESOURCE_LEVEL:
            case MLD.EVENT_RESOURCE_PAN:
            case MLD.EVENT_RESOURCE_CONFIG:
                return 1;
            default:
                return command < 0x80 ? 1 + this.exstCount : 1;
        }
    }

    /**
     * Parse a track
     */
    MLDTrack track(int note, int index, MLDBinaryReader reader)
    {

        // Error checking
        if (reader.u32() != MLD.FOURCC_TRAC)
            throw new RuntimeException("Missing \"trac\" chunk.");

        // Working variables
        MLDTrack ret = new MLDTrack();
        ret.index = index;
        reader = reader.reader(reader.u32());
        int cue = reader.offset + this.cuep[index];
        int pendingExtendedDelta = -1;

        // Parse events
        while (!reader.isEOF())
        {
            if (reader.offset == cue)
                ret.cue = ret.size();
            MLDEvent event = this.event(note, index, reader);
            if (pendingExtendedDelta >= 0)
            {
                event.delta |= pendingExtendedDelta;
                pendingExtendedDelta = -1;
            }
            if (event.type == MLD.EVENT_TYPE_EXT_B &&
                event.id == MLD.EVENT_EXTENDED_WAIT)
            {
                pendingExtendedDelta = (event.param & 0xFF) << 8;
                continue;
            }
            ret.add(event);
        }
        if (pendingExtendedDelta >= 0)
            throw new RuntimeException("Dangling extended wait at end of track.");
        return ret;
    }

    private void inspectResource(ArrayList<ResourceClipSpan> resourceClips,
        MLDEvent event)
    {
        if (event.id == MLD.EVENT_RESOURCE_START)
        {
            double seconds = this.resourceDurationSeconds(event.resourceIndex);
            if (seconds > 0.0)
                resourceClips.add(new ResourceClipSpan(event.channel,
                    event.resourceIndex, this.duration + seconds));
            return;
        }
        if (event.id != MLD.EVENT_RESOURCE_STOP)
            return;
        for (int i = resourceClips.size() - 1; i >= 0; i--)
        {
            ResourceClipSpan clip = resourceClips.get(i);
            if (clip.channel != event.channel ||
                clip.resourceIndex != event.resourceIndex)
                continue;
            clip.endSeconds = Math.min(clip.endSeconds, this.duration);
        }
    }

    private void finishResourceInspection(
        ArrayList<ResourceClipSpan> resourceClips)
    {
        // The overall MLD duration is the later of sequenced time and any
        // top-level resource clip that is still expected to sound.
        for (int i = 0; i < resourceClips.size(); i++)
            this.duration = Math.max(this.duration,
                resourceClips.get(i).endSeconds);
    }

    private double resourceDurationSeconds(int resourceIndex)
    {
        if (resourceIndex < 0 || resourceIndex >= this.adpcms.length)
            return 0.0;
        MLDADPCM resource = this.adpcms[resourceIndex];
        return resource == null ? 0.0 : resource.durationSeconds();
    }

    /** Convert a volume parameter to a linear amplitude. */
    float volumeToAmplitude(float param)
    {
        return param == 0.0f ? 0.0f : (float)Math.pow(2,
            (1 - param) * -96 / 20);
    }

    private static final class ResourceClipSpan
    {
        final int channel;

        final int resourceIndex;

        double endSeconds;

        private ResourceClipSpan(int channel, int resourceIndex,
            double endSeconds)
        {
            this.channel = channel;
            this.resourceIndex = resourceIndex;
            this.endSeconds = endSeconds;
        }
    }
}
