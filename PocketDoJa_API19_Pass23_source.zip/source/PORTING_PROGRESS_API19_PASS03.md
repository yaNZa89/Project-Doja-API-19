# PocketDoJa 1.3.0a — Android 4.4 / API 19 porting pass 03

## Changes in this pass

### 1. Locale compatibility
- Found two runtime calls to `Locale.forLanguageTag()` in `LocaleHelper`.
- Android documents this method as API 21+, so the calls could fail on Android 4.4.
- Added `LocaleTagCompat`, which uses a nested API-21 helper on newer devices and a legacy `Locale(language, country, variant)` parser on API 19–20.
- Updated both locale-loading paths in `LocaleHelper` to use the compatibility helper.
- Added a plain-Java smoke test for all 15 configured language tags.

### 2. AudioTrack compatibility
- Found an unguarded `AudioTrack.Builder` call in `AndroidSourceDataLine`, despite the previous pass having isolated builder use in `MldBgmPlayer`.
- Added an API 19–22 fallback using the legacy `AudioTrack(int streamType, int sampleRate, int channelConfig, int audioFormat, int bufferSize, int mode)` constructor.
- Isolated the API-23+ `AudioTrack.Builder` path in a nested helper.

### 3. Vibration compatibility
- Found direct API 26 `VibrationEffect` and API 31 `VibratorManager` references in `DoJaVibrationSupport`.
- Moved those calls into nested API-specific helpers. The API 19 path continues to use `Vibrator.vibrate(long[], int)` and the legacy vibrator service.

## Validation performed
- `LocaleTagCompat` compiled with the installed JDK 21.
- Locale smoke test passed for all 15 configured languages, comparing API 19 fallback output with the API 21+ parser for language and region.
- `AndroidSourceDataLine`, `DoJaVibrationSupport`, and `LocaleTagCompat` compiled against lightweight API-shaped Android stubs to catch Java syntax/type-shape errors.
- Static scans confirmed newer AudioTrack builder, VibrationEffect, VibratorManager, and Locale.forLanguageTag references are confined to API-specific nested helpers.
- Attempted `bash gradlew --offline :app:assembleDebug`; the wrapper still attempted to fetch Gradle 8.13 and failed with `UnknownHostException: services.gradle.org`.
- No Android SDK (`android.jar`, `aapt`, `d8`, or `adb`) is installed in this environment.

## Remaining blockers / status
- This remains a source-level compatibility pass. No APK was built, installed, or tested on Android 4.4.
- A complete lint/API audit with the real Android SDK is still required.
- Gradle 8.13 and Android SDK 34 build tools must be available to produce an APK.
- Audio output, vibration, filesystem NIO desugaring, storage access, and game launch still need device/emulator tests on API 19.
