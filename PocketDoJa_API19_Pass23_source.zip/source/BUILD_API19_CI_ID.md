# Jalur build alternatif: GitHub Actions

Jalur ini sengaja **tidak menurunkan Gradle/AGP**. Source saat ini menggunakan AGP 8.13.2 + Gradle 8.13 + JDK 17 + compileSdk 34. Kombinasi ini dipertahankan, sedangkan build dipindahkan ke runner Linux yang dapat mengunduh Gradle dan Android SDK.

## Cara menjalankan
1. Buat repository GitHub kosong.
2. Unggah/commit seluruh isi folder project ini ke branch `main`.
3. Buka tab **Actions**.
4. Pilih workflow **PocketDoJa Android build (API 19 target)**.
5. Tekan **Run workflow**.
6. Jika build berhasil, unduh artifact `pocketdoja-api19-debug-build` dari halaman run.

Workflow memasang JDK 17, Android platform 34, Build Tools 35.0.0, lalu menjalankan:

```sh
./gradlew --no-daemon --stacktrace :app:assembleDebug
```

Build debug dipilih karena release build proyek meminta signing properties privat yang tidak tersedia di source archive.

## Batasan penting
- Workflow ini memecahkan **kendala lingkungan build lokal** (tidak ada Android SDK dan DNS untuk unduh Gradle di workspace ini).
- Workflow belum membuktikan kompatibilitas runtime Android 4.4. Keberhasilan compile/packaging bukan bukti instalasi atau launch di API 19.
- Source runtime masih memerlukan audit/migrasi API Android dan Java yang tidak tersedia pada API 19, khususnya `java.nio.file` dan framework API 21/23. Jangan menganggap APK hasil CI siap dipakai di Android 4.4 sebelum uji emulator/perangkat.
- Jangan memasukkan signing key atau password ke repository. Untuk debug APK, signing debug otomatis.
