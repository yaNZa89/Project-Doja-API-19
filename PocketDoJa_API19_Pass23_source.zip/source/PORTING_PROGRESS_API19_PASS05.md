# PocketDoJa 1.3.0a — Android 4.4 / API 19 porting pass 05

## Focus: game JAR → Dalvik DEX → resource access

This pass validates the actual conversion path against the supplied Monster Hunter i for SH game package (`mhi_9.jam` + `mhi_9.jar`). It does not claim a full Android APK build or on-device game launch.

### Source changes

1. Replaced the `zip4j` archive reader in `dexlib`'s `ClassPathOpener` with `java.util.zip.ZipFile` / `ZipEntry`.
   - The dx converter only needs standard ZIP/JAR entry enumeration, CRC values, and input streams.
   - This removes the `zip4j` dependency from the `dexlib` module and makes the conversion archive reader use the JDK/Android ZIP implementation already used elsewhere in the app.
   - Removed the now-unused `ru.woesss.util.zip.ZipFile` adapter.
2. Added a DEX 035 structural validation gate in `JamDexHost`.
   - Checks the exact `dex\n035\0` magic required for the classic Dalvik DEX format used by Android 4.4.
   - Parses the result through `com.android.dex.Dex` and requires at least one class definition.
   - Cached DEX files are now checked with the same validator before being reused.
   - A malformed/non-Dalvik output is deleted and cannot receive the `.dex.ok` completion marker.
3. Bumped `DEX_REWRITE_VERSION` from 5 to 6 so prior cache markers are regenerated under the new validation path.
4. Made the JAR resource URL fallback encode spaces and non-ASCII characters in both the game JAR path and resource entry path.
5. Added a reusable host-side JAR-to-DEX smoke test script at `porting-tests/run-jam-dex-smoke.sh`.

### Actual game package inspection

The supplied `mhi_9.jam` identifies:
- AppName: `Monster Hunter i for SH`
- AppClass: `main`
- ProfileVer: `DoJa-5.0`
- TargetDevice: `SH904i`
- DrawArea: `240x320`

The supplied `mhi_9.jar` contains 5 class files (`a.class`, `b.class`, `c.class`, `d.class`, `main.class`) and 12 non-class resource entries, including `tdata.dat`, `map.dat`, `enemy.dat`, and `SH903i.dat`.

### Validation performed in this environment

Ran:

```sh
./porting-tests/run-jam-dex-smoke.sh /mnt/data/mhi_9.jar
```

Result:
- dexlib sources compiled with `javac -source 8 -target 8`.
- The project's dx `Main` converted the actual game JAR to a DEX file.
- Output magic was `dex\n035\0`.
- The DEX parser accepted the file and enumerated 5 class definitions.
- The dx archive reader enumerated the same 5 class entries from the original JAR.
- All 12 non-class resource entries could be opened and read from the JAR.
- Test result: `PASS: dx archive input, DEX 035 parsing, class counts, checksums, and JAR asset reads`.

The generated test DEX was 421,492 bytes. The repeatable smoke test verified that its SHA-1 signature and Adler-32 checksum match the DEX header.

### Remaining limitations

- The host-side test uses the same dx converter and archive reader, but does not execute `DexClassLoader` because this environment has no Android runtime/SDK.
- The app's ASM rewrite pass (`rewriteSjisInJar`) was not executed in this host smoke test; its behavior remains part of the Android app path.
- No full Gradle APK build, APK signing, installation, or Android 4.4 emulator/device test has been completed.
- The test confirms DEX 035 generation and JAR asset readability; it does not prove that Monster Hunter reaches its title screen or is playable.
