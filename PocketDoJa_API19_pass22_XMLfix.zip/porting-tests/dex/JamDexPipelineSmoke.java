import com.android.dex.ClassDef;
import com.android.dex.Dex;
import com.android.dx.cf.direct.ClassPathOpener;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.zip.Adler32;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/** Host-side smoke test for the same dx archive reader and DEX format used by JamDexHost. */
public final class JamDexPipelineSmoke {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: JamDexPipelineSmoke <game.jar> <game.dex>");
        }
        File jarPath = new File(args[0]);
        File dexPath = new File(args[1]);
        if (!jarPath.isFile() || !dexPath.isFile()) {
            throw new IOException("input JAR or output DEX does not exist");
        }

        Set<String> jarClasses = new HashSet<>();
        Set<String> jarResources = new HashSet<>();
        try (JarFile jar = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.isDirectory()) continue;
                if (entry.getName().endsWith(".class")) {
                    jarClasses.add(entry.getName());
                } else {
                    jarResources.add(entry.getName());
                    // Confirm that every non-class game asset is readable from the original JAR.
                    try (java.io.InputStream in = jar.getInputStream(entry)) {
                        byte[] buffer = new byte[8192];
                        while (in.read(buffer) != -1) { /* drain */ }
                    }
                }
            }
        }

        final Set<String> dxArchiveClasses = new HashSet<>();
        final ArrayList<Exception> archiveErrors = new ArrayList<>();
        new ClassPathOpener(jarPath.getAbsolutePath(), true, ClassPathOpener.acceptAll,
                new ClassPathOpener.Consumer() {
                    @Override public boolean processFileBytes(String name, long modified, byte[] bytes) {
                        if (name.endsWith(".class")) dxArchiveClasses.add(name);
                        return true;
                    }
                    @Override public void onException(Exception exception) { archiveErrors.add(exception); }
                    @Override public void onProcessArchiveStart(File file) { }
                }).process();
        if (!archiveErrors.isEmpty()) throw new IOException("dx archive reader failed", archiveErrors.get(0));
        if (!jarClasses.equals(dxArchiveClasses)) {
            throw new AssertionError("dx archive reader class set differs from JAR: " + dxArchiveClasses);
        }

        byte[] magic = new byte[8];
        try (FileInputStream input = new FileInputStream(dexPath)) {
            if (input.read(magic) != magic.length) throw new IOException("short DEX header");
        }
        if (magic[0] != 'd' || magic[1] != 'e' || magic[2] != 'x' || magic[3] != '\n'
                || magic[4] != '0' || magic[5] != '3' || magic[6] != '5' || magic[7] != 0) {
            throw new AssertionError("output is not Dalvik-compatible DEX 035");
        }

        byte[] dexBytes = java.nio.file.Files.readAllBytes(dexPath.toPath());
        byte[] expectedSignature = MessageDigest.getInstance("SHA-1")
                .digest(Arrays.copyOfRange(dexBytes, 32, dexBytes.length));
        if (!Arrays.equals(expectedSignature, Arrays.copyOfRange(dexBytes, 12, 32))) {
            throw new AssertionError("DEX SHA-1 signature mismatch");
        }
        Adler32 adler = new Adler32();
        adler.update(dexBytes, 12, dexBytes.length - 12);
        long expectedChecksum = ByteBuffer.wrap(dexBytes, 8, 4)
                .order(ByteOrder.LITTLE_ENDIAN).getInt() & 0xffffffffL;
        if (adler.getValue() != expectedChecksum) {
            throw new AssertionError("DEX Adler-32 checksum mismatch");
        }

        Dex dex = new Dex(dexPath);
        Set<String> dexClasses = new HashSet<>();
        for (ClassDef definition : dex.classDefs()) {
            dexClasses.add(dex.typeNames().get(definition.getTypeIndex()).substring(1,
                    dex.typeNames().get(definition.getTypeIndex()).length() - 1) + ".class");
        }
        if (dexClasses.size() != jarClasses.size()) {
            throw new AssertionError("DEX class count " + dexClasses.size()
                    + " differs from JAR class count " + jarClasses.size());
        }
        System.out.println("DEX magic: dex\\n035");
        System.out.println("JAR classes: " + jarClasses.size() + " | DEX classes: " + dexClasses.size());
        System.out.println("Game resource entries: " + jarResources.size());
        System.out.println("DEX SHA-1 signature: valid | Adler-32 checksum: valid");
        System.out.println("PASS: dx archive input, DEX 035 parsing, class counts, checksums, and JAR asset reads");
    }
}
