#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/game.jar" >&2
  exit 2
fi

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GAME_JAR="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
if [[ ! -f "$GAME_JAR" ]]; then
  echo "Game JAR not found: $GAME_JAR" >&2
  exit 2
fi

WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT
mkdir -p "$WORK_DIR/classes"
find "$ROOT_DIR/dexlib/src/main/java" -name '*.java' ! -path '*/ru/woesss/util/zip/*' > "$WORK_DIR/sources.txt"
printf '%s\n' "$ROOT_DIR/porting-tests/dex/JamDexPipelineSmoke.java" >> "$WORK_DIR/sources.txt"

javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options \
  -d "$WORK_DIR/classes" @"$WORK_DIR/sources.txt"
java -cp "$WORK_DIR/classes" com.android.dx.command.dexer.Main \
  --no-optimize --no-strict --min-sdk-version=1 \
  --output="$WORK_DIR/game.dex" "$GAME_JAR"
java -cp "$WORK_DIR/classes" JamDexPipelineSmoke "$GAME_JAR" "$WORK_DIR/game.dex"
