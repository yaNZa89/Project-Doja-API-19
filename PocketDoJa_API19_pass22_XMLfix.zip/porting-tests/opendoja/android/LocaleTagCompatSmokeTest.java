package opendoja.android;

import java.util.Locale;

/** Run with javac/java to check the API 19 language-tag fallback. */
public final class LocaleTagCompatSmokeTest {
    public static void main(String[] args) {
        String[] tags = {"en", "zh-CN", "zh-TW", "th", "ja", "ko", "es", "vi",
                "ms", "fil", "ta", "ru", "pt-BR", "fr", "pl"};
        for (String tag : tags) {
            Locale legacy = LocaleTagCompat.forLanguageTag(tag, 19);
            Locale modern = LocaleTagCompat.forLanguageTag(tag, 21);
            if (!legacy.getLanguage().equalsIgnoreCase(modern.getLanguage())
                    || !legacy.getCountry().equalsIgnoreCase(modern.getCountry())) {
                throw new AssertionError(tag + ": API19=" + legacy + ", API21+=" + modern);
            }
        }
        System.out.println("PASS: " + tags.length + " configured language tags match on API 19 fallback.");
    }
}
