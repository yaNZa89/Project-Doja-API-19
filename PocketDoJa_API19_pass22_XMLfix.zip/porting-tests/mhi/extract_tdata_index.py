#!/usr/bin/env python3
"""Parse Monster Hunter i tdata.dat's indexed embedded ZIP records.

The directory format is read-only and deliberately conservative:
  byte 0       = number of entries N
  bytes 1..2N  = N little-endian 16-bit ZIP-block lengths
  next region  = N consecutive ZIP local-file records, in directory order

Each record is validated by DEFLATE/STORE decompression, uncompressed size,
CRC32, and its local ZIP signature before it is written.
"""
from __future__ import annotations
import argparse, hashlib, json, struct, zlib
from pathlib import Path


def parse(data: bytes):
    if len(data) < 1:
        raise ValueError('empty tdata.dat')
    count = data[0]
    directory_end = 1 + 2 * count
    if directory_end > len(data):
        raise ValueError('truncated length directory')
    lengths = struct.unpack_from('<' + 'H' * count, data, 1)
    cursor = directory_end
    rows = []
    for index, block_len in enumerate(lengths):
        end = cursor + block_len
        if end > len(data):
            raise ValueError(f'entry {index}: block exceeds tdata.dat')
        block = data[cursor:end]
        if len(block) < 30:
            raise ValueError(f'entry {index}: short ZIP local header')
        (sig, _ver, flags, method, _time, _date, crc, comp_size,
         raw_size, name_len, extra_len) = struct.unpack_from('<IHHHHHIIIHH', block)
        if sig != 0x04034B50:
            raise ValueError(f'entry {index}: invalid ZIP signature {sig:#x}')
        if flags & 1:
            raise ValueError(f'entry {index}: encrypted ZIP entry unsupported')
        name_start = 30
        name_end = name_start + name_len
        payload_start = name_end + extra_len
        if payload_start + comp_size > len(block):
            raise ValueError(f'entry {index}: compressed payload exceeds block')
        name = block[name_start:name_end].decode('utf-8', 'replace')
        compressed = block[payload_start:payload_start + comp_size]
        if method == 0:
            raw = compressed
        elif method == 8:
            raw = zlib.decompress(compressed, -15)
        else:
            raise ValueError(f'entry {index}: unsupported ZIP method {method}')
        if len(raw) != raw_size:
            raise ValueError(f'entry {index}: size mismatch {len(raw)} != {raw_size}')
        actual_crc = zlib.crc32(raw) & 0xffffffff
        if actual_crc != crc:
            raise ValueError(f'entry {index}: CRC mismatch {actual_crc:08x} != {crc:08x}')
        rows.append({
            'index': index,
            'name': name,
            'block_offset_in_tdata': cursor,
            'block_size': block_len,
            'zip_method': method,
            'compressed_size': comp_size,
            'uncompressed_size': raw_size,
            'crc32': f'{crc:08x}',
            'sha256': hashlib.sha256(raw).hexdigest(),
            'data': raw,
        })
        cursor = end
    if cursor != len(data):
        raise ValueError(f'{len(data)-cursor} trailing bytes after indexed records')
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('jar', type=Path, help='original mhi_9.jar')
    ap.add_argument('out', type=Path, help='output directory')
    args = ap.parse_args()
    import zipfile
    with zipfile.ZipFile(args.jar) as jar:
        tdata = jar.read('tdata.dat')
    rows = parse(tdata)
    args.out.mkdir(parents=True, exist_ok=True)
    assets = args.out / 'assets'
    assets.mkdir(exist_ok=True)
    manifest = []
    for row in rows:
        path = assets / row['name']
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(row['data'])
        manifest.append({k: v for k, v in row.items() if k != 'data'})
    (args.out / 'tdata_index.json').write_text(json.dumps({
        'source': 'mhi_9.jar!tdata.dat',
        'entry_count': len(rows),
        'directory_format': 'u8 count + count*u16le ZIP-block lengths + concatenated ZIP local records',
        'total_uncompressed_bytes': sum(r['uncompressed_size'] for r in rows),
        'entries': manifest,
    }, indent=2), encoding='utf-8')
    print(f'validated {len(rows)} indexed records; {sum(r["uncompressed_size"] for r in rows)} bytes')

if __name__ == '__main__':
    main()
