import java.nio.file.*;
import java.io.*;
import opendoja.g3d.MascotLoader;
import opendoja.g3d.MascotActionTableData;
public class MascotAnimationSmokeTest {
 public static void main(String[] args)throws Exception{
  Path d=Paths.get(args[0]);int pairs=0,actions=0,frames=0;
  try(DirectoryStream<Path> fs=Files.newDirectoryStream(d,"m_*.mtra")){
   for(Path p:fs){String base=p.getFileName().toString().substring(2).replace(".mtra","");byte[] b=Files.readAllBytes(p);MascotActionTableData a=MascotLoader.loadActionTable(b);int[] out=new int[a.numBones()*12];
    for(int act=0;act<a.numActions();act++){int max=a.maxFrame(act)>>16;actions++;for(int frame=0;frame<=max;frame++){a.writeMatricesFixed(act,frame<<16,out);for(int v:out){/* force all output slots to be read */}frames++;}}
    System.out.println("ANIM PASS "+base+" actions="+a.numActions()+" evaluatedFrames="+frames);
    pairs++;
   }
  }
  System.out.println("ANIM SUMMARY tables="+pairs+" actions="+actions+" frames="+frames);
 }
}
