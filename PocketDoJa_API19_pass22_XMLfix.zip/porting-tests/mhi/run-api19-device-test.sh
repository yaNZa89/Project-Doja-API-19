#!/usr/bin/env bash
# End-to-end API 19 test for the supplied Monster Hunter i for SH package.
# Requires Android SDK/Gradle and an Android 4.4 (API 19) emulator/device on adb.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
PROJECT_DIR="$ROOT_DIR"
JAM_FILE="${1:-}"
JAR_FILE="${2:-}"
SP_FILE="${3:-}"
ADB="${ADB:-adb}"
GRADLEW="$PROJECT_DIR/gradlew"

if [[ -z "$JAM_FILE" || -z "$JAR_FILE" ]]; then
  echo "Usage: $0 /path/to/mhi_9.jam /path/to/mhi_9.jar [/path/to/mhi_9.sp]" >&2
  exit 2
fi
[[ -f "$JAM_FILE" ]] || { echo "Missing JAM: $JAM_FILE" >&2; exit 2; }
[[ -f "$JAR_FILE" ]] || { echo "Missing JAR: $JAR_FILE" >&2; exit 2; }
if [[ -n "$SP_FILE" && ! -f "$SP_FILE" ]]; then
  echo "Missing SP: $SP_FILE" >&2; exit 2
fi

# Check the build prerequisites before waiting for a device or starting Gradle.
if ! command -v "$ADB" >/dev/null 2>&1; then
  echo "Missing adb; install Android platform-tools and add them to PATH (or set ADB)." >&2
  exit 5
fi
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT is not set; point it to an installed Android SDK." >&2
  exit 5
fi
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT}}"
if [[ ! -f "$SDK_ROOT/platforms/android-34/android.jar" ]]; then
  echo "Missing Android SDK platform 34: expected $SDK_ROOT/platforms/android-34/android.jar" >&2
  exit 5
fi
if [[ ! -f "$GRADLEW" ]]; then
  echo "Missing Gradle wrapper: $GRADLEW" >&2
  exit 5
fi

"$ADB" wait-for-device
SDK="$($ADB shell getprop ro.build.version.sdk | tr -d '\r')"
if [[ "$SDK" != "19" ]]; then
  echo "Refusing to label this an API 19 test: connected device reports API $SDK (expected 19)." >&2
  exit 3
fi

cd "$PROJECT_DIR"
bash "$GRADLEW" --no-daemon :app:assembleDebug
APK="$PROJECT_DIR/app/build/outputs/apk/debug/PocketDoJa-v1.3.0a.apk"
[[ -f "$APK" ]] || { echo "Build completed but expected APK is missing: $APK" >&2; exit 4; }

APP_ID="com.shibesan.pocketdoja"
DEVICE_DIR="/sdcard/Download/PocketDoJa_API19_Test"
"$ADB" install -r "$APK"
"$ADB" shell mkdir -p "$DEVICE_DIR"
"$ADB" push "$JAM_FILE" "$DEVICE_DIR/mhi_9.jam"
"$ADB" push "$JAR_FILE" "$DEVICE_DIR/mhi_9.jar"
if [[ -n "$SP_FILE" ]]; then
  "$ADB" push "$SP_FILE" "$DEVICE_DIR/mhi_9.sp"
fi

"$ADB" logcat -c
"$ADB" shell am start -n "$APP_ID/opendoja.android.EntryActivity" \
  --es jamPath "$DEVICE_DIR/mhi_9.jam"
echo
printf '%s\n' "Launched Monster Hunter i for SH on API 19." \
  "Wait for the first title/menu frame and test touch + keypad input." \
  "Then collect crash/runtime output with:" \
  "$ADB logcat -d -s AndroidRuntime:E OpenDoJa:V"
