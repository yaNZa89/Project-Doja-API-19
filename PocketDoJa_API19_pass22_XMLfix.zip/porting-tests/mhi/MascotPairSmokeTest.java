import java.nio.file.*;
import java.io.*;
import java.util.*;
import opendoja.g3d.MascotLoader;
import opendoja.g3d.MbacModel;
import opendoja.g3d.MascotActionTableData;
public class MascotPairSmokeTest {
 public static void main(String[] args)throws Exception{
  Path d=Paths.get(args[0]); int matched=0, mismatch=0;
  try(DirectoryStream<Path> fs=Files.newDirectoryStream(d,"f_*.mbac")){
   for(Path f:fs){String base=f.getFileName().toString().substring(2).replace(".mbac","");Path a=d.resolve("m_"+base+".mtra");if(!Files.exists(a))continue;
    MbacModel model=MascotLoader.loadFigure(Files.readAllBytes(f));MascotActionTableData action=MascotLoader.loadActionTable(Files.readAllBytes(a));
    boolean ok=model.bones().length==action.numBones();
    System.out.println((ok?"PAIR PASS ":"PAIR MISMATCH ")+base+" modelBones="+model.bones().length+" actionBones="+action.numBones()+" actions="+action.numActions());
    if(ok)matched++;else mismatch++;
   }
  }
  System.out.println("PAIR SUMMARY matched="+matched+" mismatch="+mismatch);
  if(mismatch>0)System.exit(3);
 }
}
