# Monster Hunter i for SH — Android 4.4 runtime test

This test is intentionally an on-device test. A host JVM check or a valid DEX
header is not a substitute for Dalvik `DexClassLoader` execution.

## Test chain

1. Build the debug APK with the project's Gradle wrapper.
2. Require a connected Android API 19 device/emulator (the script checks
   `ro.build.version.sdk == 19`).
3. Install the APK.
4. Push the original `mhi_9.jam`, `mhi_9.jar`, and optional `mhi_9.sp` to
   `/sdcard/Download/PocketDoJa_API19_Test`.
5. Start `EntryActivity` with the JAM path. This follows the same application
   path used by the app: JAM/JAR locate → `JamDexHost.ensureDex` → DEX 035
   validation → `DexClassLoader` provider → `JamLauncher` resolves `AppClass`
   → `DesktopLauncher` calls the DoJa application lifecycle.
6. Confirm the title/menu frame appears, then test keypad/touch controls.

## Run

```sh
porting-tests/mhi/run-api19-device-test.sh /path/to/mhi_9.jam /path/to/mhi_9.jar /path/to/mhi_9.sp
```

If the app fails, collect:

```sh
adb logcat -d -s AndroidRuntime:E OpenDoJa:V
```

## What this test does not claim

No API 19 emulator or Android SDK is bundled with this source archive. The
script has not been run in this workspace. The static checks from pass 07 only
verify JAM metadata, class hierarchy, resource names, and DEX 035 structure;
they do not verify Dalvik class loading, Android rendering, audio, or gameplay.
