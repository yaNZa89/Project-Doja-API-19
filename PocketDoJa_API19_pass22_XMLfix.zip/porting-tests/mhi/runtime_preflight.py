#!/usr/bin/env python3
"""Static launch preflight for the supplied Monster Hunter i for SH JAM/JAR.

This checks archive metadata, class-file hierarchy/API references, and resource
names used by the original bytecode against the OpenDoJa source tree. It does
not execute Dalvik code or claim a successful Android launch.
"""
from __future__ import annotations
import argparse
import pathlib
import struct
import sys
import zipfile


def read_u1(data: bytes, pos: int):
    return data[pos], pos + 1


def read_u2(data: bytes, pos: int):
    return struct.unpack_from('>H', data, pos)[0], pos + 2


def parse_class(data: bytes):
    if data[:4] != b'\xca\xfe\xba\xbe':
        raise ValueError('bad class-file magic')
    minor, major = struct.unpack_from('>HH', data, 4)
    count = struct.unpack_from('>H', data, 8)[0]
    pos = 10
    cp = [None] * count
    i = 1
    while i < count:
        tag, pos = read_u1(data, pos)
        if tag == 1:
            size, pos = read_u2(data, pos)
            raw = data[pos:pos + size]
            pos += size
            cp[i] = ('utf8', raw.decode('utf-8', 'replace'))
        elif tag in (3, 4):
            pos += 4
        elif tag in (5, 6):
            pos += 8
            i += 1
        elif tag in (7, 8, 16, 19, 20):
            index, pos = read_u2(data, pos)
            cp[i] = (tag, index)
        elif tag in (9, 10, 11, 12, 17, 18):
            pos += 4
        elif tag == 15:
            pos += 3
        else:
            raise ValueError(f'unsupported constant-pool tag {tag}')
        i += 1
    access, pos = read_u2(data, pos)
    this_idx, pos = read_u2(data, pos)
    super_idx, pos = read_u2(data, pos)

    def class_name(index):
        if not index:
            return None
        item = cp[index]
        if not item or item[0] != 7:
            return None
        utf = cp[item[1]]
        return utf[1] if utf and utf[0] == 'utf8' else None

    class_refs = set()
    strings = set()
    for index, item in enumerate(cp):
        if not item:
            continue
        if item[0] == 7:
            name = class_name(index)
            if name:
                class_refs.add(name)
        elif item[0] == 8:
            utf = cp[item[1]]
            if utf and utf[0] == 'utf8':
                strings.add(utf[1])
    return {
        'minor': minor, 'major': major, 'this': class_name(this_idx),
        'super': class_name(super_idx), 'class_refs': class_refs,
        'strings': strings,
    }


def parse_jam(path: pathlib.Path):
    props = {}
    for raw in path.read_text(encoding='latin-1').splitlines():
        line = raw.strip()
        if not line or line.startswith(('#', '!')) or '=' not in line:
            continue
        k, v = line.split('=', 1)
        props[k.strip()] = v.strip()
    return props


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('jam', type=pathlib.Path)
    parser.add_argument('jar', type=pathlib.Path)
    parser.add_argument('--opendoja-src', type=pathlib.Path, required=True)
    args = parser.parse_args()

    props = parse_jam(args.jam)
    print('JAM metadata:')
    for key in ('AppName', 'AppClass', 'ProfileVer', 'TargetDevice', 'DrawArea', 'SPsize', 'AppParam'):
        print(f'  {key}={props.get(key, "<missing>")}')

    with zipfile.ZipFile(args.jar) as jar:
        names = set(jar.namelist())
        class_entries = sorted(n for n in names if n.endswith('.class'))
        parsed = {}
        for entry in class_entries:
            parsed[entry[:-6].replace('/', '.')] = parse_class(jar.read(entry))
        app_name = props.get('AppClass', '')
        if app_name not in parsed:
            raise SystemExit(f'FAIL: AppClass {app_name!r} not found in JAR')
        app = parsed[app_name]
        if app['super'] != 'com/nttdocomo/ui/IApplication':
            raise SystemExit(f"FAIL: {app_name} extends {app['super']}, not IApplication")

        src_root = args.opendoja_src
        source_classes = set()
        for java in src_root.rglob('*.java'):
            source_classes.add('.'.join(java.relative_to(src_root).with_suffix('').parts))
        api_refs = set()
        string_constants = set()
        max_major = 0
        for info in parsed.values():
            max_major = max(max_major, info['major'])
            for ref in info['class_refs']:
                if ref.startswith(('com/nttdocomo/', 'com/docomostar/')):
                    api_refs.add(ref.replace('/', '.'))
            string_constants.update(info['strings'])

        missing = sorted(name for name in api_refs if name not in source_classes)
        print(f'JAR class files: {len(class_entries)}; maximum class major: {max_major}')
        print(f'AppClass hierarchy: {app_name} -> {app["super"].replace("/", ".")} [PASS]')
        print(f'DoJa API class references: {len(api_refs)}; source classes found: {len(api_refs)-len(missing)}')
        if missing:
            for name in missing:
                print('  MISSING API SOURCE:', name)
            raise SystemExit(1)

        resource_literals = set()
        for value in string_constants:
            if value == '.dat' or value == 'resource:///' :
                continue
            if value.endswith('.dat') or (value.startswith('resource:///') and len(value) > len('resource:///')):
                resource_literals.add(value)
        resolved = {}
        for literal in sorted(resource_literals):
            candidate = literal.removeprefix('resource:///').lstrip('/')
            resolved[literal] = candidate in names
        absent = [k for k, ok in resolved.items() if not ok]
        print(f'Resource-like string constants: {len(resolved)}; present in JAR: {len(resolved)-len(absent)}')
        for literal, ok in sorted(resolved.items()):
            print(f'  {"PASS" if ok else "MISSING"} {literal}')
        if absent:
            raise SystemExit(1)

    expected = {
        'AppName': 'Monster Hunter i for SH',
        'AppClass': 'main',
        'ProfileVer': 'DoJa-5.0',
        'TargetDevice': 'SH904i',
        'DrawArea': '240x320',
        'SPsize': '56320',
    }
    bad = [f'{k}: expected {v!r}, got {props.get(k)!r}' for k, v in expected.items() if props.get(k) != v]
    if bad:
        print('\n'.join(bad), file=sys.stderr)
        raise SystemExit(1)
    print('PASS: JAM/JAR static launch preflight (not an Android runtime test)')


if __name__ == '__main__':
    main()
