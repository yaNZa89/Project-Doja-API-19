# Monster Hunter i for SH — Mascot asset smoke tests

These host-side tests exercise the emulator's existing `opendoja.g3d.MascotLoader`
against the original game's indexed resources in `mhi_9.jar`.

Run:

```sh
./porting-tests/mhi/run-mascot-smoke.sh /path/to/mhi_9.jar
```

The test extracts and CRC-validates all 57 records from `tdata.dat`, parses all
18 `.mbac` model resources and all 10 `.mtra` action tables, checks all 10
same-name model/action pairs for matching bone counts, and evaluates every
frame in all action tables through `MascotActionTableData.writeMatricesFixed`.

This is a host JVM test of the existing parser/animation data path. It does not
exercise Android `DexClassLoader`, the Android OpenGL ES backend, the game's
DoJa UI lifecycle, or prove that the title screen/gameplay runs on a device.

## Monster Hunter i for SH runtime launch preflight

The following static preflight checks the supplied JAM/JAR pair against the
OpenDoJa source tree. It verifies the JAM launch identity, the `main` class
superclass, DoJa API class coverage, and resource names referenced as string
constants by the original class files.

```sh
python3 porting-tests/mhi/runtime_preflight.py \
  /path/to/mhi_9.jam /path/to/mhi_9.jar \
  --opendoja-src opendoja/src/main/java
```

This is a static linkage/resource preflight only. It does not run Dalvik's
`DexClassLoader`, instantiate the game on Android, or prove that the title
reaches its first screen.
