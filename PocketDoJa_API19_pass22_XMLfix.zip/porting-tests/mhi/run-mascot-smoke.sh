#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
JAR="${1:?Usage: run-mascot-smoke.sh /path/to/mhi_9.jar}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$ROOT/porting-tests/mhi/extract_tdata_index.py" "$JAR" "$TMP/extracted"
ASSETS="$TMP/extracted/assets"
CLASSES="$TMP/classes"
mkdir -p "$CLASSES"
SRC="$ROOT/opendoja/src/main/java"
javac -d "$CLASSES" \
  "$SRC/opendoja/host/ByteStreams.java" \
  "$SRC/opendoja/g3d/FixedPoint.java" \
  "$SRC/opendoja/g3d/MbacModel.java" \
  "$SRC/opendoja/g3d/MascotActionTableData.java" \
  "$SRC/opendoja/g3d/MascotLoader.java" \
  "$ROOT/porting-tests/mhi/MascotAssetSmokeTest.java" \
  "$ROOT/porting-tests/mhi/MascotPairSmokeTest.java" \
  "$ROOT/porting-tests/mhi/MascotAnimationSmokeTest.java"
java -cp "$CLASSES" MascotAssetSmokeTest "$ASSETS"
java -cp "$CLASSES" MascotPairSmokeTest "$ASSETS"
java -cp "$CLASSES" MascotAnimationSmokeTest "$ASSETS"
