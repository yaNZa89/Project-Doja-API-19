import java.nio.file.*;
import java.io.*;
import opendoja.g3d.MascotLoader;
import opendoja.g3d.MbacModel;
import opendoja.g3d.MascotActionTableData;

public class MascotAssetSmokeTest {
  public static void main(String[] args) throws Exception {
    Path dir = Paths.get(args[0]);
    int modelOk=0, actionOk=0, fail=0;
    try (DirectoryStream<Path> files=Files.newDirectoryStream(dir)) {
      for (Path p: files) {
        String n=p.getFileName().toString().toLowerCase();
        byte[] b=Files.readAllBytes(p);
        try {
          if (n.endsWith(".mbac")) {
            MbacModel m=MascotLoader.loadFigure(b);
            int tris=0, quads=0, bones=m.bones().length;
            for (MbacModel.Polygon poly:m.polygons()) { if(poly.indices().length==3) tris++; else if(poly.indices().length==4) quads++; }
            System.out.println("MBAC PASS "+n+" bytes="+b.length+" vertices="+(m.rawVertices().length/3)+" polygons="+m.polygons().length+" tris="+tris+" quads="+quads+" bones="+bones+" patterns="+m.numPatterns());
            modelOk++;
          } else if (n.endsWith(".mtra")) {
            MascotActionTableData a=MascotLoader.loadActionTable(b);
            System.out.println("MTRA PASS "+n+" bytes="+b.length+" actions="+a.numActions()+" bones="+a.numBones());
            for(int i=0;i<a.numActions();i++) System.out.print((i==0?" maxFrames=":",")+ (a.maxFrame(i)>>16));
            System.out.println(); actionOk++;
          }
        } catch(Throwable t) {
          System.out.println("FAIL "+n+" bytes="+b.length+" "+t.getClass().getName()+": "+t.getMessage());
          fail++;
        }
      }
    }
    System.out.println("SUMMARY mbac="+modelOk+" mtra="+actionOk+" fail="+fail);
    if(fail>0) System.exit(2);
  }
}
