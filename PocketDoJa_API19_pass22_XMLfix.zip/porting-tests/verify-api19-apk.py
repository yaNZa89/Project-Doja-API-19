#!/usr/bin/env python3
"""Verify the basic APK metadata and DEX format required by Android 4.4/Dalvik."""
from pathlib import Path
import re
import subprocess
import sys
import zipfile

if len(sys.argv) not in (3, 4):
    print("Usage: verify-api19-apk.py <apk-path> <aapt-path> [expected-min-sdk]")
    sys.exit(2)

apk = Path(sys.argv[1])
aapt = Path(sys.argv[2])
expected_min_sdk = sys.argv[3] if len(sys.argv) == 4 else "19"
if not apk.is_file():
    raise SystemExit(f"APK not found: {apk}")
if not aapt.is_file():
    raise SystemExit(f"aapt not found: {aapt}")

badging = subprocess.check_output([str(aapt), "dump", "badging", str(apk)], text=True, errors="replace")
package = re.search(r"^package: name='([^']+)'", badging, re.M)
sdk = re.search(r"^sdkVersion:'([^']+)'", badging, re.M)
if not package:
    raise SystemExit("Could not read package name from APK manifest")
if not sdk or sdk.group(1) != expected_min_sdk:
    raise SystemExit(
        f"APK minSdk must be {expected_min_sdk}; found {sdk.group(1) if sdk else 'missing'}"
    )

with zipfile.ZipFile(apk) as archive:
    dex_names = sorted(
        (name for name in archive.namelist() if re.fullmatch(r"classes(?:[2-9]|[1-9][0-9]+)?\.dex", name)),
        key=lambda name: 1 if name == "classes.dex" else int(re.search(r"([0-9]+)", name).group(1)),
    )
    if not dex_names or "classes.dex" not in dex_names:
        raise SystemExit("APK contains no classes.dex")
    versions = {}
    for name in dex_names:
        header = archive.read(name)[:8]
        if len(header) != 8 or header[:4] != b"dex\n" or header[7] != 0:
            raise SystemExit(f"Invalid DEX header in {name}: {header!r}")
        version = header[4:7].decode("ascii", errors="replace")
        versions[name] = version
        if version != "035":
            raise SystemExit(f"{name} uses DEX {version}; Android 4.4 Dalvik requires DEX 035")

print(f"APK verification (minSdk {expected_min_sdk}): PASS")
print(f" - package: {package.group(1)}")
print(f" - minSdk: {sdk.group(1)}")
print(f" - DEX files: {len(dex_names)}; versions: {', '.join(sorted(set(versions.values())))}")
