#!/usr/bin/env python3
"""Static API-19 compatibility guard for every Java source shipped in PocketDoJa."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOTS = {
    "app": ROOT / "app/src/main/java",
    "opendoja": ROOT / "opendoja/src/main/java",
    "dexlib": ROOT / "dexlib/src/main/java",
}
# These directories are developer tools/tests, not part of app's Android source set.
OPEN_DOJA_EXCLUDED_PREFIXES = (
    "opendoja/launcher/",
    "opendoja/probes/",
    "opendoja/tools/",
)
OPEN_DOJA_EXCLUDED_FILES = {
    "opendoja/host/input/ControllerInputManagerProbe.java",
}

sources = []
for module, base in SOURCE_ROOTS.items():
    if not base.is_dir():
        print(f"ERROR: expected Android source directory is missing: {base}")
        sys.exit(2)
    for path in base.rglob("*.java"):
        rel = path.relative_to(base).as_posix()
        if module == "opendoja" and (
            rel.startswith(OPEN_DOJA_EXCLUDED_PREFIXES)
            or rel in OPEN_DOJA_EXCLUDED_FILES
        ):
            continue
        sources.append((module, path, rel))

# Resource XML in an unqualified drawable/ folder is parsed by API 19. Native
# VectorDrawable was added in API 21, so vector XML must be version-qualified
# and accompanied by a raster fallback for API 19.
resource_root = ROOT / "app/src/main/res"
resource_failures = []
vector_count = 0
for folder in sorted(resource_root.glob("drawable*")):
    if not folder.is_dir():
        continue
    for xml_path in folder.glob("*.xml"):
        try:
            root_tag = ET.parse(xml_path).getroot().tag.rsplit("}", 1)[-1]
        except ET.ParseError as exc:
            resource_failures.append(f"{xml_path.relative_to(ROOT)}: invalid XML ({exc})")
            continue
        if root_tag == "vector":
            vector_count += 1
            if folder.name == "drawable":
                resource_failures.append(
                    f"{xml_path.relative_to(ROOT)}: VectorDrawable is API 21+; move it to drawable-v21"
                )
            fallback = resource_root / "drawable-mdpi" / (xml_path.stem + ".png")
            if not fallback.is_file():
                resource_failures.append(
                    f"{xml_path.relative_to(ROOT)}: missing drawable-mdpi/{xml_path.stem}.png API 19 fallback"
                )
        if root_tag == "ripple" and folder.name == "drawable":
            resource_failures.append(
                f"{xml_path.relative_to(ROOT)}: RippleDrawable is API 21+; qualify it with drawable-v21"
            )
failures = resource_failures.copy()

# APIs that are not supplied by the API-19 platform and are not backported by
# the configured desugared library. Newer java.nio.file and java.util APIs are
# separately required to be backed by desugar_jdk_libs_nio (see checks below).
forbidden = [
    (re.compile(r"\bPath\s*\.\s*of\s*\("), "Path.of is not in the Android Path API; use Paths.get"),
    (re.compile(r"(?<!StringCompat)\.\s*isBlank\s*\("), "String.isBlank is unavailable on API 19; use StringCompat.isBlank"),
    (re.compile(r"(?<!StringCompat)\.\s*repeat\s*\("), "String.repeat is unavailable on API 19; use StringCompat.repeat"),
    (re.compile(r"\bFiles\s*\.\s*(?:readString|writeString)\s*\("), "Files.readString/writeString are not in the compile SDK's Android API surface; use streams"),
]
# Preserve resource compatibility failures collected above.
api_usage = {"java.nio.file": 0, "java.util collection factories": 0, "java.util.Base64": 0, "Java record declarations": 0}
for module, path, rel in sources:
    source = path.read_text(encoding="utf-8")
    # Strip comments to avoid false positives in examples and documentation.
    source = re.sub(r"/\*.*?\*/|//[^\n]*", "", source, flags=re.S)
    for pattern, message in forbidden:
        if pattern.search(source):
            failures.append(f"{module}/{rel}: {message}")
    api_usage["java.nio.file"] += len(re.findall(r"\b(?:java\.nio\.file\.)?(?:Files|Paths|Path)\s*\.", source))
    api_usage["java.util collection factories"] += len(re.findall(r"\b(?:List|Set|Map)\s*\.\s*(?:of|copyOf)\s*\(", source))
    api_usage["java.util.Base64"] += len(re.findall(r"\b(?:java\.util\.)?Base64\s*\.", source))
    api_usage["Java record declarations"] += len(re.findall(r"^\s*(?:(?:public|protected|private)\s+)?(?:(?:static)\s+)?record\s+[A-Za-z_$]", source, re.M))

app_gradle = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
required = {
    "minSdk 19": r"minSdk\s+19",
    "multidex enabled": r"multiDexEnabled\s+true",
    "core library desugaring enabled": r"coreLibraryDesugaringEnabled\s+true",
    "NIO desugaring artifact": r"desugar_jdk_libs_nio:2\.1\.4",
    "MultiDexApplication manifest": r"android:name=\"androidx\.multidex\.MultiDexApplication\"",
}
for label, pattern in required.items():
    target = ROOT / "app/src/main/AndroidManifest.xml" if label == "MultiDexApplication manifest" else ROOT / "app/build.gradle"
    if not re.search(pattern, target.read_text(encoding="utf-8")):
        failures.append(f"{target.relative_to(ROOT)}: missing {label}")

# This project intentionally ships only the original PocketDoJa-based API 19 app.
# Do not reintroduce a modern flavor or a second application.
for label, pattern in {
    "single API 19 application": r"minSdk\s+19",
    "explicit BuildConfig generation": r"buildConfig\s+true",
}.items():
    if not re.search(pattern, app_gradle):
        failures.append(f"app/build.gradle: missing {label}")
if re.search(r"productFlavors|modern\s*\{", app_gradle):
    failures.append("app/build.gradle: unexpected additional Android flavor; only API 19 Legacy is allowed")

# java.util.List/Map factory methods and java.util.Base64 are intentionally
# used by the runtime. Android's Java 11 API desugaring includes these APIs;
# NIO mode includes that default API set plus java.nio.file.
if "desugar_jdk_libs_nio" not in app_gradle:
    failures.append("app/build.gradle: NIO + Java 11 API desugaring is required")

# D8 record desugaring is supported by AGP 8.1+. This project currently uses
# AGP 8.13.2, so record declarations can be lowered for pre-Android-14 VMs.
root_gradle = (ROOT / "build.gradle").read_text(encoding="utf-8")
agp = re.search(r"com\.android\.application['\"]?\s+version\s+['\"]([0-9]+)\.([0-9]+)", root_gradle)
if api_usage["Java record declarations"] and (not agp or (int(agp.group(1)), int(agp.group(2))) < (8, 1)):
    failures.append("build.gradle: Java records require AGP 8.1+ D8 record desugaring")

if failures:
    print("API 19 source preflight: FAIL")
    print("\n".join(f" - {item}" for item in failures))
    sys.exit(1)

print(f"API 19 source preflight: PASS ({len(sources)} shipped Java source files scanned)")
print(" - Scanned app, OpenDoJa runtime, and dexlib source sets; excluded only non-shipped probes/tools")
print(" - No Path.of, direct String.isBlank/String.repeat, or Files.readString/writeString calls")
print(" - Single PocketDoJa Legacy application targets API 19; MultiDexApplication, multidex, and NIO + Java 11 desugaring are configured")
print(f" - Resource compatibility: {vector_count} version-qualified VectorDrawable resources checked for API 19 PNG fallbacks")
print(" - Java record declarations require AGP 8.1+; configured AGP is checked for D8 record desugaring")
for label, count in api_usage.items():
    print(f" - Runtime references found: {label}: {count} (checked against configured desugaring)")
