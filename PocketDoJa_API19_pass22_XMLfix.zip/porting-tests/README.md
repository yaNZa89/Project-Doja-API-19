# API 19 porting smoke tests

The locale fallback test is deliberately plain Java and can be run without an Android SDK:

```sh
mkdir -p /tmp/locale-test-out
javac -d /tmp/locale-test-out \
  porting-tests/opendoja/android/LocaleTagCompat.java \
  porting-tests/opendoja/android/LocaleTagCompatSmokeTest.java
java -cp /tmp/locale-test-out opendoja.android.LocaleTagCompatSmokeTest
```

The Android audio/vibration source changes were syntax-checked in the development
container against API-shaped Android stubs. This is not a substitute for compiling
against the real Android SDK or running on an API 19 device.

## Game JAR → Dalvik DEX smoke test

The DEX pipeline test can be run on a desktop JDK without Android SDK tools. It
compiles the in-project dx sources, converts a supplied DoJa game JAR to classic
DEX 035, parses the resulting DEX, and verifies that all class entries and game
resource entries are visible to the archive reader.

```sh
./porting-tests/run-jam-dex-smoke.sh /path/to/game.jar
```

This is a host-side conversion/format test. It does not execute Android's
`DexClassLoader` or replace a test on Android 4.4.


## Monster Hunter i for SH launch preflight

See [`mhi/README.md`](mhi/README.md) for the static JAM/JAR preflight. It
checks that the original `AppClass` extends the DoJa `IApplication`, that all
DoJa API classes referenced by the game exist in the emulator source tree,
and that resource names embedded in the game bytecode exist in the JAR. It is
not an Android runtime test.
