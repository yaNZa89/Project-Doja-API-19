# PocketDoJa API 19 — catatan blocker runtime (direvisi pada Pass 13)

Dokumen ini menggantikan asumsi awal bahwa semua penggunaan `java.nio.file` harus dimigrasikan ke `java.io.File` untuk API 19.

## Status NIO

Source runtime masih memakai `java.nio.file`, tetapi proyek mengaktifkan `coreLibraryDesugaring` dan memakai `com.android.tools:desugar_jdk_libs_nio:2.1.4`. Dokumentasi Android menyatakan spesifikasi NIO dapat mengemulasikan `java.nio.file` pada perangkat di bawah API 26. Karena itu, pemakaian NIO bukan otomatis blocker API 19.

Batasan di bawah API 26 tetap ada, termasuk `AsynchronousFileChannel`, watch service, dan atribut POSIX. Pemeriksaan source runtime saat Pass 13 tidak menemukan penggunaan langsung fitur-fitur tersebut. Uji perangkat masih wajib.

## Blocker yang sudah diperbaiki di Pass 13

- Enam resource VectorDrawable berada di folder `drawable/` tanpa qualifier. Native VectorDrawable baru tersedia API 21; pada API 19 pemanggilan `Resources.getDrawable()` berisiko gagal.
- Pass 13 memindahkan XML ke `drawable-v21/` dan menambahkan PNG fallback di lima density folder.
- Preflight CI kini memeriksa keberadaan fallback tersebut.

## Masih perlu diverifikasi

- Build APK dengan AGP 8.13.2 / Gradle 8.13.
- DEX akhir berformat 035 untuk Dalvik Android 4.4.
- API Android level 21+ yang diisolasi pada helper benar-benar tidak dipanggil di API 19.
- Install, launch, import JAM/JAR/SP, render, input, audio, dan gameplay pada perangkat/emulator API 19.

Status: belum ada APK hasil build dan belum ada uji runtime Android 4.4.
