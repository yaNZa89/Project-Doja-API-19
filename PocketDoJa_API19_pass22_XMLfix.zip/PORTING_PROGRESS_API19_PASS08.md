# PocketDoJa API 19 — pass 08: Android runtime test harness

## Source review

Reviewed the pass 07 Android launch path:

- `EntryActivity.launchGame()` locates the game JAR and calls
  `JamDexHost.ensureDex()`.
- `JamDexHost` checks the DEX magic for `dex\n035`, parses its table of
  contents, then creates a `DexClassLoader`.
- `EntryActivity` registers a `JamGameClassLoaderFactory` provider.
- `JamLauncher.buildLaunchConfig()` resolves `AppClass` through that provider
  and verifies that the class extends `IApplication`.
- `DesktopLauncher.launch()` is the next lifecycle boundary.

This is source-path inspection, not proof that Dalvik has executed the chain.

## New artifact

Added `porting-tests/mhi/run-api19-device-test.sh` and
`porting-tests/mhi/API19_RUNTIME_TEST.md`. The script refuses to run unless the
connected device reports SDK 19, builds/installs the debug APK, copies the
original Monster Hunter JAM/JAR/SP files, and launches the game activity.

## Checks performed in this workspace

- Re-opened pass 07 source archive and verified the above source call chain.
- Re-read pass 07 JAM/JAR preflight and DEX test output.
- Confirmed this workspace has no `adb`, `emulator`, `dalvikvm`, Android SDK
  `android.jar`, `d8`, `aapt`, or `sdkmanager` executable.
- Attempted the bundled openDoJa host smoke build with local JDK 21; it cannot
  compile the Android host source without Android SDK classes. This does not
  test or disprove the Android build.

## Status

- Static JAM/JAR preflight: passed in pass 07.
- Game JAR → DEX 035 host-side test: passed in pass 07.
- Android source launch-chain review: completed in pass 08.
- Android Gradle build: not run successfully; required Gradle distribution and
  Android SDK/platform/build-tools are unavailable in this workspace.
- Dalvik `DexClassLoader`, `IApplication.start()`, first frame, audio, and
  controls: not yet tested on API 19.
- No new APK is claimed or supplied in this pass.

## Next required evidence

Run the new device script on an Android 4.4 emulator/device. The first actual
runtime exception or a successful first title frame will determine the next
code change.
